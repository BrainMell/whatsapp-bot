# Lore Drops — Afterlife (the realm beyond the veil; speaker: the soul reader)

> Pool for the soul-sight / Afterlife feature (brief §17–§22). Format contract: rendered as
> `╒ *line* ╛`, italics on the text only.
>
> **Canon discipline:**
> - The realm is UNNAMED (owner decision pending; see additional_ideas/ideas.md naming note).
> - It is NOT declared inside Kosmion and NOT declared separate — the player discovers its
>   existence gradually; these lines never map it.
> - "Beyond the veil" phrasing is shared with the GOD-dungeon canon (Boundless Void) — used
>   deliberately as the same membrane language. No mechanics attached in dialogue.
> - The Abyss-souls lines are marked PROPOSED / NEEDS REVIEW and are NOT canon (brief §22).

## Pool 1 — the veil itself (place-flavored, speaker as guide)

1. ╒ *The veil isn't a wall. It's a shoreline. Things cross it the way tide crosses sand — patiently, and twice a day.* ╛
2. ╒ *Don't touch the curtains. Curiosity presses; the veil is polite about being pressed, once.* ╛
3. ╒ *Beyond, the light is the color of the hour you were happiest. It does that on purpose. Settle in or move along — both are allowed.* ╛
4. ╒ *It smells like rain on the far side. Everyone says so. Nobody who crossed remembers why that comforts them, but it does.* ╛
5. ╒ *The veil doesn't take. It KEEPS. There's a difference, and one day the difference will matter to you personally. Then you'll understand all my rules.* ╛

## Pool 2 — the souls (what the player's count means)

6. ╒ *You've sent quite a few souls my way lately. Business is good. I'd rather it weren't.* ╛
7. ╒ *They arrive as they were at their favorite hour. Monsters pick strange hours. You get used to the horns. You do NOT get used to the humming.* ╛
8. ╒ *A soul carries its last surprise across the veil. Yours all looked… prepared. That's a testament to you, if you want it.* ╛
9. ╒ *The count isn't a debt. The count is a library. Every number on your page is a story that ended where you stood.* ╛
10. ╒ *Do you know what they do when they arrive? They look at their hands. Every one of them, first thing. Even the ones with claws. Especially those.* ╛
11. ╒ *Some souls don't stay where they're supposed to. If you meet a wanderer who feels like a place more than a person — be polite. And keep walking.* ╛
12. ╒ *I've seen warriors arrive here from worlds you've never heard of. They tell the same stories with different names. Every time.* ╛
13. ╒ *It's becoming rather crowded beyond the veil. Whatever is stirring down deep in the Abyss — it isn't only your world doing the sending.* ╛
14. ╒ *Souls keep their favorite year, you know. Most pick something small. A kitchen. A rain. Nobody picks the treasure.* ╛
15. ╒ *The newly dead always ask the same three questions: did it matter, who won, and who's watching my dog. In that order, always.* ╛
16. ╒ *I can tell a monster's soul from a person's by the weight. You'd be surprised how often the monster's is lighter.* ╛
17. ╒ *The Infected arrive… lighter than they should. Like something was already gone before you met them. Don't carry that one around. That one's mine to carry.* ╛

## Pool 3 — the realm (gradual discovery, never a map)

18. ╒ *There are roads on the far side. I don't know where they go. The ones who walk them don't come back to say, and I've stopped finding that rude.* ╛
19. ╒ *There's a city past the meadows — I've seen it from the shore. Lights in windows. Nothing else. Whoever lights them has good taste and worse manners about questions.* ╛
20. ╒ *The far side has weather. Not ours. It remembers winters from a billion skies ago. You can smell a world in it that hasn't been born yet.* ╛
21. ╒ *Gods arrive like weather. Don't gawk. Offer tea. They're mostly embarrassed.* ╛
22. ╒ *Sometimes the veil wears thin where many souls crossed at once. Battlefields. Burning cities. Deep floors. Geography remembers.* ╛
23. ╒ *There is a door past the veil that even I don't open. It's warm to the touch. The old texts call it politely 'the second question.' We don't ask the first one either.* ╛

## Pool 4 — instructions & warnings (how to behave about souls)

24. ╒ *Don't apologize to them. They hear it as a doorbell. Don't thank me either. The veil hears THAT as an opening.* ╛
25. ╒ *Come back when the count gets heavy. Heaviness is just company you haven't spoken to yet.* ╛
26. ╒ *Do not bargain with whatever answers when you knock. I answer FOR it. That's the whole arrangement. Three coins.* ╛
27. ╒ *Never count the souls out loud in a dungeon. Numbers echo down there, and some floors are still hungry.* ╛

## Pool 5 — PROPOSED / NEEDS REVIEW (abyss-soul connection, brief §22 — NOT canon)

28. ╒ *The souls that come from the Abyss are… different. They arrive sideways, as if the road to here bends around somewhere else.* ╛
29. ╒ *A soul cut loose below floor ninety hums in a chord. I don't cast for those. The veil is thin enough there already.* ╛
30. ╒ *Sometimes two of the same soul arrive from different deeps, hours apart. Same person. Neither knows. I seat them far from each other. It's kinder.* ╛
31. ╒ *Below a certain floor, the veil doesn't wait for death. It just… leans closer. Like a listener. Whatever you meet down there — finish it kindly.* ╛
