# Implementation — Lore Drop System (design-only)

> Pools live in `lore_drops/`. Format contract in `lore_drops/README.md`.
> This document = the smallest safe machine to run them.
>
> **OWNER DECISION (review pass 2): lore drops are plain chat TEXT, occasionally.** They are
> never baked into card images and never appended to rendered card captions. Where this doc's
> surface table names a card caption as the attach point, attach instead to the command's
> TEXT reply (before/after the card message), or skip that surface. The `╒ *line* ╛` framing
> and the 10%-baseline/cooldown tuning are unchanged.

## 1. The module

`core/rpg/loreDrops.js` — NEW module (house pattern: broadcastHelpers.js / interactionTracker.js
precedent; keeps engine.js untouched except 1-line call sites).

```js
// shape (illustrative, not final)
const POOLS = { blacksmith: [...], brewing: [...], crafting: [...], enchanting: [...],
                healing: [...], trading: [...], general_world: [...],
                abyss_unknown_creature: [...], abyss_player: [...],
                abyss_distorted_player: [...], abyss_timeline_person: [...],
                abyss_self_variant: [...], afterlife: [...] };

const CONFIG = { BASE_CHANCE: 0.10, COOLDOWN_MS: 30*60*1000, RECENT_RING: 10,
                 IMPORTANT_WEIGHT: 0.4 };

function maybeDrop(category, { userId, chatId, force } = {}) -> string | null
//  1. pool = POOLS[category]; if (!pool) return null
//  2. cooldown: last drop for (chatId:userId) < 30 min ? null   (Map, lazy pruned)
//  3. chance gate: Math.random() >= chance ? null
//     chance = CONFIG.BASE_CHANCE unless caller overrides (per-surface tuning table §3)
//  4. candidates = pool minus recentRing(chatId); pick uniformly
//     ("occasionally important" lines carry weight 0.4 → 2.5× rarer)
//  5. push to ring; stamp cooldown; return `╒ *${line}* ╛`
// Entire function synchronous + try/catch-wrapped; on ANY internal error return null.
```

Rendering rule (brief §13): the returned string is `╒ *text* ╛` — asterisks INSIDE the
framers; framing glyphs never italicized. Appenders simply concatenate `+ "\n" + drop` to the
existing TEXT reply. No new message, no box, no header, no card images involved.

## 2. Probability — why 10% baseline, and where it should bend

Investigation found the house precedents: menu tips = 100% rotating (engine.js:5469-5515),
combat whispers = **5%** (guildAdventure.js:7313-7327). Player-facing crafting/economy
commands are spammable (craft ×N per hour), so a flat 10% on every craft would get muted.

| Surface | Suggested chance | Reason |
|---|---|---|
| craft/brew/cook/forge (craftingSystem.js:717 caption) | **8%** + 30-min cooldown | high-frequency command |
| balance/transfer/deposit/withdraw (money captions) | **10%** | medium frequency, captions near-empty today |
| blacksmith/repair (repairCommands.js:118/170) | **12%** | lower frequency, thematically rich |
| rune socket/fuse | **10%** | ritual moment |
| heal/hospital | **10%** | medium frequency |
| shop buy/sell | **8%** | high frequency |
| Abyss victory / collect / event | **12%** | low frequency, high atmosphere value |
| general (menus, tips rotation) | replaced by existing TIPS slot at 1-in-6 | zero new risk |

The cooldown (per user+chat, 30 min) does the heavy anti-noise lifting; the chances above are
what the owner tunes later. Alternative documented per brief §14: flat 10% everywhere with NO
cooldown would produce ~1 drop per 10 crafts — acceptable but noisier; NOT recommended.

## 3. Category selection (context decides — never random-across-pools)

| Call site (when implemented) | Category |
|---|---|
| craftingSystem.performCraft success (craftingSystem.js:713-717) | `crafting`, or `brewing`/`blacksmith` when the recipe family is BREW*/FORGE* (cardType map already distinguishes, rpgCommands.js:806) |
| repairCommands.js:118/170 + displayBlacksmith | `blacksmith` |
| runeSystem.js:739/663/831/848 | `enchanting` |
| engine.js:9967/9990 | `healing` |
| economy.js:1069/1149/1238 + engine.js:25226 caption | `trading` |
| shopCommands.js:446, rpgCommands.js:527 | `trading` |
| guildAdventure.js:6330-6362 (abyss victory) | keyed by encounter type: combat+boss→`abyss_*` by enemy class flags; wild_summon→`abyss_unknown_creature`; player-like/distorted/alt-self/timeline variants need enemy tagging (see implementation/abyss.md) |
| soul-sight feature | `afterlife` |
| menu tips slot | `general_world` |

## 4. Duplicate prevention & fairness

- Recent-ring per chat (10 entries) prevents immediate repeats even under cooldown resets.
- Pools ship with 22–31 lines each; the ring depth (10) guarantees rotation without starving.
- "Occasionally important" lines: weight 0.4 — land roughly once per 25 relevant actions, not
  per 10 — they stay special.
- Drops are pure text: zero schema change, zero Mongo writes, zero risk to the 450MB RAM line
  (a Map of small strings, pruned lazily).

## 5. Rollout order (when approved)

1. Ship module + ONE pool (`blacksmith`) on `.j repair` only → live soak.
2. Add craft-family + trading captions (the two best-attaching surfaces).
3. Add Abyss pools (needs enemy tagging from implementation/abyss.md).
4. Add `afterlife` pool with the soul-sight feature.
5. Tune chances from real drop-rate logs (a single `console.log('[loreDrop]', category)` line,
   removed after tuning).

## 6. Never-do list

- Never attach a drop to error/failure paths (user frustration × mystery = annoyance).
- Never two drops in one reply (the appender is a single call site per flow by construction).
- Never let the drop displace functional text: it is appended AFTER the result line, and
  captions keep the functional text as the first line(s).
- Never write drops in a bot persona's voice (personas are lore-forbidden, engine.js:3400).
- `.j lore` stays untouched — drops link to it, never duplicate it.
