# Implementation — Abyss Lore Encounters (design-only)

> Pools: `lore_drops/abyss.md` (5 categories). Mockups: `image_cards/abyss/`.
> Canon anchors: Boundless Void Floor 4 (alternate self), Abyss header lore
> (abyssSystem.js:8-16), GOD-dungeon veil language.

## 1. Encounter-category detection (what exists today)

`generateFloorEncounter` (abyssSystem.js:282-347) already classifies every floor into
`combat | wild_summon | treasure | event` (+ boss flag every 5th / mini-boss every 3rd on 11-20,
+ pack flag with 55%-stat adds queued on `AbyssRun.packQueue`). The encounter type persists on
the run (`currentEncounterType`, `currentEncounterData` — Mixed), so **drop routing needs no
new persistence**.

## 2. Category → pool routing

| Encounter reality | Pool | Why it fits |
|---|---|---|
| `wild_summon` — no wait, wild summons are the player's own species summons; they are FRIENDLY faces | `abyss_unknown_creature` does NOT fit here — route wild_summon floors to NO pool (or a future "the deep is watching" line) | wild summons are the player's companion variant, not an alien |
| combat vs element-family enemy (fire/water/earth/ice/mutated/hybrides) | `abyss_unknown_creature` | these are the "not from any world you've walked" bodies |
| combat vs humanoid-shaped enemy (future tag) | `abyss_player` | person-shaped |
| combat vs distorted variants (future tag) | `abyss_distorted_player` | almost-human |
| boss floors ≥ floor 90 or GOD-tier enemies | `abyss_self_variant` (rare) + `abyss_timeline_person` | deepest = closest to the veil; canon echo of Void Floor 4 |
| treasure / event floors | `general_world` (light touch) or none | don't dilute the horror pools |

## 3. The enemy tagging question (the ONE real prerequisite)

Today the enemy pool doesn't distinguish "person-shaped" from "creature". V1 (dialogue-only)
can fake the routing heuristically:

- `abyss_unknown_creature`: enemy id NOT matching known humanoid names; element-family enemies.
- `abyss_player` / `abyss_distorted_player` / `abyss_timeline_person` / `abyss_self_variant`:
  **require new encounter variants** — which IS a gameplay change (new enemies), listed here
  for completeness but marked PROPOSED. The dialogue-only v1 routes:
  - floors 1-30 → creature pool only
  - floors 31-89 → creature (70%) + timeline_person (30%)
  - floors 90+ / GOD tier → + self_variant (rare weight) — the player has "seen enough" by then
  This escalation respects brief §16 ("gradually become suspicious") without new enemies.

V2 (PROPOSED, needs owner sign-off): 2-3 new enemy variants (`WANDERER`, `MIRROR_SELF`,
`OTHER_BANNER`) using existing humanoid sprite bases (the repo has 30 class bases 512×1024 to
crop from — zero new art required for a prototype), tagged `humanoid: true` on the enemy
definition; routing then keys off the tag. Enemy XP/rewards would reuse the standard pool math.

## 4. Text attach points (verified sites)

- Floor-cleared text: guildAdventure.js `handleAbyssVictory` ~6330-6362 — append drop after
  the rewards block.
- Pack-fight lines: ~6288-6292 — pack fights may add ONE extra drop chance from the creature
  pool when an add jumps in (the "another one steps out" moment).
- Treasure collect: abyssSystem.js `processTreasure` ~529-595 — `general_world` only.
- Event rooms: `processEventChoice` ~648-734 — `general_world`.
- Death/retreat: NO drops (never attach to failure — house rule).

## 5. Encounter treatment (OWNER DECISION — review pass 2)

Abyss encounters get **NO bespoke image cards**. They are plain encounters rendered by the
existing pipeline: correct enemy sprite + ability set + the standard kill hooks
(`recordEnemyKill`). The mystery lives in *naming, behaviour and dialogue*, not in a new card
kind. Parity mockups: `image_cards/world/abyss_encounter_normal_{kobold,contact}.png` —
variant A shows a hostile deep mob using the bot's own kobold sprite with an abyss ability
set; variant B shows the person-shaped contact as a behaviour/diff row entry using the
existing humanoid sprite family.

Concretely: abyss enemy definitions extend the existing enemy tables (sprite reference +
ability rows + optional dialogue line). The `abyss_contact` flag (if adopted) toggles
behaviour (dialogue-first, no loot) — not a renderer branch.
## 6. What must NOT happen

- No mechanical tells in dialogue (no "this enemy has +10% dodge") — dialogue is observation.
- No confirmed cosmology: pools never SAY "multiverse"/"timeline" — they show wrongness.
- The word "Kosmion" never appears in Abyss drops (the map/lore docs own that name; the deep
  doesn't name things).
- Alternate-self lines never confirm identity — recognition stays deniable (canon Void Floor 4
  keeps the definitive version; the Abyss only whispers).
