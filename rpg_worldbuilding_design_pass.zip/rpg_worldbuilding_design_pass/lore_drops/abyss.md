# Lore Drops — Abyss Encounters (five category pools)

> Pools keyed to Abyss encounter categories (see investigation/existing_commands.md §3 —
> encounter type is known at render time: `combat`/`wild_summon`/`treasure`/`event`, plus
> boss/pack flags). Format contract: rendered as `╒ *line* ╛`, italics on the text only.
>
> **Voice rule for all Abyss pools:** the line is spoken by the player's party-member, a fellow
> adventurer, a survivor met at the edge — someone who SAW the encounter. Never the bot's
> persona, never the monster.

---

## 1. abyss_unknown_creature

*Creatures from worlds the player has never visited. The player must NOT imply recognition of
the species. Suspicion, description, and wrongness — never a name from home.*

1. ╒ *I've never seen a creature like this before. And I've seen the deep bestiaries. Twice.* ╛
2. ╒ *That's not from any world I've walked. Look at the joints — they bend like it's apologizing to a different sky.* ╛
3. ╒ *Whatever that is, it isn't infected. This is what it looks like when something is exactly what it's supposed to be. Somewhere else.* ╛
4. ╒ *Don't name it. Things from down here answer to their names, and we don't know which words are names.* ╛
5. ╒ *It has a spine like writing. I can't read it. I don't want to be able to.* ╛
6. ╒ *The bestiary has a blank page for this one. The blank page has a note: 'ask the old worlds.'* ╛
7. ╒ *Six legs, three lungs, and eyes like it's grading us. From where I stand, that's a person. From where it stands, who knows.* ╛
8. ╒ *It came out of a tunnel that isn't on any map, in a wall that doesn't have tunnels. It looked surprised too.* ╛
9. ╒ *Its shadow moves a half-second late. I've seen that once before — on a thing we never fought, only watched. It watched back for an hour.* ╛
10. ╒ *The lanterns hate it. All four went out politely, like ushers. When they came back, it was closer.* ╛
11. ╒ *I've fought infected, constructs, void-touched. This is none of those. This is a citizen of somewhere, and we are the intruders.* ╛
12. ╒ *It hums when it hunts. A tune. A CHILDREN'S tune. From a world I've never been to, I hope.* ╛

---

## 2. abyss_player

*Player-like enemies: humanoids with an adventurer's build and gear, not monsters.*

1. ╒ *This isn't a monster… it's a person.* ╛
2. ╒ *Why does it have a player's build? Boots, pack straps, sword-calluses. That's not a costume.* ╛
3. ╒ *It fights like an adventurer. Guard, breathe, riposte — somebody TRAINED it. Somebody like us.* ╛
4. ╒ *Its gear is real. Mended, patched, worn IN. Nothing down here mends. So where does it shop?* ╛
5. ╒ *It had a guild badge. I didn't recognize the guild. That's the part that keeps me up.* ╛
6. ╒ *I searched the body. Rations. A whetstone. A letter it never sent. I burned the letter. It felt politer.* ╛
7. ╒ *It said one word before it fell. Sounded like a name. Sounded like it was ANSWERING to it.* ╛
8. ╒ *Don't loot the person-shaped ones. The veterans don't. Ask them why and they'll buy you a drink instead of answering.* ╛
9. ╒ *It was smiling when we found it. Not mad. Relieved. That's worse.* ╛
10. ╒ *The thing walked like me. Not similar. LIKE me. Same tired left knee. Tell me that's a coincidence.* ╛

---

## 3. abyss_distorted_player

*Almost-human things: the shape is right, everything else is subtly wrong.*

1. ╒ *That looks human… but it feels like something else.* ╛
2. ╒ *Count the fingers. Count them twice. Then tell me I'm imagining things.* ╛
3. ╒ *It wore its helmet like it had never seen a mirror. Everything backwards. The buckle, the gait, the blade-hand.* ╛
4. ╒ *It smiled the whole fight. Not cruelly. The way you smile for a portrait you've held too long.* ╛
5. ╒ *The face was fine. The face was fine. The face was fine. I keep saying it so I stop checking the face.* ╛
6. ╒ *It talked, mid-swing. Full sentences. Wrong order. Like a person reciting a memory of a conversation instead of having one.* ╛
7. ╒ *Its armor fit. Perfectly. Things down here wear rags and bark. This was TAILORED. Who tailored it?* ╛
8. ╒ *When it fell, it fell like laundry. No weight. I've killed a hundred things and none of them fell like laundry.* ╛
9. ╒ *It had a shadow of its own for everyone except itself. I looked away. Professional instinct. Very loud instinct.* ╛
10. ╒ *The voice at the end was almost a person's. It said 'finally' the way you'd say it at the end of a long shift. I need that to mean nothing.* ╛

---

## 4. abyss_timeline_person

*Other-timeline versions of people: gradually suspicious, never explained.*

1. ╒ *He wore the guild colors — the OLD ones. The ones from before the second banner. He called the fortress by its old name, too.* ╛
2. ╒ *She mentioned a war I've never heard of, then mentioned a peace I HAVE. Same names. Different years.* ╛
3. ╒ *He recognized my sword. Not the make — the SCRATCHES. His were different, but he knew where mine would be.* ╛
4. ╒ *She said the city burned 'the first time.' The first time? Nobody corrected her. Nobody wanted to open that door.* ╛
5. ╒ *His scars were my captain's scars, mapped wrong. Same battles, other outcomes. I stopped counting after three.* ╛
6. ╒ *She was looking for someone. Described them down to the laugh. The name was half a heartbeat off, like a word in a dream.* ╛
7. ╒ *He asked how long since the sky 'flickered.' We told him: it hasn't. He said: 'yet,' like a man checking the weather.* ╛
8. ╒ *The coin she paid me with was our mint. Our face on it. A year that hasn't happened. I didn't give it back. I didn't keep it either.* ╛
9. ╒ *He thanked me for a kindness I've never done. I said 'you're welcome.' What else do you say?* ╛
10. ╒ *They travel in small groups, the ones from… elsewhere. You can tell by how they apologize — for things that haven't gone wrong yet.* ╛

---

## 5. abyss_self_variant

*Alternate versions of the player. Shock first, humor as armor, never an explanation.
Established canon echo: GOD-dungeon Floor 4 ("it wears your face") — these must feel like the
same phenomenon met earlier on the road.*

1. ╒ *…Why does that person have my face?* ╛
2. ╒ *How can there be another version of me? Ask a better question, I know. I don't have one.* ╛
3. ╒ *It had my scar. MY scar, from MY first dungeon. I got that scar HERE. There's no version of this that's fine.* ╛
4. ╒ *It fought exactly like me. Same openings, same lazy left guard. I've never been parried by my own bad habits before.* ╛
5. ╒ *We stared at each other a full minute. Then it nodded, like we'd planned this. We did NOT plan this.* ╛
6. ╒ *Mine was kinder. Smiled more. Better with people. I hated it instantly. Is that normal? Don't answer.* ╛
7. ╒ *It said: 'you took the left tunnel.' That's all. It DIED on that sentence. I take the right tunnels now. Superstition is free.* ╛
8. ╒ *Its kit was mine but older. Better kept. It kept its gear together. Why couldn't it keep ITSELF together?* ╛
9. ╒ *When it fell, I felt it. Not like a wound. Like a page turning somewhere I couldn't look.* ╛
10. ╒ *There were two of me once before, in a nightmare that didn't stay a nightmare. I told no one. I'm telling you. Tell no one.* ╛
11. ╒ *The others are laughing about it now — 'ha, your DOUBLE.' Laugh it up. One of us came down. One of us is down here. Do the count yourself.* ╛
12. ╒ *I checked my own hands after. Left, right, left. All mine. For now they're mine. That's the whole prayer and I'm not ashamed of it.* ╛
