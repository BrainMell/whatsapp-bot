# Lore Drops — Trading / Money

> Pool for `.j balance`, `.j transfer`, `.j deposit`, `.j withdraw`, `.j buy`, `.j sell`.
> Format contract: rendered as `╒ *line* ╛`, italics on the text only.
> Note: balance-card captions are currently near-empty (engine.js:25226) — prime slot.

## Usage notes

- Speaker implied: a banker's clerk, a market vendor, a pawnbroker, the coin itself in one or
  two cheeky lines. Money is the most *mundane* surface — drops here should skew warm/funny,
  with the eerie ones rare.
- Canon money facts: Zeni (Ꞩ), wallet/bank clamps, the mint, merchants from other realms
  (established by the theme system's "trade between the realms" flavor — reuse sparingly).

## Pool — mundane / warm

1. ╒ *The vault doesn't sleep, but the clerks do. Your Zeni kept better watch than we would anyway.* ╛
2. ╒ *Spend a little on bread, adventurer. Heroes have collapsed in my shop more than bandits have robbed it.* ╛
3. ╒ *Counted twice, sealed once. The house always double-checks. It's the house that trusts nobody.* ╛
4. ╒ *Coin's heavier when you've earned it slow. That's not sentiment. It's arithmetic, somewhere.* ╛
5. ╒ *Everything's for sale except the scale. The scale is honest. One honest thing per shop is the legal maximum.* ╛
6. ╒ *Your bank box has a scratch inside the lid. Previous owner's doing. We keep it. Looks like a tally.* ╛
7. ╒ *Come on market day. Prices are the same but the complaining is free.* ╛

## Pool — funny

8. ╒ *Deposits, withdrawals, deposits. Adventurers treat the vault like a very serious game of catch.* ╛
9. ╒ *You send money faster than the couriers can walk. We've stopped telling them where it's going. They're sensitive.* ╛
10. ╒ *No, the mint doesn't take trade-ins on regrets. We asked. The answer was a form.* ╛
11. ╒ *Bought low on iron, sold high on banners. Wars are terrible for people and wonderful for futures. I only deal in one of those.* ╛
12. ╒ *The coinpurse sings when it's full. Yours hums. Work on that.* ╛

## Pool — mysterious / worldbuilding

13. ╒ *Zeni from the deep dungeons spends fine. The bank just asks that you let the older pieces rest a night before counting. For the sound. The sound of the counting.* ╛
14. ╒ *A merchant paid in coin from a kingdom I've never heard of, and I've heard of all of them. It spent. It's spending still. We don't keep it overnight together.* ╛
15. ╒ *Bank ledgers here go back six hundred years. Every few decades a page shows a name that was never a customer. The name always has money. The money is always withdrawn. By whom is not recorded.* ╛
16. ╒ *Realms rise, realms settle, the exchange rate between them is set on the second floor. You don't want to meet the people on the second floor. Lovely people. You just don't want to owe them.* ╛
17. ╒ *Old coins sometimes come up from below with faces worn clean. Collectors pay extra for those. The faces went somewhere, I say. Nobody's argued.* ╛

## Pool — occasionally important

18. ╒ *A buyer came through offering triple for dungeon-touched steel. Paid in advance, waited a month, gone. Keep your odd finds. Someone is cataloguing.* ╛
19. ╒ *There's a ledger the guild keeps of who owes WHOM, beyond money. Debts of rescue, of blood, of last words carried. Different clerks. Same shelf.* ╛
20. ╒ *If anyone ever pays you exactly thirteen coins, count them again. I've said too much already, and I count everything.* ╛
