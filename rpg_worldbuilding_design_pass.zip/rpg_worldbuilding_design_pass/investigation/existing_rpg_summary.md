# Existing RPG Summary — System Inventory

> Investigation document, read-only. Repo state: `whatsapp-bot` @ `audit/fix-pass-1` `31be194f`,
> `Bot_genaration` @ `main` `01ab7e0`. All facts verified live in source.

---

## 1. What the product is

A multi-tenant **WhatsApp RPG** built on Node.js (Baileys) with a **Go microservice** for image
rendering and **MongoDB Atlas** for persistence. Players interact through per-bot prefixes
(`.j`, `.jk`, `.s`, `.e`, `.g`) in group chats: they register, level to 100, climb an adventurer
rank ladder F→GOD, craft/brew/cook/forge gear, socket runes, fight PvE dungeons and the endless
Abyss, duel each other, collect summon companions and TCG cards, join guilds, gamble, and play
minigames.

## 2. Bot instances (tenants)

| Instance | Prefix | Personality | Status (instances/*/botConfig.json) |
|---|---|---|---|
| Joker | `.j` | Persona 5 Phantom-Thieves leader; terse, ≤2 sentences | enabled |
| Jake | `.jk` | Jake the Dog (Adventure Time); warm older-brother | enabled |
| Subaru | `.s` | Re:Zero Subaru; loud, dramatic, hides "Return by Death" | enabled |
| Esdeath | `.e` | General Esdeath; cold commander | disabled |
| Goten | `.g` | DBZ Goten; casual teen | disabled |

Personality matters for lore drops: NPC one-liners must be **bot-agnostic** (they appear under
whichever prefix the player uses) — written as *NPC quotes*, never in the bot persona's voice.

## 3. Architecture sketch (verified)

```
WhatsApp ⇄ Baileys (index.js) ⇄ core/engine.js  (message router, ~27k lines)
                                   ├─ core/rpg/*      52 subsystem modules
                                   ├─ core/models/*   Mongoose schemas (strict mode!)
                                   ├─ core/utils/goImageService.js  → HTTP → Go service
                                   └─ core/chat/*     Groq AI context engine
Go service (Bot_genaration, gin, :7860)
   ├─ /api/combat, /api/combat/endscreen      battle scenes (baked decree art)
   ├─ /api/cards/portrait                      600×1000 family + styled kinds
   ├─ /api/cards/economy, /api/cards/transaction  money & craft cards 1000×600
   ├─ /api/cards/profile                       Node-composited profile (bg_<style>)
   └─ … grids, GIFs, boards, hunt, splash
```

- Multi-tenancy via **AsyncLocalStorage** (`botConfig.js`) resolving the active tenant.
- JID normalization is centralized (`lidResolver.js`, `economy.resolveJidHelper`).
- In-memory `gameStates` Map for active dungeon/PvP sessions; abyss runs persist in `AbyssRun`.
- **Mongoose strict mode** strips undeclared fields on save — any new persisted field must be
  declared in `core/models/*.js` in the same change (rule 40 of the house onboarding).

## 4. Progression (verified, exact)

- **XP curve:** cumulative `200·L²` (`getXPForLevel`, progression.js:198-210); MAX_LEVEL 100;
  tiered milestone multipliers ×1.2/1.3/1.5/1.8 at 10/25/50/75.
- **Real progression store:** `user.progression.{xp,level,gp,totalGP,statPoints,totalXPEarned,…}`
  (User.js:147-176). `user.stats.xp/level` are legacy.
- **Adventurer rank ladder:** F, E, D, C, B, A, S, SS, SSS, **GOD** (`ADVENTURER_RANKS`,
  classSystem.js:999-1050; each has level/questsCompleted/gp requirements; GOD = L100/1000q/25000gp).
- **Rank-up missions:** 4 gates (classSystem.js:1071-1127): Trial of Combat (D→C), Mastery (B→A),
  Legend (S→SS), **Trial of Divinity (SSS→GOD)**. Progress reads `user.stats.*` via
  `checkMissionProgress`. Promotion never downgrades (economy.js:1516-1599).
- **Persistent HP/Energy:** `user.stats.currentHP` (-1 sentinel = uninitialized),
  `currentEnergy` + `energyTs` with 6h regen — carried into adventure/PvP combat.

## 5. Combat surfaces

- **PvE dungeons:** `guildAdventure.js` `DUNGEON_RANKS` F→SSS + special DRAGON + GOD
  ("The Boundless Void"). Party-based, voting, crossroads branching every 3rd stage,
  Groq-AI victory narration with 6 fallbacks (`endAdventure` ~8168).
- **Abyss:** endless procedural floors (abyssSystem.js), 5 floor-advancing handlers all funnel
  to `startAbyssCombat`; pack fights (35% on floors ≥5, adds at 55% stats); wild summons 10%;
  treasure 20%; events 10% (TRAP/CROSSROADS/SHRINE); auto-retreat after 30 min idle; 12h cooldown.
- **PvP:** duels + summon-mode duels (pvpSystem.js), stakes, flee penalties; `pvpWins/pvpLosses`.
- **Kill accounting (exact fields, User.js):**
  - `user.stats.kills` (:75) — every PvE/Abyss kill via `economy.trackMissionStat` (economy.js:1732-1746)
  - `user.stats.bossesDefeated` (:70) — rank-gated to bosses within 2 ranks (guildAdventure.js:5727-5745)
  - `user.stats.dragonsKilled` (:71), `user.stats.undeadKills` (:74), `questsWon/Completed/Failed`,
    `pvpWins/pvpLosses`, `tamingProgress` map (per-enemyType kills)
  - **Do NOT exist:** per-kill "soul" records, deaths counter, bossKills-by-name, kill breakdown
    PvE-vs-PvP-vs-Abyss. (PvP wins are NOT kills.) → see implementation/afterlife.md.

## 6. Economy & items

- Zeni wallet/bank with clamps (2B / 10B), transfers, daily, rob, loans, stock market, premium.
- Crafting families with station gates: CRAFT/BREW/COOK/FORGE/FISH recipes
  (craftingSystem.js:362-500) + 8 legacy recipes (rpgCommands.js:1105-1197).
- Runes: socket/fuse/remove/destroy/buy/market (engine.js:19030-19360; runeSystem.js).
- Durability + repair at the **blacksmith** (a service, not a character — repairCommands.js).
- Inventory/equipment with per-item durability bars (inventorySystem.js:627-700).

## 7. Social systems

- Guilds (charter card, emblem upload with isolated sharp worker, buildings, wars, perks).
- Interaction tracker (`interactionTracker.js`): tags/mentions/replies per pair, relative-bond
  ship scores, `.j bond` history card.
- Bounties, marriages/social (socialSystem.js), TCG card game (35K cards, LFS `cards_data.json`).

## 8. AI/narration precedents

- Groq-powered victory narration (`endAdventure`), AI chat context engine with strict
  "no unsolicited lore" directives (engine.js:3400, 3607) — **the bot persona is explicitly
  forbidden from inventing lore mid-chat**, which is exactly why short *NPC-quoted* lore drops
  are a good fit: they are content, not persona riffing.
- Existing flavor precedents to imitate (format + rate):
  - rotating menu `TIPS` array, engine.js:5469-5515 (`💡 *Tip:* …`)
  - "HIVE MIND WHISPERS" — 5% chance combat one-liners, guildAdventure.js:7313-7327
  - boss `flavorTexts` map → boss card caption, guildAdventure.js:7649-7666

## 9. What this design pass must NOT break

- `.j lore` (loreContent.js) — frozen by brief.
- The 10-style card identity and battle-exempt baked cards (see existing_card_system.md).
- Mongoose strict-mode schema discipline.
- The sibling-prefix guard, engine.js catch-block `_cmdContext` rule, and other engine
  invariants documented in the owner's onboarding.
