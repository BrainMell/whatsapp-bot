#!/usr/bin/env python3.13
"""world_maps2.py — render the three cosmology concepts x 3 reveal states.
Replaces ALL previous world_map concept renders."""
import os, shutil, cairosvg, sys
sys.path.insert(0, "/home/z/my-project/scripts")
from wm2_concepts import build_A, build_B, build_C

BASE = "/home/z/my-project/download/rpg_worldbuilding_design_pass/world_map"

# wipe old concepts (keep dir)
if os.path.isdir(BASE):
    for d in os.listdir(BASE):
        p = os.path.join(BASE, d)
        shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
os.makedirs(BASE, exist_ok=True)

JOBS = {
    "concept_A_sundered_wheel": (build_A, ["wheel"]),
    "concept_B_sea_of_worlds":  (build_B, ["sea"]),
    "concept_C_woven_pillar":   (build_C, ["column"]),
}

for slug, (fn, names) in JOBS.items():
    d = os.path.join(BASE, slug)
    os.makedirs(d, exist_ok=True)
    for state in ("early", "mid", "late"):
        svg = fn(state)
        out = os.path.join(d, f"{names[0]}_map_{state}.png")
        cairosvg.svg2png(bytestring=svg.encode(), write_to=out,
                         output_width=1000, output_height=1400)
        print("ok", os.path.relpath(out, "/home/z/my-project/download"), os.path.getsize(out))
