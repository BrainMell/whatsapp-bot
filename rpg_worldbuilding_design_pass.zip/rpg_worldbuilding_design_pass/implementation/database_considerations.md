# Implementation — Database Considerations (design-only)

> Verified rule base: investigation/architecture_notes.md §7. Mongoose strict mode silently
> strips undeclared fields on save() — every field below must be declared in the SAME commit
> as the code that writes it (this bit the project 4× historically).

## 1. Everything the proposed features would persist

| Feature | Field | Type & default | Writes | Reads |
|---|---|---|---|---|
| `.j world` | `User.worldMap.mode` | String enum early/mid/late, "early" | lazily on first render + promotion triggers | every `.j world` |
| `.j world` | `User.worldMap.discoveries` | [String], [] | on unlock triggers | every `.j world` |
| `.j world` | `User.worldMap.firstChartedAt` | Date, null | first render | stats/flavor |
| Souls | `User.stats.soulsSent` | Number, 0 (or backfill = kills) | increment inside `recordEnemyKill` (guildAdventure.js:5675-5808) — the single PvE/Abyss choke point | `.j souls` |
| Souls (v2, optional) | `User.stats.soulsByRank` | Mixed {} | same site, key = enemy rank letter | `.j souls` by-rank rows |
| Souls | `User.stats.sightUnlockedAt` | Date, null | first unlock ceremony | ceremony-once guard |
| Lore drops | **nothing** | in-memory Maps only (cooldowns, rings) | — | — |
| NPC cards | **nothing** (v1 fixed cast) | — | — | — |

Sizing sanity: `User` doc growth ≤ ~200 bytes/player worst case; `soulsByRank` ≤ 10 keys.
No indexes needed (all access is by the user doc `_id` already loaded).

## 2. What deliberately requires NO database change

- Lore drops: probability gates, cooldowns, recent-rings are in-memory (Maps + lazy prune) —
  losing them on restart is harmless (a drop might repeat once after a reboot; acceptable).
- Encounter-category routing: `AbyssRun.currentEncounterType/Data` (Mixed) already persists it.
- Map mode derivation: computed from existing fields (level/rank/floor) then cached on the doc.
- NPC art selection: seed = userId hash + week number — no state.

## 3. Collections touched: exactly one (`users` via the User model)

No new collections. No migrations (additive fields, lazy init — the house pattern of
`stats.currentHP = -1` sentinel). The `systems` collection (plural!) is untouched.

## 4. Write-path discipline

- All increments go through existing helpers (`economy.trackMissionStat` auto-persists any
  `user.stats.*` key) or copy-on-write object replacement for Mixed maps
  (`interactionTracker.js` precedent) so Mongoose change detection fires.
- Batch-friendly: map-state promotion writes at most once per player per trigger event.

## 5. Backup discipline (for implementation day)

Before any User-schema deploy: `.before_souls` snapshot guidance per house rule 10 —
`db.users.find({}, {stats:1}).toArray()` dump or a targeted `mongodump --collection=users` —
cheap insurance, consistent with the cards_data.json backup precedent.

## 6. Explicit non-goals

- No per-kill event log (a "book of the slain" collection) — flagged in additional_ideas as
  EXPERIMENTAL; rejected for v1 because unbounded growth on a Free-tier cluster is exactly the
  wrong trade for flavor.
- No worldMap per-node timestamps (keep `firstChartedAt` only).
- No changes to `cards_data.json`, AbyssRun, or systems.
