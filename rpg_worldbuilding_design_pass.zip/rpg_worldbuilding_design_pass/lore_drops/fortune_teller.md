# Lore Drops — Fortune Teller / Soul Reader (the one who sees the souls)

> Pool for the future soul-sight character (`.j seer`-style interaction, §19/§20 of the brief)
> and for rare appearances in any surface once implemented. Format contract: rendered as
> `╒ *line* ╛`, italics on the text only.

## Usage notes

- This is a DEFINED character voice (unlike the anonymous smith): a fortune teller / mystic who
  performs the soul-perception spell. Identity options (witch, teller, blind mystic) are kept
  deliberately ambiguous in most lines so the owner can cast the character later; three lines
  are identity-specific variants and marked.
- Three registers, clearly separated: (A) everyday fortune readings, (B) the soul-sight moment,
  (C) afterlife/soul knowledge. Register B lines are the §19 "first time" candidates.

## Pool A — everyday fortune readings (before souls are ever mentioned)

1. ╒ *Cross my palm— no. Not that one. The other. That hand has thrown dice at fate too recently.* ╛
2. ╒ *Your cards came up the Tower, the Road, and the Mirror. Relax. Half my decks are just furniture.* ╛
3. ╒ *I see a tall dark stranger. …No, I see a short rude one. The cards are arguing. Come back Tuesday.* ╛
4. ╒ *The stars say you'll live. The stars haven't been wrong. They've been VAGUE.* ╛
5. ╒ *Luck isn't a wheel, it's a stray cat. Feed it and it stays a while. You've been feeding it, hmm.* ╛
6. ╒ *You want to know WHEN. Everyone wants to know when. The cards only know whether the door is locked.* ╛
7. ╒ *Aurora in your cup, storm at the rim. You drink too fast, and the world agrees with you. That's your whole future.* ╛
8. ╒ *For three coins I'll tell your fortune. For seven I'll tell it honestly. Your choice, adventurer.* ╛
9. ╒ *(identity variant — witch) The cards like a warm fire, and so do I. Sit. The dead don't mind waiting, but the living should learn to.* ╛
10. ╒ *(identity variant — blind mystic) I read the room by its echoes. Yours are… tidy. Suspiciously tidy. Who have you been fighting?* ╛
11. ╒ *(identity variant — market teller) The veil parts for no one's schedule, dear. But for three coins it'll peek.* ╛

## Pool B — the soul-sight moment (first time the player can see souls)

12. ╒ *You're finally strong enough to see them. Sit down first. Everyone thinks they won't need to.* ╛
13. ╒ *Are you certain you want to know how many you've sent beyond the veil? …Very well. Hold my hand. Count with me.* ╛
14. ╒ *The spell is old and it doesn't soften. What you see cannot be unseen. Breathe at the THIRD bell, not the first.* ╛
15. ╒ *Weak minds shatter looking backward at what they've done. Yours held. That says more than the number does.* ╛
16. ╒ *Every adventurer asks me to lie about the count. I refuse, and then I offer tea. You'll want the tea.* ╛
17. ╒ *Don't flinch when they look back. They always look back. They're not angry. They're just… surprised it was you.* ╛
18. ╒ *The first time is loud. The hundredth time is quiet. I'm sorry for both, in that order.* ╛

## Pool C — afterlife / soul knowledge (ongoing drops)

19. ╒ *You've sent quite a few souls my way lately. Business is good. I'd rather it weren't.* ╛
20. ╒ *Some souls don't stay where they're supposed to. If you meet a wanderer who feels like a place more than a person — be polite. And keep walking.* ╛
21. ╒ *I've seen warriors arrive here from worlds you've never heard of. They tell the same stories with different names. Every time.* ╛
22. ╒ *It's becoming rather crowded beyond the veil. Whatever is stirring down deep in the Abyss — it isn't only your world doing the sending.* ╛
23. ╒ *Souls keep their favorite year, you know. Most pick something small. A kitchen. A rain. Nobody picks the treasure.* ╛
24. ╒ *The newly dead always ask the same three questions: did it matter, who won, and who's watching my dog. In that order, always.* ╛
25. ╒ *I can tell a monster's soul from a person's by the weight. You'd be surprised how often the monster's is lighter.* ╛
26. ╒ *Gods arrive like weather. Don't gawk. Offer tea. They're mostly embarrassed.* ╛
27. ╒ *Do not bargain with whatever answers when you knock on the veil. I answer FOR it. That's the whole arrangement. Three coins.* ╛

## Pool — PROPOSED / NEEDS REVIEW (abyss-soul connection, §22 of the brief — not canon)

28. ╒ *The souls that come from the Abyss are… different. They arrive sideways, as if the road to here bends around somewhere else.* ╛
29. ╒ *A soul cut loose below floor ninety hums in a chord. I don't cast for those. The veil is thin enough there already.* ╛
30. ╒ *Sometimes two of the same soul arrive from different deeps, hours apart. Same person. Neither knows. I seat them far from each other. It's kinder.* ╛
