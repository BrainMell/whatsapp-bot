# Existing Commands — Drop-Surface & Progression Reference

> Verified dispatch sites (engine.js @ `31be194f`). Prefix shown as `.j` but identical handlers
> run for every tenant prefix.

---

## 1. Command surfaces where NPC lore drops could attach

Each row = a place a one-line `╒ *NPC quote* ╛` could append to the reply. All sites verified.

| # | Command(s) | Dispatch | Handler | Reply text composed | Card? |
|---|---|---|---|---|---|
| 1 | `.j craft [id]` (covers brew/cook/forge via `craftItem`) | engine.js:10059 | rpgCommands.js:767 → craftingSystem.performCraft:586 | `result.message` built craftingSystem.js:713-717; caption rpgCommands.js:826, text fallback :834 | CRAFT/BREW/COOK/FORGE (generateTransactionCard, rpgCommands.js:806-821) |
| 2 | legacy craft path | engine.js:10059 (--available) | rpgCommands.js:1199 | `confirmMsg` rpgCommands.js:1375-1385, caption :1388 | CRAFT hard-coded :1358-1371 |
| 3 | `.j brew <id>` / `.j cook <id>` | engine.js:10093/10112 | rpgCommands.js:840-841 (→ craftItem) | same as #1 | BREW/COOK |
| 4 | `.j forge <id>` | engine.js:10100 | rpgCommands.js:842 (→ craftItem) | same as #1 | FORGE |
| 5 | `.j blacksmith` | engine.js:8610 | repairCommands.js:30 displayBlacksmith | `msg` :34-71 | none |
| 6 | `.j repair <slot/#/all>` | engine.js:8616 | repairCommands.js:77 | `successMsg` :118-122 / :170-174 | none |
| 7 | `.j inspect <item>` | engine.js:8625 | repairCommands.js:180 | durability report | none |
| 8 | `.j rune socket/fuse/…` | engine.js:19030 | runeSystem.js socketRune:687 etc. | engine.js:19277/19294/19314; runeSystem.js:739/:663/:831/:848 | none |
| 9 | `.j heal` / `.j hospital` / `.j clinic` | engine.js:9955 | inline :9953-9995 | hard-coded :9967/:9985/:9990 | none |
| 10 | `.j buy <#>` | engine.js:9247 | shopCommands.js:311 | success :446-448 | none |
| 11 | `.j sell` | engine.js:12700 | rpgCommands.js:507 | `msg` :527-537 | none |
| 12 | `.j shop` | engine.js:9240 | shopCommands.js:164 | `msg` :182-302 | none |
| 13 | `.j balance` | engine.js:25168 | inline | **caption near-empty** `💰 *nickname*` :25226 | BALANCE card :25209 |
| 14 | `.j transfer` | engine.js:25444 | economy.js:1000 | message economy.js:1069-1078; caption engine.js:25514 | TRANSFER :25501 |
| 15 | `.j deposit` / `.j withdraw` | engine.js:25604/25694 | economy.js:1089/withdraw | economy.js:1149/1238; captions 25675/25769 | DEPOSIT/WITHDRAW |
| 16 | `.j abyss …` | various | abyssSystem.js | start :257-271; victory guildAdventure.js:6330-6362; treasure 519-607; events 648-734; death 778-784 | ABYSS_ENTRY/ABYSS_RESULT |
| 17 | dungeon victory | — | guildAdventure.js endAdventure:8168 | Groq narration + FINAL STATS :8240-8251 | end screens |
| 18 | `.j kill report`-type stats | (via .j stats/progression) | progressionCommands.js | stats render ~321-411 | RANK card |

**Best minimal-attachment points** (one edit covers many commands): #1 (craft family —
single caption builder), #13/#14/#15 (money-card captions are currently near-empty),
#5/#6 (blacksmith), #16 (abyss victory/collect).

## 2. Existing flavor precedents (the house pattern for random one-liners)

| Pattern | Site | Mechanic |
|---|---|---|
| Rotating menu tips | engine.js:5469-5515 | static `TIPS` array, uniform random, `💡 *Tip:* …` appended |
| HIVE MIND WHISPERS | guildAdventure.js:7313-7327 | **5% chance** per combat, picks from array, italic whisper line |
| Boss flavor captions | guildAdventure.js:7649-7666, raidSystem.js:37-70 | per-boss flavorTexts map → card caption |
| Groq narration | endAdventure:8174-8205 | AI victory narration, 6 deterministic fallbacks |

These give three ready-made shapes for lore drops: **(a)** array + uniform pick,
**(b)** array + probability gate, **(c)** context-keyed map. The proposal in
`implementation/lore_drop_system.md` uses (b) with per-category cooldowns.

## 3. Abyss & dungeon command surface

- `.j abyss enter/choose/collect/skip/resume/retreat` → abyssSystem.js; all five floor-advancers
  funnel through `startAbyssCombat` (guildAdventure.js:6031).
- Encounter composition is **pure data** (`generateFloorEncounter` :282-347; treasures :359-406;
  events :414-454) → Abyss lore drops can slot in as new encounter metadata + a small
  render-time pick, **no schema change required** (`AbyssRun.currentEncounterData` is Mixed).
- Encounter category is known at render time: `combat` / `wild_summon` / `treasure` / `event`
  (+ boss flag, + pack flag) → category-specific lore pools are directly feasible
  (`abyss_unknown_creature`, `abyss_player`, `abyss_distorted_player`, `abyss_timeline_person`,
  `abyss_self_variant`).

## 4. Kill statistics — exact wiring (for the Afterlife/souls feature)

| Stat | Field | Increment site | Notes |
|---|---|---|---|
| Any kill | `user.stats.kills` (User.js:75) | guildAdventure.js:5797-5798 via `economy.trackMissionStat` (economy.js:1732-1746); Abyss: 6224 | every PvE/Abyss kill, all party members |
| Boss kill | `user.stats.bossesDefeated` (User.js:70) | guildAdventure.js:5744 (rank-gated ±2), Abyss :6225 | rank-mission stat |
| Dragons | `user.stats.dragonsKilled` (:71) | :5802-5805 `incrementDragonKills` economy.js:1781 | |
| Undead | `user.stats.undeadKills` (:74) | :5806-5808 | |
| PvP | `user.pvpWins/pvpLosses` (:40-41) | pvpSystem.js:1834/1186/1857 | NOT kills |
| Per-type | `user.tamingProgress` Map (:240) | tame-at-10 system | per-enemyType kill counts already aggregated! |

- `trackMissionStat` auto-persists **any** `user.stats.*` key → a future `user.stats.soulsSent`
  needs zero new write infrastructure (still must be declared in User.js per strict mode).
- Rank missions read `user.stats` directly (classSystem.js:1181-1199) → souls could gate a
  mission objective later.
- **No deaths counter, no kill-by-enemy-rank breakdown** — "souls by tier" would need either a
  new increment site at `recordEnemyKill` (guildAdventure.js:5675) or a `soulsByRank` Mixed map.

## 5. Level/rank gate precedents (house pattern for the soul-sight requirement)

1. Abyss entry: `level < 20` rejection — engine.js:19682-19684 ("❌ You need to be at least
   level 20 to enter the Abyss.\n_Current level: X_").
2. Raid join: level 20 — engine.js:20184. 3. Bounty target: bountySystem.js:53.
4. GOD dungeon: rank gate + **lore-flavored rejection** — guildAdventure.js:6838-6841 ("THE
   BOUNDLESS VOID REJECTS YOU…"). This is the pattern a "sight" gate should copy: a mystical
   refusal, not a UI error.

## 6. Commands that must remain untouched

- `.j lore` / `.jlore` / bare `.lore` (loreContent.js + election) — frozen by brief.
- Nothing in this pass modifies any command. Implementation docs only *propose* attach points.
