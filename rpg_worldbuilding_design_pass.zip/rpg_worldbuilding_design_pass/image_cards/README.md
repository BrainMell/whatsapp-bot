# Image Cards — README (REWORKED)

> OWNER REVIEW PASS 2 decisions applied here:
> 1. **No AI-generated imagery anywhere.** Art windows hold either **researched online
>    assets** (see `assets/researched/SOURCES_manifest.json`) or a labeled **art slot**
>    placeholder pointing at the research.
> 2. **Lore text is never baked into cards.** The `lore_drop_line` element was removed
>    from the card kit. Lore drops are occasional plain chat text (`lore_drops/`).
> 3. **Abyss encounters are NOT image cards.** They render through the existing encounter
>    pipeline with the right enemy sprite + ability set. See `image_cards/world/` for the
>    two parity mockups and `implementation/abyss.md`.

## What's here

| Folder | Cards | Art policy |
|---|---|---|
| `blacksmith/` | v1 decree · v2 stonekeep · v3 ledger-split | v1/v2: **Snabisch's free NPC pack (OGA-BY 3.0)** — chibi/cartoon style, flagged as a style-fit discussion (better for popup/dialog art); v3: **Blarumyrran's dwarf (CC-BY/OGA-BY 3.0)** — 63×85 pixel sprite, NEAREST-upscaled, closest to the bot's 64×96 enemy format |
| `brewing/` | still room (landscape) · crooked cauldron | labeled **art slots** — candidates listed in `assets/README.md` leads |
| `fortune_teller/` | souls locked · souls unlocked · seer (Soul Forge variant) | labeled **art slots** |
| `afterlife/` | shoreline · great ledger | labeled **art slots** (the realm stays deliberately unillustrated in canon terms — "not charted") |
| `world/` | world card (ships the concept-A map) · **2 abyss-encounter parity mockups** | world card uses the new wheel map; encounter mockups use the **bot's own kobold sprite** (internal reference copy in `assets/researched/enemies/bot_reference/`) |
| `alternatives/` | smith ribbon variant · text-only info card | same policy; the text-only card demonstrates features that need no art at all |

## Card kit changes (`scripts/card_kit.py`)

- `lore_drop_line()` **removed** — cards end at caption/footer as before pass 1.
- `art_placeholder()` added — hatched slot with a pointer to the asset research, so no
  mockup pretends to have final art.
- `pixel_art_window()` added (in `cards.py`) — NEAREST-upscales small pixel sprites and
  clips them to the art window, preserving crisp pixels.

## Style-fit warning (honest note)

The downloaded NPC pack is **chibi vector-cartoon**, not pixel art. It demonstrates the
card chrome correctly, but for in-card NPC portraits the better fits are the pixel-art
packs in `assets/researched/` (dwarf, witch strips, enemy sheets) or the leads listed in
`assets/README.md`. Nothing here has been shipped to the bot — this is a review package.
