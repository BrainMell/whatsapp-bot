# Assets — research, sources & licenses (REWORKED)

> OWNER REVIEW PASS 2: **no AI-generated imagery.** The first pass's 22 AI renders were
> removed from the package. Everything below was **found online**, downloaded from the
> source, and verified (file signature + license statement on the source page).

## Researched & downloaded (`assets/researched/`)

Machine-readable manifest: `SOURCES_manifest.json` (category, title, license, author,
source URL, files).

| Category | Asset | License | Source (OpenGameArt content page) | Style fit for the bot |
|---|---|---|---|---|
| npc | NPC Character Pack — Blacksmith / Jeweler / Sage / Warlord (921 animated PNGs + popup art) | **OGA-BY 3.0** | `/content/npc-character-pack` (by Snabisch) | chibi cartoon — great for popup/dialog art; NOT pixel style |
| witch | 5-Direction Witch Walking Sprite | CC-BY 3.0 / CC-BY-SA 3.0 | `/content/5-direction-witch-walking-sprite` | small strip, classic pixel |
| witch | Animated Sorcerer Witch | CC-BY 3.0 (Snabisch) | `/content/animated-sorcerer-witch` | small strip, classic pixel |
| witch | Dark Elf Pixel Art Witch Character (faces) | **OGA-BY 3.0** | `/content/dark-elf-pixel-art-witch-character` | portrait frames |
| elf | Dark Elf Character (faces) | **OGA-BY 3.0** | `/content/dark-elf-character` | portrait frames |
| dwarf | "Dwarf!" (pakapikk lineage, Blarumyrran) | CC-BY 3.0 / OGA-BY 3.0 | `/content/dwarf` | **63×85 — near-exact fit for the bot's 64×96 enemy sprite format** |
| enemies | 10 Basic RPG Enemies | CC-BY 3.0 / OGA-BY 3.0 (LFA) | `/content/10-basic-rpg-enemies` | small pixel critters |
| enemies | 10 Fantasy RPG Enemies | CC-BY 3.0 / CC-BY-SA 3.0 / GPL 3.0 | `/content/10-fantasy-rpg-enemies` | mixed sheet |
| enemies | bot reference sprites (kobold / goblin / skeleton) | bot's own assets (internal reference copies) | `core/rpgasset/enemies/` | the target style |
| environment | Dungeon Tileset | CC0 / OGA-BY (FuzzyWuzzie) | `/content/dungeon-tileset` | tiles + enemy mage |
| abyss_flavor | 1-Bit Doomsphere Charset (340 files + License.txt) | **CC0** (surt) | `/content/1-bit-doomsphere-charset` | 1-bit charset, usable as abyss flavor sprites |
| npc | Tiny 32 Complete Spritesheet Repack | **CC0** (Lanea Zimmerman / Sharm) | `/content/tiny-16-basic` | 16/32px universal characters & tiles |

License compliance summary: OGA-BY 3.0 & CC-BY 3.0 require **attribution** (keep the
manifest entry + author in any shipped credits); CC-BY-SA 3.0 additionally share-alike;
CC0/public-domain items have no strings. **Nothing in this package is shipped to the bot
yet** — attribution wiring is listed in `implementation/` when assets get promoted.

## Leads (real packs, could not auto-download — manual pickup)

- **Kenney** — https://kenney.nl/assets (everything **CC0**; 1-Bit Pack and Pixel Platformer
  fit the decree-adjacent look). Site serves zips via JS; grab manually.
- **CraftPix free packs** — witch sprite sheets, demon characters, gnoll pack
  (free tier requires account login; license = CraftPix free license, no resale).
- **itch.io free pixel packs** — e.g. https://itch.io/game-assets/free/tag-elf/tag-pixel-art
  (per-pack licenses, mostly CC0/CC-BY; download manually per pack page).
- **Universal LPC Sprite Sheet Character Generator** (LiberatedPixelCup, CC-BY-SA 3.0) —
  generates dwarf/elf/whatever character sheets; check license compatibility (SA) before use.

## What each brief category still needs

- **fortune teller / soothsayer**: no exact free match found yet — best leads: CraftPix
  "Gorgon"/mystic free packs, LPC generator (soothsayer outfit), or commission-style
  pickup from itch. Art slots in the fortune-teller cards point here.
- **brewing/cauldron scene**: CraftPix witch cauldron pack (lead) or crop from witch strips.
- **backgrounds**: existing bot backgrounds remain canonical; the dungeon tileset above can
  extend them. Old AI backgrounds removed.

## Fonts & UI (`assets/ui/`)

Unchanged from pass 1: Cinzel / CinzelDecBold / MedievalSharp / IM Fell — these are
**references copied from the bot repos** (already used by the card system), not new assets.
