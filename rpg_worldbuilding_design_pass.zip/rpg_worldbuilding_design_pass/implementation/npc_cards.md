# Implementation — NPC Cards (design-only)

> Mockups: `image_cards/{blacksmith,brewing,fortune_teller}/`. Asset reality: there are NO race
> NPCs in the game today (verified — investigation/existing_lore.md §8). This doc covers how a
> card-level NPC presence could work WITHOUT new mechanics, per brief §11/§12.

## 1. Principle — characters appear, systems don't change

The dwarf in the forge card is presentation, exactly like the existing quest/guild cards'
scene windows. Zero new commands, zero NPC state, zero dialog trees. The ONLY new moving part
is: (a) art selection, (b) a `speaker` field in payloads so the drop pool can match the face.

## 2. Character selection

Two viable models:

| Model | How | When |
|---|---|---|
| **Fixed cast** (recommended v1) | each flow owns one NPC: forge→dwarf smith, still room→elf brewer, cauldron→witch, sight→the reader | deterministic art, players bond with a face |
| Rotating bench | payload picks from 2-3 portraits per flow (seeded by userId hash, stable per week) | after the first pass lands; adds "the other smith" variety without code churn |

Seeding rule if rotating: `idx = (userIdHash + weekNumber) % cast.length` — stable within a
week so the same face answers twice in a session (characters must feel like people, not dice).

## 3. Asset selection & pipeline

- Source art (OWNER PASS 2 — no AI art): researched online packs under
  `assets/researched/` (sources + licenses in `SOURCES_manifest.json`), with labeled art
  slots where a category lacks a confirmed pack (leads in `assets/README.md`). Crop to the
  art-window ratio (490×352 for the portrait window at (55,208)-(545,560)); small pixel
  sprites upscale with NEAREST (`pixel_art_window()` in scripts/cards.py).
- Production pipeline would copy finals into `Bot_genaration/assets/rpgasset/npcs/`
  (new folder, mirrored in the bot repo if Node-side canvas ever needs them), then the Go
  service needs `pm2 restart` after new files (in-memory image cache rule).
- Licensing per asset_sources/sources_and_licenses.md before anything ships.

## 4. Card composition (what the mockups encode)

- Banner: the PLACE ("THE FORGE", "THE STILL ROOM"), not the person — people appear in the art
  window + nameplate. This keeps banner text consistent with the existing family
  (`themeBannerFor` uses function names today; NPC cards add place names).
- Nameplate: NPC name + role ("BALIN STONEHEW · SMITH") — the only place a character is named.
- Result panel: unchanged flow output (repair rows, brew result) — the NPC never replaces data.
- Lore drop: bottom line in `╒ *…* ╛` (see lore_drop_system.md) — the character "speaks" only
  there, which keeps dialogue rare by construction (10%-gated).
- Caption: flow's old text (house rule image-first).

## 5. Style compatibility

v1 ships NPC cards as **baked decree-family** (like CRAFT/BREW today): one look for everyone,
zero per-style work, zero risk to the 10-style QA matrix. The mockups include a Stonekeep
variant and a Soul Forge variant to show what per-style would look like IF the owner later
wants NPC cards inside `styledKinds()` — that decision adds 9 compositions per NPC flow and
should be priced accordingly (the styleqa matrix grows 162 → 162+9×flows).

## 6. Where each NPC card attaches (same sites as the drops)

| NPC | Card kind | Attach point | Canvas |
|---|---|---|---|
| Dwarf smith | `FORGE_RESULT` / repair card | repairCommands success (text-only today → gains card + caption) | 600×1000 |
| Elf brewer / witch | reuses live `BREW`/`COOK` kinds with an NPC art window added | existing card calls rpgCommands.js:806-821 (payload gains `npcArt`) | 1000×600 |
| The reader | `SOULS` (new) | soul-sight feature (implementation/afterlife.md) | 600×1000 |
| Abyss encounters | **NO image cards** (owner pass 2) — existing encounter renderer: sprite + ability rows + kill hooks | — (no new surface) | existing |

Adding `npcArt` (a file basename) to `portraitRequest` is the only Go-side change; renderers
draw it through the existing art-window helper. Missing file → skip window gracefully (never
fail the card).
