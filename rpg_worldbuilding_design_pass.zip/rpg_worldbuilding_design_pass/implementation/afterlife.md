# Implementation — Afterlife & Soul Statistics (design-only)

> Brief §17-§22. Pools: `lore_drops/afterlife.md` + `fortune_teller.md` pools B/C.
> Mockups: `image_cards/fortune_teller/souls_card_{locked,unlocked}.png`,
> `image_cards/afterlife/`. Verified wiring: investigation/existing_commands.md §4.

## 1. The concept in one line

Kills are already counted (`user.stats.kills`); the Afterlife feature RE-FRAMES them —
"these are souls you sent beyond the veil" — and gates the *seeing* behind progression +
the soul reader character.

## 2. Kill tracking today (verified, exact)

- Every PvE/Abyss kill: `economy.trackMissionStat(jid, 'kills', 1)` at guildAdventure.js:5797
  (all party members) and :6224 (Abyss), via economy.js:1732-1746 which does
  `user.stats[statKey] = (user.stats[statKey] || 0) + val` + save.
- Bosses: `bossesDefeated` (rank-gated ±2 ranks, :5744). Dragons/undead: dedicated counters.
- PvP: `pvpWins/pvpLosses` only — PvP does NOT touch `kills`.
- Per-enemyType counts already aggregated on `user.tamingProgress` (taming system).

## 3. What would need to exist (none of it exists — verified)

| Piece | Proposal |
|---|---|
| `user.stats.soulsSent` | mirrors `kills` 1:1 OR backfilled from kills at first sight-cast (owner decision — both one line; see §7) |
| `user.stats.soulsByRank` (Mixed map, rank→count) | optional v2 for the by-rank ledger rows in the unlocked mockup; increment inside `recordEnemyKill` where enemy rank is in scope (guildAdventure.js:5675-5808) |
| sight gate | level ≥ 40 **or** rank ≥ B (owner picks; 40 mirrors nothing existing — level-20 gates are the current house pattern, so 40 reads as "rare") |
| `.j seer` / `.j souls` command | new command → new module `core/rpg/soulSight.js` → `SOULS` card (locked/unlocked payloads) |
| the reader NPC | fortune teller identity (3 concepts delivered); her pools = afterlife.md + fortune_teller.md B/C |
| afterlife realm | NO map anchor, NO name, NO mechanics — only the shoreline on `.j world` late state + the reader's dialogue |

## 4. Command flow (proposed)

```
".j souls" (alias ".j seer")
→ soulSight.handle():
   locked = level<40 && rank<B
   payload = { kind:"SOULS", locked, count: stats.soulsSent||0, byRank: soulsByRank,
               style: user.cardStyle||0, drop: loreDrops.maybeDrop('afterlife', ctx) }
   locked → souls_card_locked mockup layout: three ritual requirements (level 40,
            deep floors, the reader's fee) with the met one checked; drop line = refusal quote
   unlocked → souls_card_unlocked layout: totals + by-rank bars + "from below floor 90" hook
   image FIRST; caption = old text path (plain numbers), null→text fallback
```

First-unlock moment (brief §19): when the gate first passes, the reply uses the ceremony lines
("You're finally strong enough to see them. Sit down first." / "Are you certain you want to
know how many you've sent beyond the veil?") and persists `user.stats.sightUnlockedAt` (one
date field) so the ceremony happens exactly once.

## 5. The restriction as worldbuilding (not UI lock)

- The locked card says WHY in-world: "the spell overwhelms the weak-willed" — requirements are
  framed as ritual preparation (reach level 40 / face the deep floors / pay the reader's fee),
  never as "requires level 40".
- The rejection reuses the Boundless-Void gate's tone (guildAdventure.js:6838): mystical
  refusal, then the factual requirement in small text. UI-lock feel: zero.

## 6. Abyss-souls connection (brief §22 — PROPOSED, NOT CANON)

`lore_drops/afterlife.md` Pool 5 + `fortune_teller.md` Pool marked PROPOSED keep this
separable: souls arriving "sideways" from deep floors, humming in chords, duplicates seated
apart. If canonized later, the only mechanical hook would be `soulsByRank['abyss']` (counting
`currentFloor ≥ 90` kills — data already in scope at the increment site). Nothing else changes.

## 7. Open decisions for the owner (blocking implementation, not design)

1. **Backfill or fresh start?** soulsSent = current kills ("you never realized") vs 0
   ("the sight begins now"). Recommendation: fresh 0 — the count lands harder ceremonially.
2. **PvP kills?** A duel isn't "sent beyond the veil"… or is it? Recommendation: exclude v1.
3. **Gate number:** level 40 vs rank B vs "deep-floor contact" (survived floor 30+).
4. **Seer identity:** witch / market teller / blind mystic (3 art concepts delivered).
5. **Does the reader charge?** The pools joke about "three coins" — a small Zeni fee would be
   flavor-consistent; free is also fine. (Any fee = economy touch = needs owner approval.)

## 8. Schema summary (for implementation/database_considerations.md)

```
User.stats.soulsSent      Number   default 0     (if backfill chosen: init = stats.kills)
User.stats.soulsByRank    Mixed    default {}    (v2, optional)
User.stats.sightUnlockedAt Date    nullable
```
All declared in the same commit that writes them (strict-mode rule 40). No migrations needed
(fields are additive, lazy-initialized).
