# Lore Drops — Enchanting / Runes

> Pool for `.j rune socket`, `.j rune fuse`, `.j rune remove`, `.j rune destroy`, and
> enhance/stone successes. Format contract: rendered as `╒ *line* ╛`, italics on the text only.

## Usage notes

- Speaker implied: the rune-worker / enchanter behind the outcome — or sometimes the rune
  itself, briefly, which the existing soul-rune vocabulary (`SOUL_RIP`) supports.
- Established mechanics this can lean on: socket/slots, fusing, rune ranks, soul-tier runes,
  the DejaVu rune-glyph system on cards. Avoid inventing NEW rune mechanics in dialogue.

## Pool — mundane / warm

1. ╒ *Hold still. Runes settle easier on the brave. Fidget and it costs you a week of luck.* ╛
2. ╒ *Nice clean socket. Whoever drilled this cared. Rare, that.* ╛
3. ╒ *The glyph likes you. They don't always. I've been bitten by a perfectly good protection rune twice.* ╛
4. ╒ *Two of the same fused make one stronger. Three make something else. We don't do threes in this shop.* ╛
5. ╒ *Warm your hands first. Cold palms make skittish enchantments.* ╛
6. ╒ *It's done. Don't polish over it — the shine isn't decoration, it's the seal breathing.* ╛
7. ╒ *Fused it on the first try. You may applaud. The rune won't, it's shy.* ╛

## Pool — funny

8. ╒ *The last customer asked if I could socket 'just a little more power.' I socketed humility. He didn't notice. They never do.* ╛
9. ╒ *Yes, it hums. No, you can't turn it off. It hums loudest when you're lying, so watch yourself.* ╛
10. ╒ *I once destroyed a curse-rune and my hair went white for a month. Worth it. The tips were GREAT.* ╛
11. ╒ *Rune of Fortune, is it? The wheel-spinners downstairs buy those. Me, I'd rather be lucky at dinner than lucky at dice.* ╛

## Pool — mysterious / worldbuilding

12. ╒ *Every rune is a word from before the words. We don't write them. We remember them badly and carve the result.* ╛
13. ╒ *Runes this deep-cut were made before the Infection. The old cuts don't fade. Whatever knew these letters wanted them to last.* ╛
14. ╒ *Some glyphs repeat across every realm. Same mark, same meaning, worlds that never traded a cup of salt. Think about that too long and the torch looks friendly.* ╛
15. ╒ *The soul-runes cost more than the stone they sit in. That's not greed. Something has to hold the shape of a person, and shape-holders are rare.* ╛
16. ╒ *A removed rune doesn't die. It waits in the tray, and it sulks. I've heard them. The tray is lined with felt for a REASON.* ╛
17. ╒ *My master said enchanting is just asking politely with fire. Then he asked something impolitely, once, and we don't keep his chair anymore.* ╛

## Pool — occasionally important

18. ╒ *That glyph isn't from any alphabet I stock. It walked in on the item. It's settled now, harmless — but if it starts to glow when you're near mirrors, come back.* ╛
19. ╒ *The deep runes answer to a rhythm. Abyss-rhythm. You'll hear it in your sleep the first week — a ticking, like water. It passes. Usually.* ╛
20. ╒ *They say the old powers broke into pieces, and the pieces still hold their shapes. Every strong rune is one letter of one of those shapes. I don't carve sets. Never carve a SET.* ╛
