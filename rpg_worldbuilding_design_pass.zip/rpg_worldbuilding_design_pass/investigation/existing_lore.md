# Existing Lore — Established Canon Inventory

> Investigation document. Nothing in the live bot was changed. All references verified against
> `whatsapp-bot` @ `audit/fix-pass-1` commit `31be194f` (plus `Bot_genaration` @ `main` `01ab7e0`).

---

## 1. The `.j lore` command — the canonical creation myth

**Status: UNTOUCHED.** Per the design brief, `.j lore` is frozen. This document only records what it says.

**Location:** `core/rpg/loreContent.js` (27 lines, single static message).
**Served by:** `<prefix> lore`, `<prefix>lore` (e.g. `.j lore`, `.jlore`), and bare `.lore`.
The bare prefix-less `.lore` / `.updates` commands are arbitrated across sibling bots by a
shared-Mongo election (`electOnce()`, collection `shared_command_elections`, 90 s prune,
fail-open) so exactly one bot replies (engine.js dispatch ~11935; see also `.jmode`).

**Full canon text (verbatim structure):**

| Section | Established content |
|---|---|
| **The Era of Duality** | In the beginning there was only the **Divine Architect** and the **Primordial Chaos**. Together they wove the fabric of existence — the Architect providing *structure*, Chaos providing *raw, untamed energy of life*. For eons the realms flourished in perfect, delicate balance. |
| **The Great Envy** | The Chaos was restless. It grew **envious of the Architect's beautiful, ordered creations**. It seeped into the cracks of the world *like dark, viscous ink*, corrupting everything it touched: flowers became thorns, peaceful beasts became monsters, and **living souls were twisted into mindless husks known as The Infected**. |
| **The Divine Spark** | The Architect could not destroy Chaos without destroying the realms themselves. Instead they **shattered their own essence**, bestowing **Divine Sparks** upon a chosen few — **The Adventurers**. |
| **Your Purpose** | Every Adventurer **carries a fragment of that celestial power**. They are the only ones able to enter **the Dungeons — the epicenters of the corruption**. Mission: 1) Defeat the Infected. 2) Cleanse the Dungeons. 3) Face and destroy the **Primordial Evil** lurking at the heart of the void. |

**Register welcome** (short, 493 chars) points new players at `.lore` for the full history —
the lore flow is: `.register` → short welcome → player discovers `.lore` organically.

---

## 2. Naming reconciliation — brief vs. shipped canon

The design brief summarizes the cosmology as "Chaos and Order". The shipped lore text uses
different (older, more evocative) names for the same two poles. **Neither was changed.** The mapping:

| Brief term | Established canon term | Evidence |
|---|---|---|
| "Chaos and Order as primordial beings" | **Primordial Chaos** + **Divine Architect** | loreContent.js §Era of Duality |
| "Order gave creation structure" | "the Architect providing the structure" | same |
| "Chaos created life" | "Chaos providing the raw, untamed energy of life" | same |
| "Chaos became envious and began corrupting creation" | **The Great Envy** — identical beat | same |
| "Order shattered itself" | the Architect "shattered their own essence" | same |
| "Every player carries a fragment/piece of Order" | Adventurers carry a **fragment of celestial power / Divine Spark** | same |
| "Chaos also broke itself into multiple pieces" (future bosses) | **Not yet in any shipped text** — open slot. The brief's piece-bosses can be introduced later without contradicting anything | grep: no match |
| **Kosmion** (working name for the connected worlds) | **Nowhere in code.** Entirely new. No collisions | grep: 0 hits |
| "Abyss is separate from Kosmion, endless, time-different" | Consistent with shipped Abyss lore (below). Time-distortion already canon in the GOD dungeon (Floor 3 "compressed time") | abyssSystem.js:8-16, guildAdventure.js:166 |
| God-Rank world "unnamed, beyond known cosmology" | **The Boundless Void** exists as the GOD-rank *dungeon* — a strong candidate name for the region, but the brief says leave the *world* name open. Treated as "the known doorway", not the finalized world name | guildAdventure.js:150-171 |

⚠️ **Documented contradiction (do not silently resolve):** the brief says "Chaos *created* life"
while the lore says the Architect *and* Chaos *together* wove existence, with Chaos providing the
raw energy. These are compatible readings (Chaos = the life-stuff, Architect = the shaping), and
the recommended posture for new writing is: **never restate the creation order explicitly; let
NPCs speak only of what came after** ("when the Architect still held the pen", "before the ink
seeped"). This sidesteps the contradiction without touching canon.

---

## 3. The Boundless Void — GOD-rank content (already canon)

`core/rpg/guildAdventure.js` `DUNGEON_RANKS.GOD` (lines ~150–171):

- **Name:** "The Boundless Void" — 7 encounters, boss `ABYSSAL_GOD`, pool `DRAGON_LAIR`,
  `requiresGodRank: true`, difficulty 25.0, xpMult 10.0.
- **Entry rejection text (file ~6838):** "❌ *THE BOUNDLESS VOID REJECTS YOU* — You are not yet
  ready. Only a GOD — one who has transcended the very bounds of dimensionality — may **step
  beyond the veil**. … Complete the Trial of Divinity (Mission 4) and reach GOD rank to enter."
- **loreIntro (file ~161):** "You step beyond the veil of dimensionality. Reality unravels
  around you — time flows backward, space folds upon itself, and the very laws of physics dissolve
  into primordial chaos. Here, in the Boundless Void, only those who have transcended the
  boundaries of mortal existence can survive. **You are a GOD. But even gods can die.**"
- **loreFloors 1–7 (file ~162–170) — per-floor narrative, sent each stage:**
  1. "The air itself rejects your presence. Shadows move with intent, whispering secrets that predate creation."
  2. "You encounter **echoes of fallen adventurers** — their last moments replaying eternally. They reach for you, seeking to drag you into their eternal loop."
  3. "The ground beneath you is not ground. It is **compressed time**. Each step costs you a memory. You feel yourself forgetting… something important."
  4. "A figure appears — **it wears your face**, but its eyes are void. It speaks: 'I am what you could have been. What you should have been. The version of you that never compromised.' It attacks."
  5. "The Void itself becomes sentient. It has watched you since the moment of your ascension. It is curious. It is hungry. It is everywhere."
  6. "You find the remnants of a previous god who attempted this journey. Their final message, carved into non-existence: '**The Abyssal God is not a creature. It is a concept. You cannot kill a concept. But you can become one.**'"
  7. "The Abyssal God manifests. It does not speak. It does not need to. It simply IS — the antithesis of existence, the final question with no answer."

**Why this matters for the design pass:**
- **Alternate selves already canon.** GOD-dungeon Floor 4 establishes "a version of you" as an
  enemy. The brief's Abyss "alternate versions of the player" drops therefore *echo* an
  established beat — new pools should reference it obliquely (suspicion, recognition) and never
  explain the mechanism.
- **"Beyond the veil" already means GOD ascension.** The brief wants the Afterlife framed as
  "beyond the veil" too. **Naming collision risk:** see §6.
- **Gods can die / previous gods' remnants** — soft support for the Afterlife holding *god*-souls.

---

## 4. The Abyss — established lore + mechanics

`core/rpg/abyssSystem.js` header (lines 8–16), verbatim summary:

- The Abyss is a **vast underground network of caverns and ruins predating recorded history**.
- **Before the Infection** it was home to natural creatures: cave bats, rats, slimes,
  territorial beasts evolved in darkness.
- The Infection **seeped up from below** and twisted some creatures (Infected Colossus,
  Corrupted Guardian); others remained unchanged, coexisting in strange ecological balance.
- **Deeper floors hold ancient constructs and void-touched entities** that predate even the
  natural life.
- Floor tiers: F(1-2) → C(3-6) → B(7?) → A(11-20) → S(21-49) → SS(50-99) → SSS(100+ …
  header shows ABYSSAL_GOD ≥100, GOD ≥200 in `getFloorTier`, abyssSystem.js:42-52).
- Death keeps 10% of loot, retreat keeps 100%; weekly leaderboard reset (Monday).

**Consistency with the brief:** "endless" ✓ (procedural), "creatures from worlds the player has
never visited" ✓ compatible (void-touched entities "predate natural life" — nothing says they are
*from* the player's world), "different versions of people" — compatible, not yet stated.
The brief's beats can be layered in via encounter lore-drops without touching any text above.

**Mechanical text surfaces (where Abyss lore drops would attach):**
- Run start text: abyssSystem.js:257-271
- Floor-cleared / pack text: guildAdventure.js `handleAbyssVictory` ~6330-6362
- Treasure collect: abyssSystem.js `processTreasure` ~519-607
- Event choice: `processEventChoice` ~648-734; skip: `processSkip` ~737-767
- Death: `processDeath` ~778-784; retreat: ~849-860

---

## 5. Dungeon zone names — the "Afterlife" collision (IMPORTANT)

`core/rpg/guildAdventure.js` `DUNGEON_ENVIRONMENTS` (~lines 290-305) already contains two zones:

| Zone id | Name | Asset | Modifier |
|---|---|---|---|
| `INFECTED_AFTERLIFE` | **"Infected Afterlife"** | spark_1-night.png | CORRUPTION (damage over time), 10% RESURRECTION |
| `PRE_INFECTED_AFTERLIFE` | **"Pre-Infected Afterlife"** | spark_7.png | PURITY_AURA / HOLY_GROUND |

**Read:** in current usage "Afterlife" is an **ecology label** — "the lands *after* the Infection
passed through" (as in "after-life = what survives afterwards"), NOT a realm of the dead.
It is also used in `docs/rpg/quest.md:477-478`.

**Implication for §17 of the brief (new Afterlife realm):** the new realm of the dead needs a
distinct name from day one or players will conflate it with these two existing dungeon zones.
The brief explicitly says the realm's name is **not finalized** — this investigation therefore
recommends provisional *labels* only (e.g. "the Veilward", "the Hush Beyond" — see
`additional_ideas/ideas.md`) and flags the collision so the owner picks with full knowledge.

---

## 6. "Beyond the veil" — language audit

| Where | Meaning today |
|---|---|
| guildAdventure.js GOD rejection (~6840) + loreIntro (~161) | crossing into GOD-tier transcendence (the Boundless Void) |
| `veil_of_the_void` cloak item (lootSystem.js:1610, +10% evasion) | item name only |
| `shield_of_restless_souls` (lootSystem.js:2250) | item name only — "restless souls" flavor already exists |
| Brief §18/§19/§21 (proposed) | the boundary of the Afterlife; souls "sent beyond the veil" |

**Proposed resolution (for review, not implemented):** treat *the veil* as the same membrane
seen from different sides — mortals who ascend cross *out*; the dead cross *down/in*. The
GOD-dungeon and the Afterlife would then be **two doorways to the same outside**, which is
consistent with "The Abyssal God is not a creature. It is a concept." This is exactly the kind of
cosmology-alignment the owner should rule on first → logged in `additional_ideas/ideas.md` as
NEEDS REVIEW. No text was changed anywhere.

---

## 7. Soul-adjacent canon already in the game (no new lore needed to justify)

These existing elements make the Afterlife/souls proposal feel native rather than bolted on:

| Existing element | Location | Flavor value |
|---|---|---|
| Reaper class → **Death Lord** ascension, tagline "**Collector of souls**" | engine.js:17130 (class docs) | A god-tier class literally defined by soul collection |
| Skills: `soul_reap`, `soul_shield`, `grim_reaping`, `soul_reaping` | skillTree.js:5352-5517 | Reaper kit |
| Warlock `soul_harvest` (2820), Necromancer `soul_bind` (3380), Leviathan `soul_of_the_deep` (4658) | skillTree.js | Soul magic is mainstream |
| **Soul Forging** (summon fusion, SOULBOUND 7 days) | summonForging.js:28,238 | "Soul" = crafting currency metaphor already accepted |
| **Soul Echo** (buff when a summon dies) | summonAI.js:422-450 | Death leaves echoes — Afterlife-adjacent |
| `SOUL_RIP` rune | engine.js:5476 | rune tier |
| `death_scythe` "Reaper Scythe — Harvests souls" | lootSystem.js:899 | item |
| Necromancer capture flavor "soul escapes capture" | summonCapture.js ~271 | closest existing kill→soul hook |
| GOD-dungeon Floor 2 "echoes of fallen adventurers" | guildAdventure.js:163 | the dead linger as echoes — Afterlife foothold |

---

## 8. What does NOT exist (verified by repo-wide grep, both repos)

- **Kosmion** — 0 hits. New working name, no collisions.
- **World map / `.j world`** — 0 hits (no command, no assets, no code).
- **Afterlife realm feature** — 0 hits (only the two zone names + wordlist).
- **Fortune teller** — 0 hits. "fortune" = Wheel-of-Fortune gambling command, "of Fortune" item
  affix, "Fortune Seeker" LUCK rank tier, "Ol' Fortune" TCG card name. No NPC.
- **Fantasy-race NPCs (dwarf/elf/goblin/witch as characters)** — 0 hits as NPCs. Dwarf/elf/witch
  names exist only as TCG collectible card names (cards_data.json) and the Stonekeep theme
  comment "dwarven fortress". Goblins exist as *enemies* (sprite sheets, mob mapping) and the
  boss "HIVE COMMANDER (was: Goblin King)". **No race NPC has ever been depicted.**
- **`bossKills` / `deaths` / `souls` stats** — do not exist (see existing_commands.md §4).

---

## 9. Verdict for the design pass

1. Canon is **preserved verbatim**; `.j lore` untouched; nothing above was edited in code.
2. The brief's cosmology is **compatible** with shipped canon under the naming mapping in §2.
3. The Abyss (§4), alternate-selves (§3), and soul-flavor (§7) give the new content a *native*
   vocabulary — new writing should reuse: "the Infection", "void-touched", "Divine Spark",
   "echoes", "beyond the veil" (with the §6 caveat), "The Infected", "Adventurers".
4. Two naming collisions to resolve at review time: **"Afterlife" zones** (§5) and **"the veil"**
   (§6).
5. The player's world has **no established name** and **no map** — `.j world` would be the first
   depiction ever, which is why the map concepts treat "your world" as a named-but-simple
   homeland region surrounded by unknowns (see world_map/README inside the package).
