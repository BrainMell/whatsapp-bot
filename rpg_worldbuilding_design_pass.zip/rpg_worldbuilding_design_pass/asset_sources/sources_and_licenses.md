# Asset Sources & Licenses

> Honest ledger of every visual asset in this package. Nothing here has been embedded in the
> bot. Verify before any production use.

---

## 1. AI-generated art (generated during this design pass) — 22 files

Location: `assets/` subdirectories (`dwarves/`, `elves/`, `witches/`, `fortune_tellers/`,
`other_races/`, `miscellaneous/`, `world_map/map_base_*.png`, `world_map/*_art.png`).

| Attribute | Status |
|---|---|
| Source | Z.ai image generation (text-to-image), prompts recorded in `scripts/artgen_group.sh` in the working session (prompts summarized per-file in `assets/README_prompts.txt`) |
| License | Per Z.ai generated-output terms — output is usable by the account holder; **not third-party encumbered to our knowledge** |
| Commercial use | Treated as YES for prototyping; confirm current ToU before shipping to production |
| Attribution | Not required by the tool |
| Editing needed | Yes, for production: consistency pass (same painter for a given NPC), background cleanup, size normalization (currently 864×1152 / 1024×1024 / 1344×768 mixes) |
| Known limits | Hands/faces vary between generations of the "same" character; the two dwarf files are intentionally two different smiths (see `image_cards/blacksmith/`), not one character |

**Design note:** the fantasy-race "cast" (dwarf smith ×2, elf brewer ×2, witch ×2, seer ×3)
was generated as distinct people so the owner can pick per-NPC identities later.

## 2. Assets copied from the project's own repos (internal, zero licensing risk)

| File | Copied from | Why |
|---|---|---|
| `assets/backgrounds/bg_BREW.png` `bg_FORGE.png` `bg_DUEL.png` | Bot_genaration `assets/rpgasset/ui/craft/` | the reference look new cards must match |
| `assets/backgrounds/spark_15.png` | Bot_genaration `assets/rpgasset/environment/` | current PvP arena default (2026-09-17 owner pick) |
| `assets/ui/bg_1.png` `bg_7.png` | whatsapp-bot `core/rpgasset/ui/styles/` | themed profile backgrounds (Stonekeep / Decree) |
| `assets/ui/Cinzel.ttf` `CinzelDecBold.ttf` `MedievalSharp.ttf` `IMFellEnglish-Italic.ttf` `fantesy.ttf` | repo font dirs (see investigation/existing_card_system.md §6) | the house typography used in every mockup |
| `assets/miscellaneous/Fighter1.png` `fire (5).png` | class/enemy sprite sets | scale reference (512×1024 / 64×96) for any new character art |

These are the project's own assets (or fonts already shipped inside the repos) — usable freely
within the project. External redistribution of the fonts is a separate question (see §4).

## 3. Rendered mockups & maps (this package)

`world_map/**` and `image_cards/**` were composed by this pass (SVG/PIL) from the §1 and §2
art plus code-drawn chrome. Treat as design deliverables — same terms as §1 once composed.

## 4. External sources — LEADS ONLY (not fetched, not verified in this sandbox)

Sandbox network restrictions prevented reliable fetching of external packs (attempted Kenney
fantasy-town-kit → returned an HTML stub). The following are curated leads with license status
to verify at fetch time:

| Source | What | License | URL | Notes |
|---|---|---|---|---|
| Kenney "Fantasy Town Kit" | 3D/2D building & prop set | **CC0** (Kenney's standard) | kenney.nl/assets/fantasy-town-kit | CC0 = safe; grab manually and re-check the pack's LICENSE.txt |
| OpenGameArt: "LPC" character collections | humanoid sprites w/ walk cycles | CC-BY-SA 3.0 mostly | opengameart.org (search "LPC") | ⚠️ share-alike viral — avoid mixing into proprietary sets; attribution + same license required |
| OpenGameArt: "Flavour and Towns" / potion & forge icon packs | icons | mixed CC0 / CC-BY | opengameart.org | check per-file |
| itch.io free NPC packs (e.g. "Serene Village", "Tiny RPG") | race NPCs w/ poses | usually free w/ attribution; varies per pack | itch.io/game-assets/free | **varies — read each pack page**; many are non-commercial |
| Google Fonts: Cinzel, MedievalSharp, IM Fell English | the house fonts | OFL (open font license) | fonts.google.com | the repo copies came from here originally; OFL allows bundling with fonts renamed if modified — shipping as-is inside a private repo is fine |
| DejaVu Sans (runes/fallback) | system font | free (Bitstream Vera derivative) | dejavu-fonts.github.io | already system-provided |

**Flagged:** anything from itch.io with "free" but no explicit license file = treat as
UNCLEAR until the pack page states commercial rights. Do not ship those without the owner's
sign-off.

## 5. Intended use per asset family

| Family | Intended use | Additional editing needed |
|---|---|---|
| `dwarves/` | blacksmith NPC cards, forge/repair flow chrome | crop to art-window ratio; maybe unify one smith |
| `elves/` + `witches/` | brewing/cooking cards | crop; the witch doubles as alchemist |
| `fortune_tellers/` | soul-sight / seer feature | pick ONE identity (brief §20 wants multiple concepts — delivered 3) |
| `other_races/abyss_*` | Abyss encounter cards (creature/player/distorted/alt-self/timeline) | vignette + red-tint pass for horror consistency |
| `miscellaneous/afterlife_*` | Afterlife/veil cards, soul ledger | composite w/ gold veil curtains to match decree chrome |
| `world_map/map_base_*` | `.j world` concept backgrounds | parchment/dark bases are textures; cosmic is Concept C/E base |
| `ui/` | mockup chrome | — |
