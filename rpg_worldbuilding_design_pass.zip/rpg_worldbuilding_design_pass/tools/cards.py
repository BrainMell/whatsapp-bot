#!/usr/bin/env python3.13
"""cards.py — generates NPC / feature card mockups into image_cards/.

REWORKED per owner review:
  - NO AI-generated imagery anywhere (researched online assets or labeled art slots).
  - NO lore lines baked into cards — lore drops are chat text only (lore_drops/).
  - NO bespoke abyss image cards — abyss encounters are normal encounters with the
    right enemy sprite + ability set (see abyss_as_normal_encounter()).
"""
import sys, os
sys.path.insert(0, "/home/z/my-project/scripts")
from card_kit import *
from PIL import Image, ImageDraw

PKG = "/home/z/my-project/download/rpg_worldbuilding_design_pass"
A = f"{PKG}/assets"
R = f"{A}/researched"
OUT = f"{PKG}/image_cards"
for sub in ("blacksmith", "brewing", "fortune_teller", "afterlife", "world", "alternatives"):
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)

SMITH_IDLE = (f"{R}/npc/free-npc-character-pack-blacksmith-jeweler-sage-warlord/"
              "Blacksmith/PNG/PNG Sequences/Idle/0_Blacksmith_Idle_000.png")
SMITH_GREET = (f"{R}/npc/free-npc-character-pack-blacksmith-jeweler-sage-warlord/"
               "Blacksmith/PNG/PNG Sequences/Greeting/0_Blacksmith_Greeting_005.png")


def pixel_art_window(im, sprite_path, box, scale=None, overlay=40, frame=True,
                     cell=None, grid=None, crop=None):
    """art_window variant for pixel sprites: optional raw crop / sheet-cell crop,
    integer NEAREST upscale chosen to fit, clipped to the window box."""
    x0, y0, x1, y1 = box
    spr = Image.open(sprite_path).convert("RGBA")
    if crop:
        spr = spr.crop(crop)
    elif grid:
        gw, gh = spr.width // grid[0], spr.height // grid[1]
        c = cell or (0, 0)
        spr = spr.crop((c[0]*gw, c[1]*gh, (c[0]+1)*gw, (c[1]+1)*gh))
    win_w, win_h = x1 - x0, y1 - y0
    if scale is None:
        scale = max(1, min(win_w // spr.width, win_h // spr.height))
    spr = spr.resize((spr.width * scale, spr.height * scale), Image.NEAREST)
    win = Image.new("RGBA", (win_w, win_h), (0, 0, 0, 0))
    px, py = (win_w - spr.width) // 2, (win_h - spr.height) // 2
    if px < 0 or py < 0:  # sprite larger than window: center-crop it
        sx = max(0, -px); sy = max(0, -py)
        spr = spr.crop((sx, sy, min(spr.width, sx + win_w), min(spr.height, sy + win_h)))
        px, py = max(0, px), max(0, py)
    win.alpha_composite(spr, (px, py))
    if overlay:  # draw shade on a separate layer (ImageDraw would REPLACE pixels!)
        shade = Image.new("RGBA", win.size, (0, 0, 0, 0))
        ImageDraw.Draw(shade).rectangle([0, 0, win_w, win_h], fill=(24, 16, 10, overlay))
        win.alpha_composite(shade)
    im.alpha_composite(win, (x0, y0))
    if frame:
        d = ImageDraw.Draw(im)
        d.rectangle([x0, y0, x1, y1], outline=DECREE["Gold"], width=2)


# ---------------------------------------------------------------- 1. BLACKSMITH
def blacksmith_v1():
    im = canvas()
    art_window(im, SMITH_IDLE, (55, 208, 545, 560))
    banner_band(im, "THE FORGE")
    nameplate(im, "BALIN STONEHEW · SMITH")
    d = ImageDraw.Draw(im)
    panel(im, (55, 585, 545, 900))
    dividers(im, [626, 630], 70, 530)
    d.text((300, 606), "REPAIR BENCH", font=F("cinzel", 21), fill=DECREE["Muted"], anchor="mm")
    y = rows(im, [("Iron Longsword", "35 / 100"), ("Steel Cuirass", "12 / 100"),
                  ("Traveler's Boots", "78 / 100"), ("Rune-etched Helm", "44 / 100")],
             80, 380, 656, 46)
    for i, frac in enumerate([0.35, 0.12, 0.78, 0.44]):
        stat_bar(im, 300, 668 + i*46, 150, 10, 1-frac)
    dark_pill(im, "durability restored - cost 1,240 zeni", 300, 872, size=15)
    caption(im, "the forge never sleeps, it only banks its coals", 300, 936)
    wax_seal(im, 70, 935, 26, "B")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/blacksmith/smith_card_v1_decree.png")

def blacksmith_v2():
    """Stonekeep-themed variant: steel palette, riveted frame."""
    im = canvas(bg=(74, 76, 82, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 600, 1000], fill=(74, 76, 82, 255))
    art_window(im, SMITH_GREET, (40, 170, 560, 620), overlay=30)
    d.rectangle([24, 24, 576, 976], outline=(172, 174, 174, 255), width=3)
    for cx, cy in [(36, 36), (564, 36), (36, 964), (564, 964)]:
        d.ellipse([cx-6, cy-6, cx+6, cy+6], fill=(28, 30, 34, 255),
                  outline=(172, 174, 174, 255), width=2)
    d.text((300, 80), "STONEKEEP FORGE", font=fit_text(d, "STONEKEEP FORGE", "cinzeldec", 34, 460),
           fill=(232, 234, 238, 255), anchor="mm")
    d.rounded_rectangle([150, 118, 450, 156], 8, fill=(35, 37, 41, 235))
    d.text((300, 137), "repair · refit · re-edge", font=F("medsharp", 20),
           fill=(255, 179, 64, 255), anchor="mm")
    panel(im, (60, 660, 540, 930), fill=(168, 170, 174, 255), outline=(35, 37, 41, 255))
    d.text((300, 690), "BENCH REPORT", font=F("cinzel", 20), fill=(74, 78, 86, 255), anchor="mm")
    rows(im, [("Longsword", "100/100"), ("Cuirass", "100/100"), ("Helm", "100/100")],
         90, 380, 724, 44, label_c=(35, 37, 41, 255), val_c=(26, 28, 32, 255))
    dark_pill(im, "rivets set · iron honest", 300, 886)
    caption(im, "steel remembers the hammer", 300, 950, color=(35, 37, 41, 255))
    im.convert("RGB").save(f"{OUT}/blacksmith/smith_card_v2_stonekeep.png")

def blacksmith_v3():
    """Alternative split composition: pixel dwarf sprite left, ledger right."""
    im = canvas()
    d = ImageDraw.Draw(im)
    pixel_art_window(im, f"{R}/dwarf/dorf2.png", (0, 120, 260, 880), overlay=15)
    banner_band(im, "THE FORGE — LEDGER")
    panel(im, (285, 208, 560, 700))
    d.text((422, 240), "SERVICES", font=F("cinzel", 20), fill=DECREE["Muted"], anchor="mm")
    rows(im, [("Repair", "from 40z"), ("Refit", "120z"), ("Re-edge", "65z"),
              ("Rune socket", "300z"), ("'Special' job", "ask")],
         305, 430, 280, 48, max_val_w=110)
    dividers(im, [560], 305, 540)
    d.text((422, 588), "no questions,\nno refunds,", font=F("medsharp", 19),
           fill=DECREE["Ink"], anchor="mm", align="center")
    d.text((422, 640), "no haunting", font=F("medsharp", 19), fill=DECREE["Sub"], anchor="mm")
    dark_pill(im, "open dusk till dawn", 422, 760)
    caption(im, "sparks that fall upward mean the fire's seen something", 420, 936, max_w=300)
    wax_seal(im, 70, 935, 26, "B")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/blacksmith/smith_card_v3_ledger_split.png")

# ---------------------------------------------------------------- 2. BREWING (landscape 1000x600)
def brewing_v1():
    im = canvas(1000, 600)
    art_placeholder(im, (40, 60, 560, 540),
                    "ART SLOT — still-room scene (see assets/researched + leads)")
    banner_band(im, "THE STILL ROOM", y0=14, y1=94)
    d = ImageDraw.Draw(im)
    panel(im, (580, 120, 970, 470))
    d.text((775, 152), "BREWED", font=F("cinzeldec", 30), fill=DECREE["Ink"], anchor="mm")
    d.text((775, 190), "Elixir of the Deep Root", font=fit_text(d, "Elixir of the Deep Root", "medsharp", 22, 340),
           fill=DECREE["Sub"], anchor="mm")
    rows(im, [("Potency", "+18%"), ("Hours", "6"), ("Rarity", "uncommon"), ("Value", "310 zeni")],
         600, 810, 226, 44, max_val_w=130, size=20)
    dividers(im, [420], 600, 950)
    d.text((775, 445), "quality: the vial hums politely", font=F("medsharp", 17),
           fill=DECREE["Muted"], anchor="mm")
    wax_seal(im, 616, 520, 26, "V")
    caption(im, "brewed on apple-wood fire, never iron", 800, 520, max_w=250, size=18)
    im.convert("RGB").save(f"{OUT}/brewing/brew_card_v1_stillroom.png")

def brewing_v2():
    """Witch cauldron, portrait, Woodmere-warm palette."""
    im = canvas(bg=(88, 58, 34, 255))
    d = ImageDraw.Draw(im)
    art_placeholder(im, (40, 150, 560, 640),
                    "ART SLOT — witch & cauldron (researched leads)")
    d.rectangle([20, 20, 580, 980], outline=(198, 140, 60, 255), width=3)
    d.rectangle([30, 30, 570, 970], outline=(52, 34, 15, 255), width=2)
    d.text((300, 84), "THE CROOKED CAULDRON", font=fit_text(d, "THE CROOKED CAULDRON", "cinzeldec", 30, 500),
           fill=(226, 192, 142, 255), anchor="mm")
    d.text((300, 120), "tonics · philtres · soups that argue back", font=F("medsharp", 19),
           fill=(240, 180, 94, 255), anchor="mm")
    panel(im, (60, 680, 540, 930), fill=(226, 192, 142, 255), outline=(52, 34, 15, 255))
    d.text((300, 712), "BREWED — Marshlight Draught", font=F("cinzel", 21),
           fill=(52, 34, 15, 255), anchor="mm")
    rows(im, [("Effect", "glow in the dark"), ("Duration", "3 hrs"), ("Side effect", "gentle humming")],
         84, 320, 748, 42, label_c=(116, 82, 46, 255), val_c=(52, 34, 15, 255))
    caption(im, "the kettle knows what you did", 300, 946, color=(240, 180, 94, 255))
    im.convert("RGB").save(f"{OUT}/brewing/brew_card_v2_witch.png")

# ---------------------------------------------------------------- 3. FORTUNE TELLER / SOULS
def souls_locked():
    """Soul-sight LOCKED state (below level gate) — the refusal as UI copy."""
    im = canvas()
    art_placeholder(im, (55, 208, 545, 620),
                    "ART SLOT — the reader's tent (researched leads)")
    banner_band(im, "THE VEILWARD READING")
    nameplate(im, "THE SOUL READER")
    d = ImageDraw.Draw(im)
    panel(im, (55, 660, 545, 900))
    d.text((300, 700), "THE SIGHT", font=F("cinzeldec", 30), fill=DECREE["Ink"], anchor="mm")
    for i, (t, done) in enumerate([("reach level 40", True), ("face the deep floors", False),
                                   ("pay the reader's fee", False)]):
        yy = 736 + i*44
        d.ellipse([84, yy-10, 104, yy+10], outline=DECREE["Track"], width=3)
        if done:
            d.ellipse([88, yy-6, 100, yy+6], fill=DECREE["Done"])
        d.text((120, yy), t, font=F("cinzel", 20), fill=DECREE["Ink"])
    d.rounded_rectangle([95, 856, 505, 892], 18, fill=(96, 62, 24, 235))
    d.text((300, 874), "the spell overwhelms the weak-willed", font=F("medsharp", 18),
           fill=DECREE["PillTx"], anchor="mm")
    caption(im, "come back when the count gets heavy", 300, 936)
    wax_seal(im, 70, 935, 26, "X")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/fortune_teller/souls_card_locked.png")

def souls_unlocked():
    """Soul-sight UNLOCKED — the count by rank."""
    im = canvas()
    art_placeholder(im, (55, 208, 545, 500),
                    "ART SLOT — reading tableau (researched leads)")
    banner_band(im, "SOULS BEYOND THE VEIL")
    nameplate(im, "READER · THE COUNT")
    d = ImageDraw.Draw(im)
    panel(im, (55, 540, 545, 900))
    d.text((300, 576), "THE LEDGER OF WHAT YOU SENT", font=F("cinzel", 19),
           fill=DECREE["Muted"], anchor="mm")
    y = rows(im, [("total souls", "1,284"), ("F-rank kind", "812"), ("C-rank kind", "341"),
                  ("A-rank kind", "97"), ("boss kinds", "29"), ("from below floor 90", "5")],
             80, 310, 606, 42, max_val_w=110, size=19)
    for i, frac in enumerate([1.0, 0.63, 0.27, 0.08, 0.02]):
        stat_bar(im, 436, 616+i*42, 92, 9, frac)
    dividers(im, [872], 70, 530)
    d.text((300, 892), "they looked back. they always look back.", font=F("medsharp", 18),
           fill=DECREE["Sub"], anchor="mm")
    caption(im, "the count is a library — every number a story", 300, 936)
    wax_seal(im, 70, 935, 26, "X")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/fortune_teller/souls_card_unlocked.png")

def seer_v3():
    """Soul Forge styled alternative — teal/gold mystic."""
    im = canvas(bg=(27, 27, 48, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 600, 1000], fill=(27, 27, 48, 255))
    art_placeholder(im, (30, 150, 570, 660),
                    "ART SLOT — mystic tableau (researched leads)")
    d.rectangle([22, 22, 578, 978], outline=(201, 169, 97, 255), width=2)
    d.rectangle([30, 30, 570, 970], outline=(127, 215, 208, 255), width=1)
    d.text((300, 84), "SPIRIT READING", font=fit_text(d, "SPIRIT READING", "cinzeldec", 36, 480),
           fill=(236, 228, 204, 255), anchor="mm")
    d.text((300, 122), "the cards remember every face", font=F("medsharp", 19),
           fill=(127, 215, 208, 255), anchor="mm")
    panel(im, (50, 700, 550, 920), fill=(32, 32, 58, 235), outline=(201, 169, 97, 255))
    d.text((300, 734), "DRAW FOR: WHAT STIRS BELOW", font=F("cinzel", 18),
           fill=(201, 169, 97, 255), anchor="mm")
    rows(im, [("card I", "the road, reversed"), ("card II", "the mirror, upright"),
              ("card III", "the door, sleeping")],
         74, 320, 768, 42, label_c=(168, 159, 138, 255), val_c=(236, 228, 204, 255))
    caption(im, "three coins. no refunds on fate.", 300, 946, color=(201, 169, 97, 255))
    im.convert("RGB").save(f"{OUT}/fortune_teller/seer_card_v3_soulforge.png")

# ---------------------------------------------------------------- 4. AFTERLIFE
def afterlife_v1():
    im = canvas()
    art_placeholder(im, (55, 208, 545, 640),
                    "ART SLOT — the shoreline (intentionally uncharted)")
    banner_band(im, "BEYOND THE VEIL")
    nameplate(im, "THE SHORELINE")
    d = ImageDraw.Draw(im)
    panel(im, (55, 680, 545, 900))
    d.text((300, 716), "WHAT THE DEAD REPORT", font=F("cinzel", 19), fill=DECREE["Muted"], anchor="mm")
    rows(im, [("roads", "unmapped"), ("weather", "remembered winters"),
              ("arrivals", "crowded, lately"), ("inhabitants", "polite")],
         80, 330, 748, 42, max_val_w=180)
    dark_pill(im, "the light is the color of your happiest hour", 300, 880, size=16)
    caption(im, "the veil doesn't take. it keeps.", 300, 936)
    wax_seal(im, 70, 935, 26, "?")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/afterlife/afterlife_card_v1_shore.png")

def afterlife_v2():
    im = canvas()
    art_placeholder(im, (55, 208, 545, 620),
                    "ART SLOT — ledger hall (researched leads)")
    banner_band(im, "THE GREAT LEDGER")
    nameplate(im, "NAMES, AND WHAT CARRIED THEM")
    d = ImageDraw.Draw(im)
    panel(im, (55, 660, 545, 900))
    y = rows(im, [("sent by you", "1,284"), ("sent by your guild", "9,031"),
                  ("sent by all realms", "unknowable")],
             80, 360, 700, 46, max_val_w=150, size=19)
    dividers(im, [846], 70, 530)
    d.text((300, 872), "even the monsters weigh lighter than you'd think", font=F("medsharp", 18),
           fill=DECREE["Sub"], anchor="mm")
    caption(im, "every number a story that ended where you stood", 300, 936)
    wax_seal(im, 70, 935, 26, "L")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/afterlife/afterlife_card_v2_ledger.png")

# ---------------------------------------------------------------- 5. ABYSS = NORMAL ENCOUNTER
def abyss_as_normal_encounter():
    """Owner decision: abyss contacts are NOT image cards. They are plain encounters
    using the EXISTING enemy pipeline: correct sprite + ability set + kill hooks.
    This mockup uses the bot's own sprites (internal reference, assets/researched/
    enemies/bot_reference/) to show the intended rendering parity."""
    # variant A: hostile — kobold sprite, abyss-tinted ability rows
    im = canvas()
    pixel_art_window(im, f"{R}/enemies/bot_reference/kobold_0000_red.png",
                     (55, 208, 545, 560), crop=(1245, 60, 1420, 185), overlay=30)
    banner_band(im, "ENCOUNTER — THE DEEP")
    nameplate(im, "DEEP KOBOLD · DROWSED LINE")
    d = ImageDraw.Draw(im)
    panel(im, (55, 585, 545, 900))
    d.text((300, 606), "ABILITY SET", font=F("cinzel", 21), fill=DECREE["Muted"], anchor="mm")
    rows(im, [("gnaw", "quick, bleeds"), ("torch-snuff", "dims lanterns"),
              ("pack call", "summons 1d2"), ("counterspell", "weak")],
         80, 380, 656, 46)
    dark_pill(im, "kills feed recordEnemyKill as any mob — no special case", 300, 872, size=14)
    caption(im, "same encounter renderer, right sprite, right abilities", 300, 936)
    wax_seal(im, 70, 935, 26, "A")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/world/abyss_encounter_normal_kobold.png")

    # variant B: the person-shaped contact — humanoid sprite family, dialogue-first
    im = canvas()
    art_placeholder(im, (55, 208, 545, 560),
                    "SPRITE SLOT — existing humanoid NPC sprite family")
    banner_band(im, "ENCOUNTER — CONTACT")
    nameplate(im, "THE WAITING ONE")
    d = ImageDraw.Draw(im)
    panel(im, (55, 585, 545, 900))
    d.text((300, 606), "BEHAVIOUR, NOT BESTIARY PAGE", font=F("cinzel", 20),
           fill=DECREE["Muted"], anchor="mm")
    rows(im, [("hostile?", "no — until named"), ("dialogue", "one line, then echo"),
              ("attack set", "mirrors yours, -1 tier"), ("on kill", "no loot, +1 soul")],
         80, 380, 656, 46)
    dark_pill(im, "flagged abyss_contact — timeline + variant tables only", 300, 872, size=14)
    caption(im, "it is an encounter. it is not a collectible card.", 300, 936)
    wax_seal(im, 70, 935, 26, "A")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/world/abyss_encounter_normal_contact.png")

# ---------------------------------------------------------------- 6. WORLD (as shipped card)
def world_card():
    """How .j world ships: the map as a card with banner + caption."""
    map_path = f"{PKG}/world_map/concept_A_sundered_wheel/wheel_map_mid.png"
    im = canvas()
    art_window(im, map_path, (30, 150, 570, 830), overlay=8)
    banner_band(im, "KOSMION — KNOWN WORLDS")
    nameplate(im, "CHART OF THE WEAVING")
    d = ImageDraw.Draw(im)
    caption(im, "the fog keeps what you haven't earned — yet", 300, 880, max_w=520)
    d.text((300, 940), ".j world  ·  new discoveries are inked automatically", font=F("cinzel", 16),
           fill=DECREE["Muted"], anchor="mm")
    wax_seal(im, 70, 935, 26, "K")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/world/world_card_v1.png")

# ---------------------------------------------------------------- alternatives
def alt_smith_banner_variants():
    """Typography/border experiments for the smith card."""
    im = canvas()
    d = ImageDraw.Draw(im)
    art_window(im, SMITH_GREET, (55, 150, 545, 700), overlay=15)
    d.rectangle([16, 16, 584, 984], outline=DECREE["Gold"], width=2)
    d.rectangle([24, 24, 576, 976], outline=(120, 88, 40, 255), width=1)
    d.polygon([(120, 60), (480, 60), (460, 110), (300, 130), (140, 110)],
              fill=DECREE["Banner"], outline=DECREE["BannerEdge"])
    d.text((300, 88), "IRONSONG & DAUGHTERS", font=fit_text(d, "IRONSONG & DAUGHTERS", "cinzel", 26, 300),
           fill=DECREE["BannerTx"], anchor="mm")
    d.rounded_rectangle([180, 740, 420, 786], 23, fill=(8, 8, 8, 160))
    d.text((300, 763), "est. before the Infection", font=F("medsharp", 19),
           fill=DECREE["PillTx"], anchor="mm")
    rows(im, [("apprentice slot", "open"), ("commission wait", "9 days"),
              ("grudge ledger", "3 names")],
         150, 450, 820, 44)
    caption(im, "walk-ins welcome · sword-draggers scowled at", 300, 930)
    wax_seal(im, 300, 975, 22, "ID")
    im.convert("RGB").save(f"{OUT}/alternatives/smith_variant_ribbon.png")

def alt_info_card_no_art():
    """Text-led decree card: for features that need no illustration at all."""
    im = canvas()
    d = ImageDraw.Draw(im)
    banner_band(im, "TOWN CRIER · NOTICES")
    nameplate(im, "THE WEEK'S WORD")
    panel(im, (55, 208, 545, 900))
    d.text((300, 248), "POSTED", font=F("cinzeldec", 30), fill=DECREE["Ink"], anchor="mm")
    rows(im, [("rift roads", "two open"), ("the underside", "do not survey"),
              ("soul count", "up"), ("forge prices", "unchanged"),
              ("the veil", "keeps what it takes")],
         90, 480, 300, 52, size=20)
    dividers(im, [610, 614], 80, 520)
    d.text((300, 660), "nothing here is a card image —", font=F("medsharp", 20),
           fill=DECREE["Ink"], anchor="mm")
    d.text((300, 692), "the crier speaks, the text stays text.", font=F("medsharp", 20),
           fill=DECREE["Sub"], anchor="mm")
    dark_pill(im, "lore lines appear in chat like this — occasionally, in italics", 300, 872, size=14)
    caption(im, "ink is cheaper than parchment — say it, don't paint it", 300, 936)
    wax_seal(im, 70, 935, 26, "N")
    gold_hairline(im)
    im.convert("RGB").save(f"{OUT}/alternatives/info_card_text_only.png")

if __name__ == "__main__":
    blacksmith_v1(); blacksmith_v2(); blacksmith_v3()
    brewing_v1(); brewing_v2()
    souls_locked(); souls_unlocked(); seer_v3()
    afterlife_v1(); afterlife_v2()
    abyss_as_normal_encounter()
    world_card()
    alt_smith_banner_variants(); alt_info_card_no_art()
    print("all cards generated (no AI art, no baked lore, no abyss image cards)")
