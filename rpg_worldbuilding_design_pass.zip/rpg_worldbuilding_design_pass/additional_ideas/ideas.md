# Additional Ideas — collected during the investigation

> Nothing here is canon. Labels: **PROPOSED** (fits, needs owner approval) ·
> **EXPERIMENTAL** (interesting, unproven) · **NEEDS REVIEW** (touches canon or another
> system; owner must rule). Each: what / why it fits / system used / lore revealed /
> downsides / contradictions.

---

## 1. The veil is one membrane, two doorways — NEEDS REVIEW
- **What:** formalize that the GOD-dungeon's "beyond the veil" (guildAdventure.js:6840) and the
  Afterlife's veil are the same boundary seen from different sides: ascension crosses out,
  death crosses in.
- **Why it fits:** reuses existing canon language instead of adding a second metaphysics; the
  Abyssal God's "not a creature — a concept" line (Void Floor 6) implies the outside is the
  same nowhere for both.
- **System used:** dialogue + map edge treatments only.
- **Lore revealed:** why the reader says gods arrive like weather.
- **Downsides:** fuses two features the owner may want independent; constrains future writing.
- **Contradictions:** the brief lists the Afterlife and the God-Rank world as separate unknowns;
  this idea deliberately entangles them. Owner must choose.

## 2. "Infected Afterlife" zone-name collision — NEEDS REVIEW
- **What:** the existing dungeon zones "Infected Afterlife" / "Pre-Infected Afterlife"
  (guildAdventure.js:290-305) will collide with the new dead-realm in player vocabulary.
- **Proposal:** either (a) rename those zones in a future pass (they're ecology labels —
  "the lands after the Infection"), or (b) lean in: the reader has a line acknowledging the
  mortals' sloppy naming ("Your kind calls a corrupted plain 'afterlife'. Adorable. Mine is
  the one with the doors.").
- **Downsides:** (a) touches existing text the brief froze-adjacent; (b) adds a fourth wall
  wink — tone risk.

## 3. `.j world` discovery toasts — PROPOSED
- **What:** when a trigger fires (first dungeon clear, floor 50, GOD rank), the NEXT `.j world`
  render includes one freshly-inked region with a subtle "newly charted" seal and its own
  one-line lore drop.
- **Why it fits:** makes the map a living reward loop with zero new mechanics.
- **System used:** worldMap.discoveries diff vs render; one extra drop call.
- **Downsides:** players may spam `.j world` expecting content (cooldown suggested).

## 4. The extra bowl (afterlife ambient) — PROPOSED
- **What:** brewing/cooking successes have a 2% chance to append: "╒ *You set an extra bowl.
  Costs nothing. The old texts insist.* ╛" — the player's character instinctively honors the
  dead before the afterlife is ever revealed.
- **Why it fits:** earliest possible afterlife foreshadowing, fully deniable, zero mechanics.
- **System used:** loreDrops with a rare weight.
- **Downsides:** none identified.

## 5. Named smiths per instance — EXPERIMENTAL
- **What:** each bot tenant's forge card names a different smith (Joker's forge: "Balin
  Stonehew", Jake's: "Ironsong & Daughters", Subaru's: …) — same pools, different faces.
- **Why it fits:** tenancy already segments personality; gives each bot a household cast.
- **System used:** npcArt selection keyed by botConfig name.
- **Downsides:** triples art needs for the same flows; art consistency per character is the
  hard part (solved by sourcing from one asset pack per character, not AI generation).

## 6. Book of the Slain — EXPERIMENTAL (rejected for v1)
- **What:** a per-kill ledger collection (enemy name, rank, floor, timestamp) powering a
  "remember them" scroll in the soul-sight card.
- **Why it fits:** the strongest emotional version of §18.
- **Downsides:** unbounded writes on a Free-tier Mongo cluster for flavor; kill volume is
  high (pack fights multiply it). Rejected for v1; revisit only with aggregation limits.
- **Contradiction:** none, purely cost.

## 7. Fortune teller as the ONE recurring lore NPC — PROPOSED
- **What:** the seer is the only character allowed to appear across multiple flows (souls,
  rare general drops, future event rooms) — everyone else stays in their lane (smith = forge,
  brewer = kitchen).
- **Why it fits:** brief §20-21 make her the spell-caster; a single recurring face builds the
  "she knows" feeling the pools already write toward.
- **Downsides:** overexposure risk — keep her surface count at ≤3.

## 8. Abyss "not-yet" sky event (worldwide) — NEEDS REVIEW
- **What:** general.md line 24 ("A star went out and came back dimmer… every oracle said 'not
  yet'") seeds a future server-wide event the owner could later canonize (a cosmology beat
  before GOD-rank content expands).
- **Why it fits:** drops plant long-arc storytelling for free.
- **Downsides:** plants a debt — if nothing ever comes of it, it reads as broken promise.
  Only adopt if the owner wants the thread.

## 9. `.j lore` suggestions (NOT implemented — brief §2 requires this here)
- If someday approved: add a final line to `.j lore` pointing at the map ("The chronicles are
  silent on the shape of the worlds. The guild's cartographers are less shy: `<prefix> world`.")
  — a bridge, not a rewrite.
- A "chronicles II" second page (the Chaos-shards / piece-bosses beat from the brief's canon
  list) is UNWRITTEN canon space; the existing text stops at "the fate of all realms" — the
  owner can extend without contradicting anything.

## 10. Timeline tint on `.j world` — EXPERIMENTAL
- **What:** late-state maps add a barely-visible second ring of "echo anchors" (dotted, tinted)
  hinting at timeline variations without a single word of explanation.
- **Why it fits:** brief §5 wants timeline variation representable; silence is the hard part.
- **Downsides:** may read as a rendering bug; needs a legend line or nothing at all.

## 11. Reader's fee as sink — PROPOSED (economy touch — needs owner approval)
- **What:** the "reader's fee" in the locked card's requirements is a real (small) Zeni payment
  on first unlock — a flavor-consistent tiny sink.
- **Downsides:** any economy coupling needs owner sign-off; free is perfectly fine.

## 12. Kosmion name reveal ceremony — NEEDS REVIEW
- **What:** "Kosmion" stays map-only (working name) until some trigger (GOD rank?) where ONE
  character finally says it — the word enters dialogue exactly once.
- **Why it fits:** brief §5 calls it a working name; a controlled first utterance makes it
  canon on the owner's schedule.
- **Downsides:** none mechanical; purely an editorial commitment.
