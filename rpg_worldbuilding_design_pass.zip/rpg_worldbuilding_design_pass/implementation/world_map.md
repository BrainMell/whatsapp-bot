# Implementation — `.j world` (design-only; nothing implemented)

> Depends on: investigation/architecture_notes.md §1/§3, world_map/README.md.
> Zero code changed in this pass; this is the build plan for when the owner approves.

## 1. Command flow

```
".j world" (or ".s world" etc. — same handler)
→ engine.js dispatch: add `if (primaryCmd === "world")` near the other RPG dispatches
  (insert point suggestion: beside `.j lore` at engine.js ~6880, same indent depth)
→ core/rpg/worldMap.js  (NEW MODULE — house pattern: features live in modules, not engine.js)
   1. const user = await economy.getUser(senderJid);  if (!user) → register nudge
   2. state = buildMapState(user)          // §3 below
   3. payload = { kind: "WORLDMAP", style: user.cardStyle || 0, state: state.mode,
                  discoveries: state.discoveries, nickname: displayName, caption: helpText }
   4. buf = await goImageService.generatePortraitCard(payload)   // null on any failure
   5. image FIRST: sock.sendMessage(chatId, { image: buf, caption })
   6. null → text fallback: an ASCII mini-map (fixed 12-line sketch) + same caption
```

Caption contract: `🗺️ *KOSMION — known worlds* (working name)\n` + one status line
(discoveries count / next hint) + optional lore drop via `loreDrops.maybeDrop('general_world')`.
No `.j lore` text duplication — the map links to it conceptually ("the chronicles live at
`<prefix> lore`" is allowed as a single hint line; do not paste lore).

## 2. Map rendering (Go side, when approved)

- New kind `WORLDMAP` in `portraitRequest`; register in the dispatch switch (portrait.go ~377)
  and `styledKinds()` only if themed variants are wanted.
- **Recommended v1: baked decree-style** (like battle cards): add `bg_WORLDMAP.png`
  (1000×1400 bake derived from concept A art), draw dynamic overlays in Go from payload:
  fog patches over undiscovered anchors, revealed world blobs, abyss strata count from
  `state.deepFloor`, BEYOND tear glow when `state.beyond`, shoreline when `state.veil`.
- Canvas: 1000×1400 (new size — mirrors the concept art; safe for WhatsApp).
- Reuse: `portraitFitText` for labels, `sealAt` for the wax seal, gold hairline frame.
- If the owner prefers themed maps later: the concept set (A–G) already encodes per-style
  translations; concept F = style 9, G = style 3, B = style 2, etc.
- Node text fallback must exist BEFORE the Go renderer ships (house rule: cards never dead-end).

## 3. Player map state

Recommended **Option B-lite** (one declared field, lazily initialized):

```js
// core/models/User.js — SAME COMMIT as the code that writes it (Mongoose strict mode!)
worldMap: {
  mode: { type: String, enum: ['early','mid','late'], default: 'early' },
  discoveries: { type: [String], default: [] },   // world/region ids
  firstChartedAt: Date,
}
```

Mode derivation on first render (then cached on the doc):
- `late` if `user.adventurerRank in {SSS, GOD}` OR deepest Abyss floor ≥ 90
- `mid` if level ≥ 20 (Abyss gate precedent, engine.js:19682) OR ≥1 dungeon complete
- `early` otherwise
Discovery ids (v1 vocabulary, expandable): `home`, `rift_1`, `rift_2`, `abyss_mouth`,
`abyss_deep`, `beyond`, `veil_shore`. Adding a world later = appending an id + an anchor
coordinate in the Go map-data file — no schema change.

## 4. Unlock states (triggers, not implemented)

| Discovery | Trigger |
|---|---|
| `home` | always |
| `rift_1` | first dungeon completion (guildAdventure endAdventure victory) |
| `abyss_mouth` | first `.j abyss enter` (level 20 gate already exists) |
| `rift_2` | reserved for the first cross-realm dungeon (future content) |
| `abyss_deep` | deepest floor ≥ 50 |
| `beyond` | rank GOD (Trial of Divinity complete) |
| `veil_shore` | soul-sight unlocked (see implementation/afterlife.md) — ties the two features |

## 5. Future expansion

- Anchor-coordinate table lives in ONE Go-side data file (`pkg/combat/worldmap_data.go`):
  `{id, x, y, label, revealState}` per discovery — new worlds/timelines append rows.
- Timeline variations = same anchors with a `timeline` tag and a tint shift; no new geometry.
- The Afterlife NEVER becomes an anchor — it stays an edge treatment (shoreline), preserving
  "separate from Kosmion" without saying it.
- God-Rank area stays nameless: the tear keeps label "BEYOND" until the owner names it.

## 6. QA bar (when implemented)

- Render at styles 0/7 (baked) + 1/2/6/9 if themed; long-name test (20-char nickname on the
  plate via `portraitFitText`); empty-discovery payload (fresh account); text fallback drill
  (kill the Go service → message still helpful).
- Verify: fog NEVER covers `home`; Abyss never renders as a circle/world; BEYOND tear does not
  render below `late`; shoreline never renders before `veil_shore`.
