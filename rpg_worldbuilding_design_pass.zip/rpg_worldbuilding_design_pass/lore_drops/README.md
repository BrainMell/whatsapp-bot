# Lore Drops — README (format & frequency contract)

## The one-line format

Every lore drop is a single line appended to an existing command reply — **plain chat text only**.
OWNER DECISION (review pass 2): lore is NEVER baked into image cards and never attached to
card renders. It appears occasionally, in the flow of chat, then is gone:

```
╒ *I bet my family misses me, but this world brings business.* ╛
```

- **Framing glyphs are `╒` and `╛`** (box-drawing corner characters). They are NOT italicized.
- **The text inside is italicized** with single asterisks (WhatsApp single-asterisk = italics).
- One line, never a box, never a header like "LORE DISCOVERED", never a speaker label.
- Line length target: ≤ ~120 chars so it never wraps badly in WhatsApp; the longest pool lines
  were kept under ~150 for rare "important" ones.

## Category → surface map (from investigation)

| Pool | Attach surface | Code site (when implemented) |
|---|---|---|
| blacksmith | `.j repair`, `.j blacksmith`, forge successes | repairCommands.js:118/170; crafting FORGE caption |
| brewing | `.j brew`, `.j cook` | craftingSystem.js:713-717 caption |
| crafting | `.j craft`, `.j forge` | same caption builder |
| enchanting | `.j rune socket/fuse/remove/destroy` | runeSystem.js:739/663/831/848 |
| healing | `.j heal` / hospital / potion use | engine.js:9967/9990 |
| trading | `.j balance/transfer/deposit/withdraw/buy/sell` | engine.js:25226 caption (near-empty today), economy.js:1069/1149/1238 |
| fortune_teller | future `.j seer`/soul-sight + rare on any surface | new command (proposed) |
| general | menu tips rotation, idle/atmosphere slots | engine.js TIPS pattern :5469-5515 |
| abyss_unknown_creature / abyss_player / abyss_distorted_player / abyss_timeline_person / abyss_self_variant | Abyss combat victory / encounter text, keyed by encounter category | guildAdventure.js:6330-6362, abyssSystem encounter data |
| afterlife | soul-sight feature + fortune teller | proposed new feature |

## Frequency policy (baseline + reasoning)

- **Baseline 10%** per qualifying interaction (brief §14). The existing house precedents are
  5% (HIVE MIND WHISPERS) and 100%-but-rotating (menu TIPS) — so 10% sits comfortably between
  "rare whisper" and "every menu". Alternative documented in implementation doc: **8% + 30-min
  per-user cooldown** to protect repeat commands (crafting/balance are spammable; drops should
  not become noise).
- **Duplicate prevention:** per-chat ring buffer of the last 10 shown lines; never repeat
  within the ring. Pools are large enough that 10-deep rings never starve.
- **Weighting:** most pools mark a few lines "occasionally important" — recommend weight 1×
  for mundane, 1× mysterious, and a *lower* weight (0.4×) for important lines so heavy lore
  lands rare but inevitable.
- **Category routing:** context decides the pool (craft→crafting family, abyss encounter
  category→matching abyss pool). Never pick cross-category at random.
- **Tone mix target:** roughly 40% mundane/warm, 25% funny, 25% mysterious, 10% important.
  Every pool above ships with more mundane+funny than important, by design.

## Writing rules used (so future additions match)

1. Speaker is implied, never labeled, never the bot persona (bot personas are explicitly
   forbidden from inventing lore mid-chat — engine.js:3400).
2. Canon vocabulary only: the Infection, The Infected, Divine Spark, void-touched, the realms,
   the Abyss, the veil (GOD-canon shared), dungeons as epicenters. NO Kosmion name-drops until
   the owner canonizes the term in-game (it stays a map/documents-level name for now).
3. Never explain mechanisms. Time distortion, alternate selves, other worlds are *observed*
   and *mistrusted*, never lectured.
4. No emoji inside drops (plain WhatsApp text; nothing to strip).
5. Sentence openings are varied deliberately (count them: "I", "You", imperative, fragment,
   "The", "My", "Some/They say", question, "Don't", proper noun, "Come back"…). No more than
   two consecutive lines in any pool may open with the same word.
6. Abyss creature lines NEVER name or recognize the species (brief §16 rule).
7. Timeline-person lines escalate suspicion gradually (early lines = odd details; late lines =
   wrong-year coins), never the word "timeline".
8. Alternate-self lines escalate from shock → dark humor → unease; they may echo the
   established GOD-dungeon Floor 4 beat but never cite it.
