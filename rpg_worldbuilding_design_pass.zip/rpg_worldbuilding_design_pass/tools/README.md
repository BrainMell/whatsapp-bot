# Reproducibility tools (pass 2)

- `wm2_helpers.py` + `wm2_concepts.py` + `world_maps2.py` — the three cosmology map
  concepts (A wheel / B sea / C pillar) × 3 reveal states. Run `python3.13 world_maps2.py`.
- `card_kit.py` + `cards.py` — decree card chrome + all card mockups. Run
  `python3.13 cards.py`. NOTE: no `lore_drop_line` (removed per owner review); art comes
  from `assets/researched/` or `art_placeholder()` slots; `pixel_art_window()` handles
  small pixel sprites (NEAREST upscale, sheet-cell crop).

Fonts expected in `assets/ui/` (repo references). Maps render via cairosvg; cards via PIL.
