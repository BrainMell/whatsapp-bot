# Existing Card System — Visual Identity Reference

> Everything a new card design must comply with. Verified in source:
> `Bot_genaration/pkg/cardstyle/palettes.go`, `pkg/combat/{theme,portrait,eventcards}.go`,
> `pkg/economy/*`, `whatsapp-bot/core/utils/goImageService.js`, `core/rpg/profileCardRenderer.js`,
> `docs/CARD-SYSTEM.md` (v5).

---

## 1. The two rendering stacks

| | Stack A — Go image service | Stack B — Node canvas |
|---|---|---|
| Runs on | Box 2 + Box 1 relay, pm2 `bot-generation-go` | inside the bot process |
| Draws with | Go `gg` (fogleman) | node-canvas |
| Renders | combat scenes, portrait cards, economy/money cards, grids, boards | character profile card, style sheet, allocate card |
| Fonts | Cinzel / CinzelDecBold / MedievalSharp / IM Fell / PressStart2P / Inter / Kenney (DejaVu = system, runes only) | Cinzel-Variable, CinzelDecorative, MedievalSharp, IM Fell, PressStart2P, Pixeloid/dogica |

**Routing rule:** dense/status/general RPG cards → Stack A themed; personal-identity surfaces
(ship card, profile card) → Stack B bespoke; **battle cards are ALWAYS Stack A baked decree art**
(owner decision, never themed).

## 2. The ten styles (player identity via `.j cardstyle`)

Stored on `User.cardStyle` (User.js:34; 0 = follow server default `_shared_default_card_style`).
Names (rpgCommands.js:1530): **1 Stonekeep · 2 Golden Arcanum · 3 Retro Court · 4 Woodmere ·
5 Emblem Noir · 6 Soul Forge (older docs: "Holo Gacha") · 7 Royal Decree · 8 Neon Arcade ·
9 Rune Monolith · 10 Crimson Court.**

⚠️ Two palette sets exist in Go. **`pkg/cardstyle/palettes.go` is canonical** (used by the v2
`style01..10.go` renderers and economy painters). `theme.go cardThemes` is the legacy fallback
shell. Values below are **palettes.go**, verified:

| Style | Bg | Panel | Ink | Muted | Accent | Accent2 | Seal | Caption |
|---|---|---|---|---|---|---|---|---|
| 1 Stonekeep | `#4A4C52→#33353B` | `#A8AAAE` (ed `#232529`) | `#1A1C20` | `#4A4E56` | `#2C2E34` | `#FFB340` | `#2C2E34` | `#4A4E56` |
| 2 Golden Arcanum | `#171232→#241C46` | `#282146` α242 | `#F0E6BE` | `#BAAC84` | `#D4AF37` | `#8CC8A0` | `#78581C` | `#BAAC84` |
| 3 Retro Court | `#DECEAA→#E8DCBC` | `#F0E4C4` | `#3A2C20` | `#705840` | `#7A2C3A` | `#466E50` | `#7A2C3A` | `#705840` |
| 4 Woodmere | `#583A22→#422A18` | `#E2C08E` (ed `#3C2814`) | `#34220F` | `#74522E` | `#D68A2E` | `#F0B45E` | `#6E4622` | `#74522E` |
| 5 Emblem Noir | `#0E0E10→#18181C` | `#1E1E22` | `#EEECE6` | `#9E9A92` | `#C6A664` | `#94202C` | `#94202C` | `#9E9A92` |
| 6 Soul Forge | `#1B1B30→#232345` | `#20203A` α235 | `#ECE4CC` | `#A89F8A` | `#C9A961` | `#7FD7D0` | `#2A2A4A` | `#C9A961` |
| 8 Neon Arcade | `#0A0C1C→#121630` | `#10142C` α235 | `#E0F2FF` | `#80A8D0` | `#FF40A0` | `#40E0FF` | `#FF40A0` α230 | `#80A8D0` |
| 9 Rune Monolith | `#2C322E→#1E2220` | `#424A44` | `#E0E6D6` | `#9CA698` | `#E88C40` | `#FFBE78` | `#B44618` | `#9CA698` |
| 10 Crimson Court | `#420C16→#2C0810` | `#601622` α242 | `#F4E2CE` | `#C69C92` | `#D4A856` | `#E8DCC8` | `#8C1824` | `#C69C92` |
| 7 Decree (baked) | `#18100A` bg | parchment `#E9D7AB` | `#342010` | `#785828` | gold `#AA823C` | — | wax `#801C28` tx `#FAD278` | `#785828` |

Decree ink roles (theme.go:64-80, byte-identical legacy): Plate `#3E2C1C`, PlateTx `#D6AA52`,
BannerTx `#F4D68C`, BannerEdge `#AA823C`, PillBg `rgba(96,62,24,235)`, Fill `#D6AA52`,
Done `#6EA050`. **Any new palette role must be added to `decreeTheme()` first** (documents the
default), then to all ten themes.

## 3. Framing contracts (reuse, don't reinvent)

- `drawPortraitShell(dc, th, kind)` — theme.go:273-363: vertical Bg gradient → motif → banner
  band y18-108 (fold notches x46/x554; banner text CinzelDecBold 30) → name plate (60,132) 270×54
  r10 → main panel (55,208) 490×624 → gold dividers y266/271/492 → footer rule y900.
- `FrameStyle` per style: 1 bevel+rivets · 2 double gold hairline + corner diamonds · 3 burgundy
  double rules + dots · 4 inset gold line + corner ticks · 5 white rounded + sparkles · 6 neon
  glow stack · 7 carved grooves + ember ticks · 8 ornate gold double + diamonds · 9 carved notch
  · default = decree gold hairline rounded (inset 10, lw1.5, r6).
- Shared helpers (eventcards.go): `sealAt` (wax seal, ≤4 runes), `captionAt` (MedievalSharp 20,
  ink `rgb(176,140,96)`, truncate >52 runes, default "the guild watches"), `darkPill`
  (`rgba(8,8,8,150)` / `rgb(250,210,120)`), `drawRows` (label `rgb(120,88,40)` / value
  `rgb(52,32,16)`), `drawSceneWindow` (cover-crop env asset + 46/255 black overlay, gradient
  fallback — brightness up!), `portraitFitText` (auto-shrink — never hardcode sizes).
- Wax seal literals: fill `rgba(128,28,40,245)`, rim `rgb(70,12,20)` lw3, inner ring
  `rgb(220,150,90)`, text `rgb(250,210,120)`.

## 4. Canvas sizes & kinds (portrait.go)

- Portrait family **600×1000**: DUEL, QUEST, TRIAL, RANK, ALLOCATE, ABYSS_ENTRY, ABYSS_RESULT
  (baked `bg_<KIND>.png` + decree inks) and styled v2: RANK, ALLOCATE, SKILLUP.
- Custom: QUESTSTART/RAID 1000×600 · GUILDINFO 800×800 · SKILLTREE 1200×1000 · EQUIP 1500×1000 ·
  ABILITIES 1000×dynamic(700..1400) · SHOP 800×dynamic(step 168).
- Economy/transaction **1000×600**: BALANCE, TRANSFER, DEPOSIT, WITHDRAW, CRAFT, BREW, COOK,
  FORGE, FISH, DECREE (`econTypeTitle` maps BREW→"BREWED", FORGE→"FORGED", FISH→"CATCH OF THE
  DAY", DECREE→"RANK UP").
- `portraitRequest` carries ~45 optional fields (kind, nickname, caption, sealText, ledger[],
  players[], progress[], entries[], slots[], style, playerClass/playerIndex, emblem, …) — new
  card kinds add fields here + a `render<Kind>Card` + registration in `styledKinds()` +
  per-style dispatch switches, OR stay baked with a new `bg_<KIND>.png`.

## 5. Baked backgrounds inventory (Bot_genaration `assets/rpgasset/ui/craft/`)

1000×600: `bg_CRAFT bg_BREW bg_COOK bg_FORGE bg_FISH bg_DECREE bg_HUNT bg_BOSS bg_QSTART bg_RAID`
· 600×1000: `bg_DUEL bg_QUEST bg_TRIAL bg_RANK bg_ALLOCATE bg_ABYSS bg_SKILLUP bg_VICTORY
bg_DEFEAT` · 800×800 `bg_GUILD` · 1200×800 `bg_TREE` · 1200×1000 `bg_TREE2`.
Node `core/rpgasset/ui/styles/`: `bg_1..bg_10.png` (800×1100) + `layouts.json` (op-DSL).
Environments: `assets/rpgasset/environment/spark_1..10, spark_15, *_night` (640×480).

**No world-map, no NPC-portrait, no fortune-teller, no afterlife art exists anywhere.**

## 6. Fonts (exact files)

- Go: `assets/rpgasset/ui/craft/Cinzel.ttf`, `CinzelDecBold.ttf`, `MedievalSharp.ttf`;
  `craft/fonts/IMFellEnglish-Regular|Italic.ttf`, `PressStart2P-Regular.ttf`;
  `assets/rpgasset/ui/Inter-Medium|SemiBold.ttf`, `KenneyFuture.ttf(.Narrow)`.
- Node: `core/rpgasset/fonts/` — Cinzel-Variable, CinzelDecorative-Bold/Black, MedievalSharp,
  IMFell ×2, PressStart2P, PixeloidSans, dogicapixel(.bold); `core/rpgasset/ui/fantesy.ttf`.
- DejaVuSans is the **system** font for effect runes only (Cinzel/MedievalSharp have NO symbol
  coverage; verified rune whitelist ✦✺❄♨⚔☠✥✚▲▼◈✷⚡❖⨀⚑; ⌛⛨⛓ tofu).
- Fonts are cached after first parse (`pkg/utils/utils.go:81-107`) — do not re-parse per call.

## 7. Integration contracts a new card must honor

1. **Text fallback:** every `goImageService` method returns `Buffer | null` (timeout 10 s,
   queue 3-slot semaphore) — the Node caller MUST have a text path (cards may never dead-end).
2. **Image first, text as caption** — any flow gaining a card sends the image BEFORE the text;
   the old text becomes the caption (never image-only, never text-only).
3. **Style duty:** general RPG cards must work across all 10 styles via `cardstyle.Palette`
   roles — no hardcoded hex where a role exists. Style 0/7/invalid → baked Decree art.
4. **Sanitize:** `cardstyle.Sanitize` NFKD-transliterates and strips emoji/symbols — NPC dialogue
   in cards must survive it (ASCII-safe punctuation, no emoji in card text).
5. **QA bar:** render the full style matrix, LOOK at every PNG, live-verify through the real
   command path, pixel-probe when suspicious (docs/CARD-SYSTEM.md §11).

## 8. Consequences for THIS design pass

- `.j world` map = **new card kind** ("WORLDMAP" or similar) → either baked decree-style map art
  (600×1000 or a new landscape bake) or a themed 10-style shell — design concepts in
  `world_map/` show both routes; the mockups default to **baked Decree** (map = world-document,
  same reasoning as battle cards, plus a cosmic alternative).
- NPC cards (blacksmith/brewer/fortune teller) = portrait-family 600×1000 bakes
  (`bg_SMITH`, `bg_BREW` exists, `bg_SEER`…) with `drawSceneWindow` character art windows —
  concepts in `image_cards/`.
- Lore drops themselves are **text**, not cards: `╒ *…* ╛` appended to captions/messages —
  see lore_drops/README.md for the formatting contract.
