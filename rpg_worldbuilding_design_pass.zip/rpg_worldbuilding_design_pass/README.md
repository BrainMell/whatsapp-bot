# RPG Worldbuilding & Visual Design Pass — README

**Status:** research + design + prototyping package ONLY. **The live bot was not modified.**
`.j lore` was not touched. No code, schema, or command changes were made anywhere.
Repo state inspected: `whatsapp-bot` @ `audit/fix-pass-1` `31be194f`, `Bot_genaration` @ `main` `01ab7e0`.

---

## 1. What this package is

An overnight investigation-and-design pass by an agent that started with **no context of this
RPG**: it read the codebase and documentation end-to-end, reconciled the design brief with
established canon, then produced world-map concepts, NPC/encounter card mockups, substantial
lore-drop pools, asset research, implementation plans, and alternative directions — everything
 packaged for the owner's critique. **Nothing is implemented; implementation begins only after
the owner's corrections.**

## 2. What was investigated (and where the notes live)

| Area | Findings document |
|---|---|
| The RPG as a whole (architecture, progression, combat, economy) | `investigation/existing_rpg_summary.md` |
| `.j lore` verbatim canon + Boundless Void + Abyss lore + naming reconciliation | `investigation/existing_lore.md` |
| The 10-style card system, exact palettes, renderers, fonts, fallback contracts | `investigation/existing_card_system.md` |
| Every command surface where a lore drop could attach (file:line) | `investigation/existing_commands.md` |
| How features would physically integrate (modules, payloads, risks) | `investigation/architecture_notes.md` |

Key discovery highlights:
- Shipped canon names the two primordials **Divine Architect** and **Primordial Chaos** (the
  brief's "Chaos and Order"); players carry "a fragment of that celestial power" (Divine
  Sparks). The brief's cosmology maps onto this 1:1 except two open slots documented, not
  resolved (see `investigation/existing_lore.md` §2).
- **"Kosmion" appears nowhere in code** — clean working name. **No world map exists** (no
  command, no assets). **No afterlife, no fortune teller, no race NPCs exist** (verified).
- The GOD-rank dungeon "The Boundless Void" already contains alternate-self and
  time-distortion lore (Floor 4 / Floor 3) — the brief's Abyss ideas echo established beats.
- Naming collisions found and documented: dungeon zones literally named "Infected Afterlife"/
  "Pre-Infected Afterlife", and "beyond the veil" already means GOD ascension
  (`investigation/existing_lore.md` §5-§6).
- Kill stats are solid ground for souls: `user.stats.kills` increments at ONE choke point;
  `trackMissionStat` auto-persists new stat keys; no souls/deaths fields exist yet.


## 3. REWORKED per owner review (pass 2)

The owner reviewed pass 1 and corrected five things; the package now reflects them:

1. **"Assets" meant finding real assets online — not AI-generating them.** All 22 AI renders
   were deleted. `assets/researched/` now holds **12 sourced online packs** (OpenGameArt /
   CC0 / OGA-BY / CC-BY, manifest with source URL + license per file) plus manual-pickup
   leads (Kenney CC0, CraftPix, itch.io, LPC) in `assets/README.md`.
2. **The world map was rebuilt as a multiversal cosmology** — three concepts inspired by the
   DC Multiverse Map, Marvel's cosmology charts and Dragon Ball's universe organization,
   rendered in the Royal Decree style: **A The Sundered Wheel** (quadrant survey wheel,
   cracked seal at the center), **B The Sea of Worlds** (world-bubbles on an ink sea around
   the First Seam, the Abyss as a tear in the page), **C The Woven Pillar** (world-tree-style
   column: unnamed crown / weave of worlds / abyss depth strata). Each in early/mid/late
   reveal states. `world_map/README.md` maps every element to its inspiration.
3. **Cards: the chrome work was accepted; the AI art is gone.** Card windows now hold
   researched sprites (pixel packs, NEAREST-upscaled) or labeled **art slots** pointing at
   the research. The lore-drop line element was **removed from the card kit**.
4. **Abyss encounters are not image cards.** They render as plain encounters through the
   existing pipeline — right enemy sprite + ability set + kill hooks. Parity mockups:
   `image_cards/world/abyss_encounter_normal_{kobold,contact}.png`;
   spec in `implementation/abyss.md` §5.
5. **Lore drops are occasional plain chat text** (`╒ *line* ╛`), never baked into cards and
   never rendered as card captions. Contract updated in `lore_drops/README.md` and
   `implementation/lore_drop_system.md`.

## 4. What was designed

### World map — `.j world` (`world_map/`, README inside)
Seven directions, 14 renders, with a consistent content contract (unnamed home world,
fogged rift worlds, the Abyss as a *wound* not a world, the GOD area as a **tear in the map
frame**, the afterlife as a late-game shoreline, "Kosmion" always titled as a working name):

| Concept | Direction | States |
|---|---|---|
| A | Royal Decree parchment cartography | early/mid/late |
| B | Golden Arcanum star-glass (magical) | early/late |
| C | Cosmic constellation sea | early/mid/late |
| D | Dark mysterious vellum | mid/late |
| E | Decree × cosmic hybrid (recommended default) | mid/late |
| alt F | Rune Monolith carved plate | mid |
| alt G | Retro Court atlas plate | mid |

Progression model documented (early→mid→late triggers), per-player state schema proposed,
future-expansion plan (anchor table) included — nothing implemented.

### Image cards (`image_cards/`, README inside)
18 mockups using the exact house chrome (decree palette, Cinzel/DecBold/MedievalSharp, banner
band, nameplate, wax seal, dark pills) with the lore-drop line rendered in the `╒ *…* ╛`
format: blacksmith ×3 (incl. Stonekeep variant + split-ledger alternative), brewing ×2
(landscape matching the live BREW family + witch portrait), soul-sight ×3 (locked gate as
world rule / unlocked count / Soul-Forge seer), afterlife ×2, Abyss encounters ×5 (one per
pool: unknown creature, player-like, distorted, alternate self, other-timeline), world card
×1, composition alternatives ×2.

### Lore drops (`lore_drops/`, README = format & frequency contract)
**10 pools / ~230 original lines** in the brief's 14 categories: blacksmith (25), brewing
(25), crafting (23), enchanting (20), healing (21), trading (20), fortune_teller (30),
general_world (25), abyss ×5 sub-pools (54: unknown creature 12 / player 10 / distorted 10 /
timeline person 10 / self variant 12), afterlife (31 incl. PROPOSED pool). All italic-text
format, varied structures, tone-mixed (mundane/funny/mysterious/important), canon-vocabulary-
only, with the brief's §16 rules enforced (no species recognition, gradual timeline suspicion,
deniable alternate selves).

## 5. Assets (`assets/` + `asset_sources/`)

- **No AI art.** The 22 pass-1 AI renders were removed at owner review; prompts file deleted.
- **Researched & downloaded** (`assets/researched/`): 12 online-sourced packs with per-file
  license manifest (`SOURCES_manifest.json`) — NPC pack (OGA-BY 3.0, Snabisch), dwarf
  (CC-BY/OGA-BY 3.0, pakapikk lineage — 63×85, near-exact fit for the bot's 64×96 sprite
  format), witch strips, dark-elf character faces, enemy sheets, dungeon tileset,
  1-Bit Doomsphere charset (CC0), Tiny32 repack (CC0) — plus internal reference copies of
  the bot's own enemy sprites for the encounter-parity mockups.
- **Internal references** copied from the repos (house fonts in `assets/ui/`, bg/spark refs
  noted in investigation docs) — zero licensing risk.
- **Leads** for manual pickup (Kenney CC0, CraftPix free, itch.io, LPC generator) documented
  in `assets/README.md` with license status per lead.

## 6. Canon vs proposed vs experimental (summary)

- **Established (untouched):** the creation myth, The Great Envy, The Infected, Divine Sparks,
  the Abyss origin lore, the Boundless Void + its 7 floor narrations, all existing zones/items/
  classes with soul vocabulary (Reaper→Death Lord, Soul Forging, SOUL_RIP, veil_of_the_void…).
- **Proposed (designed, awaiting approval):** `.j world` command + map kinds, all lore-drop
  pools + the 8-12% × 30-min-cooldown system, NPC cards on forge/brew flows, the SOULS
  soul-sight feature (gate, ceremony, ledger), Abyss encounter-category drops, the 3 schema
  fields in `implementation/database_considerations.md`.
- **Experimental / needs review (segregated):** abyss-souls behave differently (brief §22 —
  kept in PROPOSED pools), the one-veil-two-doorways reading, zone-name collision resolutions,
  timeline tint ring, per-tenant smith cast, book-of-the-slain (rejected for cost, documented).

## 7. Unresolved questions (owner decisions)

1. Naming: "Kosmion" confirmation · the unnamed God-Rank world stays nameless (delivered as
   "BEYOND — the map breaks here") · the Afterlife stays unnamed (delivered as "the shoreline
   beyond the veil").
2. The "Infected Afterlife" zone collision (ideas.md #2).
3. Souls backfill (0 vs current kills) · PvP exclusion · gate numbers (level 40 vs rank B).
4. Seer identity pick (3 concepts delivered).
5. The one-veil cosmology entanglement (ideas.md #1) — approve or keep separate.

## 8. Licensing concerns (details in `assets/README.md` + `SOURCES_manifest.json`)

- Downloaded packs: OGA-BY 3.0 / CC-BY 3.0 items require **attribution** (manifest entries
  carry author + source URL; wire into credits when promoted); CC0 items have no strings;
  CC-BY-SA items (witch strips) are share-alike — flag before production use.
- Fonts: all already shipped inside the project repos (OFL family) — no new font adoption.
- Leads not yet downloaded remain leads — nothing unverified is bundled.

## 9. Implementation considerations (when approved)

`implementation/` contains the build plans: `world_map.md` (command flow, Go payload, map
state, unlock triggers, expansion table), `lore_drop_system.md` (module shape, per-surface
chances, cooldowns, rings, rollout order), `npc_cards.md` (fixed cast, art pipeline, style
compatibility pricing), `abyss.md` (category routing, the enemy-tagging question, escalation
by depth), `afterlife.md` (exact wiring to the single kill-choke-point, ceremony-once guard,
open decisions), `database_considerations.md` (3 additive fields, strict-mode discipline, what
deliberately needs NO persistence).

Implementation constraints the plans respect: Mongoose strict mode (same-commit field
declarations), text fallback for every card, image-first/caption contract, Go pm2 restart
after new assets, no Python edits of engine.js, lore drops are pure in-memory (zero risk to
the 450MB RAM line), and all five Abyss floor-advancing handlers stay in sync.

## 10. Recommended review order

1. `investigation/existing_lore.md` §2 + §5-6 — the canon reconciliation + naming collisions
   (everything else depends on these rulings).
2. `world_map/README.md` then concept A → E → C renders (pick a direction).
3. `image_cards/README.md` then the blacksmith + souls mockups (the two flows nearest shippable).
4. `lore_drops/README.md` (frequency contract) then skim pools — mark lines to cut.
5. `implementation/afterlife.md` §7 — the five blocking decisions.
6. `additional_ideas/ideas.md` — keep/cull.
7. Everything else at leisure; the package keeps ALL alternatives on purpose (brief §31).

## 11. Package map

```
rpg_worldbuilding_design_pass/
├── README.md                  ← you are here
├── investigation/             5 docs (rpg summary, lore, cards, commands, architecture)
├── world_map/                 7 concepts, 14 renders + README
├── image_cards/               18 mockups in 7 families + README
├── lore_drops/                10 pools (~230 lines) + README contract
├── assets/                    22 AI art + repo references + prompts manifest
├── asset_sources/             sources_and_licenses.md
├── implementation/            6 build-plan docs
└── additional_ideas/          ideas.md (12 labeled ideas)
```

**The promise kept:** `.j lore` untouched · zero production changes · all alternatives kept ·
every claim in this package traceable to a file:line or an explicit "does not exist (verified)".
