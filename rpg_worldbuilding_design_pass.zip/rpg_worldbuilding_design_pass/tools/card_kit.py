#!/usr/bin/env python3.13
"""card_kit.py — house-accurate card primitives for design mockups (PIL).

Mirrors the Go family's geometry/colors (theme.go decreeTheme, eventcards.go helpers)
so mockups compare 1:1 with live cards. Canvas 600x1000 (portrait family) default.
"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_DIR = "/home/z/my-project/download/rpg_worldbuilding_design_pass/assets/ui"

# decree ink roles (theme.go:64-80)
DECREE = dict(
    Bg=(24, 16, 10, 255), Panel=(233, 215, 171, 255), Plate=(62, 44, 28, 255),
    PlateTx=(214, 170, 82, 255), Banner=(62, 44, 28, 255), BannerTx=(244, 214, 140, 255),
    BannerEdge=(170, 130, 60, 255), Ink=(52, 32, 16, 255), Muted=(120, 88, 40, 255),
    Sub=(84, 96, 44, 255), Gold=(170, 130, 60, 255), PillBg=(96, 62, 24, 235),
    PillTx=(244, 214, 140, 255), Track=(54, 36, 18, 255), Fill=(214, 170, 82, 255),
    Done=(110, 160, 80, 255), Seal=(128, 28, 40, 255), SealTx=(250, 210, 120, 255),
    Caption=(176, 140, 96, 255),
)

_font_cache = {}
def F(name, size):
    key = (name, size)
    if key not in _font_cache:
        files = {"cinzel": "Cinzel.ttf", "cinzeldec": "CinzelDecBold.ttf",
                 "medsharp": "MedievalSharp.ttf", "imfell_i": "IMFellEnglish-Italic.ttf"}
        _font_cache[key] = ImageFont.truetype(f"{FONT_DIR}/{files[name]}", size)
    return _font_cache[key]

def fit_text(draw, text, font_name, size, max_w, min_size=10):
    while size > min_size:
        f = F(font_name, size)
        if draw.textlength(text, font=f) <= max_w:
            return f
        size -= 1
    return F(font_name, min_size)

def canvas(w=600, h=1000, bg=(24, 16, 10, 255)):
    return Image.new("RGBA", (w, h), bg)

def vignette(im, strength=90):
    w, h = im.size
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    d.ellipse([-w*0.35, -h*0.25, w*1.35, h*1.25], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(120))
    black = Image.new("RGBA", (w, h), (0, 0, 0, strength))
    im.alpha_composite(Image.composite(Image.new("RGBA",(w,h),(0,0,0,0)), black, m))
    return im

def banner_band(im, text, y0=18, y1=108, color=DECREE["Banner"], tx=DECREE["BannerTx"],
                edge=DECREE["BannerEdge"]):
    d = ImageDraw.Draw(im)
    w = im.size[0]
    d.polygon([(70, y0), (w-70, y0), (w-46, (y0+y1)//2), (w-70, y1),
               (70, y1), (46, (y0+y1)//2)], fill=color, outline=edge, width=2)
    f = fit_text(d, text, "cinzeldec", 30, w-220)
    d.text((w//2, (y0+y1)//2), text, font=f, fill=tx, anchor="mm")

def nameplate(im, name, x=60, y=132, w=300, h=54):
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([x, y, x+w, y+h], 10, fill=(8, 8, 8, 170),
                        outline=DECREE["Gold"], width=1)
    f = fit_text(d, name, "cinzeldec", 24, w-24)
    d.text((x+w//2, y+h//2), name, font=f, fill=DECREE["PillTx"], anchor="mm")

def panel(im, box, fill=DECREE["Panel"], edge=(90, 70, 40, 26), outline=DECREE["Gold"]):
    d = ImageDraw.Draw(im)
    d.rounded_rectangle(box, 8, fill=fill, outline=outline, width=2)

def gold_hairline(im, inset=10, lw=2, r=6):
    d = ImageDraw.Draw(im)
    w, h = im.size
    d.rounded_rectangle([inset, inset, w-inset, h-inset], r,
                        outline=DECREE["Gold"], width=lw)

def art_window(im, art_path, box, overlay=46, frame=True):
    """drawSceneWindow equivalent: cover-crop + dark overlay."""
    x0, y0, x1, y1 = box
    art = Image.open(art_path).convert("RGBA")
    bw, bh = x1-x0, y1-y0
    scale = max(bw/art.width, bh/art.height)
    art = art.resize((int(art.width*scale)+1, int(art.height*scale)+1))
    cx, cy = art.width//2, art.height//2
    art = art.crop((cx-bw//2, cy-bh//2, cx-bw//2+bw, cy-bh//2+bh))
    dark = Image.new("RGBA", art.size, (0, 0, 0, overlay))
    art.alpha_composite(dark)
    im.paste(art, (x0, y0))
    if frame:
        d = ImageDraw.Draw(im)
        d.rectangle(box, outline=DECREE["Gold"], width=2)

def rows(im, items, x_label, x_val, y0, step, max_val_w=150, label_c=None, val_c=None,
         size=19):
    d = ImageDraw.Draw(im)
    label_c = label_c or (120, 88, 40, 255)
    val_c = val_c or (52, 32, 16, 255)
    y = y0
    for k, v in items:
        fl = F("cinzel", size)
        d.text((x_label, y), k, font=fl, fill=label_c)
        vw = d.textlength(v, font=fl)
        d.text((x_val + max_val_w - vw, y), v, font=fl, fill=val_c)
        y += step
    return y

def dark_pill(im, text, cx, y, pad=16, size=17):
    d = ImageDraw.Draw(im)
    f = fit_text(d, text, "cinzel", size, 500)
    tw = d.textlength(text, font=f)
    box = [cx-tw/2-pad, y-6, cx+tw/2+pad, y+f.size+8]
    d.rounded_rectangle(box, (box[3]-box[2])//2, fill=(8, 8, 8, 150))
    d.text((cx, y+(f.size)//2), text, font=f, fill=(250, 210, 120, 255), anchor="mm")

def wax_seal(im, cx, cy, r, text):
    d = ImageDraw.Draw(im)
    d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=(128, 28, 40, 245),
              outline=(70, 12, 20, 255), width=3)
    r2 = int(r*0.72)
    d.ellipse([cx-r2, cy-r2, cx+r2, cy+r2], outline=(220, 150, 90, 255), width=2)
    f = F("cinzel", int(r*0.8))
    d.text((cx, cy), text, font=f, fill=(250, 210, 120, 255), anchor="mm")

def caption(im, text, cx, y, max_w=480, color=None, size=20):
    d = ImageDraw.Draw(im)
    color = color or (176, 140, 96, 255)
    f = fit_text(d, text, "medsharp", size, max_w)
    if d.textlength(text, font=f) > max_w and len(text) > 52:
        text = text[:49] + "..."
        f = fit_text(d, text, "medsharp", size, max_w)
    d.text((cx, y), text, font=f, fill=color, anchor="mm")

_dejavu = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
def _dv(size):
    return ImageFont.truetype(_dejavu, size)

def art_placeholder(im, box, label_txt="ART SLOT — pick from assets/researched/ (see SOURCES.md)"):
    """Neutral hatched slot marking where researched online art goes (NO AI art)."""
    x0, y0, x1, y1 = box
    d = ImageDraw.Draw(im)
    d.rectangle([x0, y0, x1, y1], fill=(210, 190, 150, 255), outline=DECREE["Gold"], width=2)
    step = 26
    span = (x1 - x0) + (y1 - y0)
    t = 0
    while t < span:
        sx, sy = x0 + max(0, t - (y1 - y0)), y0 + min(t, y1 - y0)
        ex, ey = x0 + min(t, x1 - x0), y0 + max(0, t - (x1 - x0))
        d.line([(sx, sy), (ex, ey)], fill=(190, 168, 128, 110), width=1)
        t += step
    f = fit_text(d, label_txt, "medsharp", 18, (x1-x0) - 60, min_size=11)
    d.text(((x0+x1)//2, (y0+y1)//2 - 14), label_txt, font=f, fill=(110, 84, 44, 255), anchor="mm")
    d.text(((x0+x1)//2, (y0+y1)//2 + 14), "(placeholder — no AI imagery in this package)",
           font=F("medsharp", 13), fill=(130, 100, 60, 235), anchor="mm")
    return im

def dividers(im, y_list, x0=60, x1=540, gold=True):
    d = ImageDraw.Draw(im)
    c = DECREE["Gold"]
    for i, y in enumerate(y_list):
        lw = 2 if i == 0 else 1
        d.line([x0, y, x1, y], fill=c, width=lw)

def stat_bar(im, x, y, w, h, frac, track=DECREE["Track"], fill=DECREE["Fill"]):
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([x, y, x+w, y+h], h//2, fill=track)
    if frac > 0:
        d.rounded_rectangle([x, y, x+max(h, int(w*min(1, frac))), y+h], h//2, fill=fill)
