# Lore Drops — Brewing / Alchemy / Cooking (elves, witches, tavern keepers)

> Pool for `.j brew`, `.j cook` successes and failures.
> Format contract: rendered as `╒ *line* ╛`, italics on the text only.

## Usage notes

- Speaker implied: an elf alchemist, a hedge-witch, a tavern cook — whoever plausibly stands
  behind the result. The bot's examples were elf/witch flavored; keep the pool mixed so it
  doesn't read as one character.
- Canon hooks used: the Abyss (time distortion is established — "months... came back an old
  man"), the Infection, realms/Kosmion-adjacent phrasing ("this world", "the endless realms").
- Food and drink should feel safe and warm — the contrast is what makes the eerie lines land.

## Pool — mundane / warm

1. ╒ *Stir it widdershins if you want courage, deosil if you want sleep. You looked like you needed the sleep.* ╛
2. ╒ *My grandmother's recipe. She'd be furious I'm selling it. She'd also be rich.* ╛
3. ╒ *Don't sniff it before you drink it. Trust me. You'll talk yourself out of a cure.* ╛
4. ╒ *Honey from the high meadows, where nothing blooms that shouldn't. Worth the climb, every jar.* ╛
5. ╒ *The secret isn't the mushroom. Everyone asks about the mushroom. The secret is patience.* ╛
6. ╒ *Cooked on a fire of apple wood. Iron pots make soup taste like apologies.* ╛
7. ╒ *An adventurer ate here once and wept. Compliment or warning, I never decided.* ╛
8. ╒ *One cup for the ache, two for the memory. Don't ask which memory. It picks.* ╛
9. ╒ *I water the herbs with rain I catch in the graveyard. Best in the county. Nothing grows weeds back there.* ╛
10. ╒ *You get used to brewing for people who might not come back for the second batch. You get used to it. Mostly.* ╛

## Pool — funny

11. ╒ *My cousin tried to ferment cave-slime once. The jar is still hissing. We don't open that cupboard.* ╛
12. ╒ *That's a love tonic. Don't panic — it's WEAK. Worst case, you'll be very fond of soup.* ╛
13. ╒ *Yes, it smells like a wet dog in a thunderstorm. Drink it anyway. Healing is not a perfume contest.* ╛
14. ╒ *The recipe says 'a pinch of salt.' The recipe's author had tiny hands and big opinions.* ╛
15. ╒ *If you see colors that aren't there, they're friendly. If you see colors that ARE there — that's the ceiling, and you've had enough.* ╛

## Pool — mysterious / worldbuilding

16. ╒ *My cousin was stuck in the Abyss for months. Came back an old man. The tea didn't help. The company did.* ╛
17. ╒ *Some herbs only grow where the Infection passed and changed its mind. I won't say where I pick them. The beds refill slower than you'd think.* ╛
18. ╒ *Moon-sugar from a world with two moons tastes like Sunday morning. I get one sack a year. One.* ╛
19. ╒ *A brew remembers its ingredients' deaths, if you let it steep too long. Keep it under an hour and it stays cheerful.* ╛
20. ╒ *Elves brewed wine here before your histories had letters. The cellar is older than the tavern, the town, the road, and possibly the king.* ╛
21. ╒ *There's a mushroom down the deep that tastes like a memory of your mother's kitchen. It's a lie. It's delicious, and it's a lie.* ╛
22. ╒ *I once brewed for a party of five. Four cups. I still don't know who I skipped, and neither did they. That one haunts me.* ╛

## Pool — occasionally important

23. ╒ *Souls settle in soup, the old texts say. Nonsense, probably. Still — I always set an extra bowl. Costs me nothing.* ╛
24. ╒ *If your brew ever glows violet instead of gold, pour it on the ground and walk. It isn't spoiled. It's listening.* ╛
25. ╒ *Time behaves strangely down in the deep kitchens of the world. That's all I'll say about where the honey comes from. Drink your tea.* ╛
