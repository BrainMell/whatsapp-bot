# Lore Drops — Healing

> Pool for `.j heal` / `.j hospital` / `.j clinic` and potion use.
> Format contract: rendered as `╒ *line* ╛`, italics on the text only.

## Usage notes

- Speaker implied: a healer, nurse, apothecary, or temple orderly. The hospital in this world
  sees what adventurers bring back — that's the well this pool drinks from.
- Wounds are described as consequences of known systems: Abyss floors, pack fights, dungeon
  branching, infected zones. Never invent new medical magic.

## Pool — mundane / warm

1. ╒ *Breathe in. Hold. Out. …Good. Whatever you fought, you outlived it. That's the whole treatment today.* ╛
2. ╒ *Third time this month. I'm starting to recognize your boots in the hall.* ╛
3. ╒ *The body wants to live. My job is mostly to stop interrupting it.* ╛
4. ╒ *You'll bruise spectacular colors for a week. Pick a story you like, you'll be telling it often.* ╛
5. ╒ *Eat something. Healing on an empty stomach is like sailing on an empty river.* ╛
6. ╒ *The temple pays for adventurers' bandages out of a fund older than the temple. Nobody remembers who funded the fund. It never runs out. We've stopped asking.* ╛
7. ╒ *Rest. Not the tavern kind. The kind where the ceiling stays where you left it.* ╛

## Pool — funny

8. ╒ *You have exactly the injuries of a man who kicked something that clearly said not to.* ╛
9. ╒ *No, the potion is NOT supposed to fizz like that. …It's fine. It's fine. Probably the batch. It's fine.* ╛
10. ╒ *I said one sip. One. You drank like it was a festival. Congratulations, you're healed AND three hours sober from sleep.* ╛
11. ╒ *Half my patients are adventurers. The other half are adventurers who 'didn't need a healer.'* ╛
12. ╒ *Yes, that scar will hold its shape. No, I won't make it more dramatic. You people and your stories.* ╛

## Pool — mysterious / worldbuilding

13. ╒ *Wounds from below heal slower if you keep looking at them. Not superstition. Charts show it. We just don't ask why out loud.* ╛
14. ╒ *Abyss-bites close at the same hour they opened, the second night. Nobody knows why. Plan to be awake that night.* ╛
15. ╒ *The Infected don't come here. Doors open fine, feet just… prefer the other way. Keeps the waiting room calm.* ╛
16. ╒ *Old healers could see a person's fire guttering before the body knew. The sight ran in families. It ran out. Mostly.* ╛
17. ╒ *Bring me the arrowheads you're pulled out with. All of you, always. The drawer is nearly full. I don't know what I'm collecting. Yet.* ╛
18. ╒ *Prayers help. So does broth. I've seen prayer hold a soul at the doorstep and broth talk it back inside. Use both. Argue with me later.* ╛

## Pool — occasionally important

19. ╒ *You were speaking a language on the table. Not yours. The nurse wrote it down phonetically. If it happens again, ask for me by name.* ╛
20. ╒ *A patient from a run below floor ninety once healed overnight — every wound closed at the same heartbeat. Mine beat with his. I've written it down. Nobody's read it.* ╛
21. ╒ *Sometimes the dead are brought in breathing. Cold, quiet, breathing. We keep them warm and we don't ask. The ones who come back wrong never came through MY doors. Remember that if it matters later.* ╛
