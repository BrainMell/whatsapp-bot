# Lore Drops — Blacksmith (dwarf forge voices)

> Pool for `.j repair`, `.j blacksmith`, `.j inspect`, and forge-adjacent successes.
> Format contract: every drop is rendered as `╒ *line* ╛` — the *italics* wrap the text only.
> ~10% baseline chance on a relevant interaction (see implementation/lore_drop_system.md).

## Usage notes

- Speaker is implied, never labeled: an old smith somewhere behind the counter. Never "the
  blacksmith says:" — the framing glyphs ARE the attribution.
- Fits the established world: dungeons are real, the Infection is real, adventurers are
  ordinary customers. Dwarven-ness is implied by subject matter (family forges, old debts,
  stone/iron), never by writing an accent phonetically.
- Cite canon vocabulary only: the Infection, void-touched, Divine Spark, the Abyss, the realms.

## Pool — mundane / warm (everyday forge life)

1. ╒ *Mind the edge, that one bites back. I keep a bandage behind the counter for a reason.* ╛
2. ╒ *You adventurers bring me more work than a rockslide brings a quarry. Don't stop.* ╛
3. ╒ *My grandfather forged door-hinges. I forge things that kill monsters. Progress, I suppose.* ╛
4. ╒ *That scuff is from a cave floor. I know my cave floors. Deep ones, too.* ╛
5. ╒ *Everyone wants a legendary blade. Nobody wants to pay for a legendary whetstone.* ╛
6. ╒ *I've fixed four hundred swords and sharpened one axe I was proud of. It's the axe I remember.* ╛
7. ╒ *Don't apologize for the blood on the grip. It's cheaper than oil, and it rinses.* ╛
8. ╒ *Half the forges in the lowlands closed when the roads went bad. Mine stayed open. Adventurers eat trouble, and trouble eats steel.* ╛
9. ╒ *Come back when it's raining. The quench sings nicer in the rain.* ╛
10. ╒ *You're the third one today with frost damage on the scabbard. Going somewhere cold, are we?* ╛
11. ╒ *My wife says I love the anvil more than her. I said nothing. Never argue with a lit forge behind you.* ╛
12. ╒ *A dull blade is an insult to whoever swings it. Glad you came before it insulted you.* ╛

## Pool — mysterious / worldbuilding

13. ╒ *This steel came from below the sixth stratum. Don't ask how I know. Just don't lose it.* ╛
14. ╒ *Void-touched metal hums if you hold it to your ear at night. Yours is quiet. Be glad.* ╛
15. ╒ *Before the Infection, my family forged ploughs. Eleven generations of ploughs. Then the world needed us for something else.* ╛
16. ╒ *There was a rune-thing etched under this guard. Old script. I ground it out. Some letters are better off unread.* ╛
17. ╒ *Sparks that fall upward mean the forge-fire's seen something behind you. Yours fell normal. This time.* ╛
18. ╒ *The good ore vanished from the shallows decades ago. Everything worth mining now is deeper than anyone I've mended for has ever been.* ╛
19. ╒ *I don't engrave names on blades anymore. Had a customer come back once to ask me to scrape his off. Wouldn't say why. Paid double.* ╛

## Pool — occasionally important (rare; heavier weight, see README)

20. ╒ *The Abyss spits back metal changed. If your edge ever smells like rain in a dry room — you bring it to me FIRST. Not to a shrine, not to a mage. To me.* ╛
21. ╒ *My cousin went down chasing ore and came up wrong. Whatever lives down there doesn't just kill you. Some doors open both ways.* ╛
22. ╒ *A blade that's drunk enough monster blood starts remembering. Don't ask me how I know. Watch the edge near the fire, if it throws a shadow on its own — retire it.* ╛
23. ╒ *They say the Divine Spark burns brightest in the hand that works. That's why adventurers always find a forge. Some part of you knows.* ╛

## Speaker variants (optional second voice for variety)

24. ╒ *Apprentice! The bellows! …Forgive him. The lad's from the surface. Loud places frighten him.* ╛
25. ╒ *My granddaughter patched that seam last month. Sloppy work. Don't tell her I said so, she bites.* ╛
