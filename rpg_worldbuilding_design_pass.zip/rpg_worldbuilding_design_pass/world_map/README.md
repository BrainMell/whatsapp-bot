# World Map — Cosmology Concepts (REWORKED)

> OWNER REVIEW PASS 2: the first pass's map was rejected (read as a terrestrial parchment
> with a blob for the Abyss — no cosmology in it). The concepts below are rebuilt around a
> **multiversal structure**, with explicit inspiration notes, rendered in the **Royal Decree**
> style (parchment `#E9D7AB`, ink `#342010`, gold `#AA823C`, wax `#801C28`, Cinzel / IM Fell,
> gold hairline frame, banner cartouche, survey stamps).

## The three concepts (all alternatives kept)

| Concept | Inspiration | Structure on the sheet | Reveal states |
|---|---|---|---|
| **A — The Sundered Wheel** | Dragon Ball universe chart (organized quadrants around a seat of authority) | A great wheel of **4 survey quadrants** divided by gold spokes; center medallion = **THE SUNDERING** (cracked seal — where Order broke); worlds plotted as sigil-orbs; the Abyss = a **torn notch bitten out of the chart's rim** ("THE UNDERSIDE"); late state adds a dashed outer ring = the **unnamed crown** (God-rank) and rim cracks | early / mid / late |
| **B — The Sea of Worlds** | DC Multiverse Map (worlds as bubbles on a cosmic sea, arranged around an axis) | An ink **sea**; every world a floating bubble; center = **THE FIRST SEAM** (Order half-disc above, its shattered mirror below); rift roads as dotted gold threads; the Abyss = a **tear in the page itself** at the sea's bottom edge with reversed-hour clocks; late state adds a halo arc above the frame = unnamed crown | early / mid / late |
| **C — The Woven Pillar** | Marvel cosmology / world-tree (vertical axis: crown, trunk, roots) | A vertical column: **unnamed crown** of fire-rings on top; the **weave** = a ring of world-knots threaded on one golden thread; the pillar rules crack as Order shatters; below the plinth, the **Abyss is depth strata** (I–IV) with margin notes; Chaos fragments burn as red diamonds at the root-tips; late state adds **the far shore of the veil** (unlabeled, by law) | early / mid / late |

Files: `concept_A_sundered_wheel/wheel_map_{early,mid,late}.png`, same pattern for
`concept_B_sea_of_worlds` and `concept_C_woven_pillar`. 1000×1400 each.

## Progressive reveal (what each state means)

- **early** — `.j world` at low progression: your world + 2–3 uncharted marks; structure
  visible, content sparse. The wheel/sea/pillar *shape* is the hook.
- **mid** — after more exploration: semi-known worlds annotated ("reached through the
  rift", "heard of in taverns"), rift roads drawn, the Abyss breach/tear/strata appear as
  *warning*, not destination.
- **late** — endgame chart: full world field, unnamed crown ring revealed (still unnamed),
  cracks in the structure, abyss depth notes; veil shoreline only in C.

## Canon locks honored (unchanged from brief)

- Player's world is never named ("YOUR WORLD").
- Sibling worlds are never named — only how they were heard of.
- The Abyss is **not a world** on any concept: it is a tear, a notch, or depth — outside/
  beneath the structure, separate from Kosmion.
- God-rank realm is **never named** ("an unnamed crown of worlds / above the sea / above
  the weave — the chart will not name it").
- Afterlife is **never mapped**; at most a veil shoreline line in C-late, deliberately
  unlabeled. Stamps in A/B say so explicitly ("THE VEIL IS NOT CHARTED").
- **Kosmion** stays a working name in every subtitle.

## Iterate

`scripts/wm2_helpers.py` (palette + primitives), `scripts/wm2_concepts.py` (the three
builds), `scripts/world_maps2.py` (render 9 PNGs). Positions/labels are data — edit and
re-run `python3.13 scripts/world_maps2.py`.
