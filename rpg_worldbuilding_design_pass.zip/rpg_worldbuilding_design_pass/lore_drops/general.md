# Lore Drops — General World

> Pool for any low-stakes surface that wants atmosphere instead of system-specific voice:
> menu tips rotation, register anniversaries, idle successes, dungeon entry headers.
> Format contract: rendered as `╒ *line* ╛`, italics on the text only.

## Usage notes

- These are "the world murmuring" — a passerby, an innkeeper, a child, a notice-board voice.
  No mechanic attached. Never exposition dumps; single brushstrokes only.
- Canon constraints honored: the Divine Architect / Primordial Chaos unnamed where possible
  ("the old powers", "the ones before"); The Infected; Divine Sparks; dungeons as epicenters;
  many realms exist; the player's world is one of them.

## Pool — street & market life

1. ╒ *Mind the east road after dusk. The lanterns there gutter in pairs now. Used to be one at a time.* ╛
2. ╒ *A child drew a map of everywhere today. Nice thing about children's maps — the unknown parts look friendly.* ╛
3. ╒ *The pigeons came back to the bell tower. First time since the bad year. Nobody's told the bell-ringer. He's happy.* ╛
4. ╒ *Prices on candles again. Everyone's burning them at both ends this season. I blame the dungeons.* ╛
5. ╒ *A traveler paid for his soup with a coin bearing a moon that isn't ours. The soup was excellent. The coin is on the shelf now.* ╛
6. ╒ *Grandmother says the stars used to be closer. Grandmother also says the stars are holes. Both her stories end with 'and that's why you knock for luck.'* ╛
7. ╒ *They've repainted the guild hall doors. Third shade of red this year. The paint keeps… going somewhere.* ╛
8. ╒ *The well water tastes of iron on odd days. The well-keeper logs it. The log has a column for dreams. Don't ask which dreams.* ╛

## Pool — adventurer culture

9. ╒ *An adventurer's map has three colors: where you've been, where you're told not to go, and where you're going anyway.* ╛
10. ╒ *The veterans leave their old boots by the guild door. Nobody's counted them. Nobody wants the number.* ╛
11. ╒ *Rule one of the road: the dungeon doesn't chase you. Rule two: everything in it already knows you're coming.* ╛
12. ╒ *You can tell a fresh adventurer by the polished boots. You can tell a survivor by the polished SCABBARD.* ╛
13. ╒ *Party rules, posted: share the loot, share the food, share the watch. The last line is scratched out. It just says 'share the stories.'* ╛
14. ╒ *Every party has one who packs too much and one who packs nothing. Both are always surprised at the same river.* ╛
15. ╒ *They say the Divine Sparks favor the bold. The bold say the Sparks have a sense of humor. Both groups limp.* ╛

## Pool — quiet eeriness (worldbuilding)

16. ╒ *The Infection never reached the high passes. The shepherds up there still count their sheep by older names. Nothing up there has needed a new name in a long time.* ╛
17. ╒ *Old shrines stand at every crossroads. Older, unmarked stones stand just past them. The first ones are for asking. Nobody remembers what the second ones are for.* ╛
18. ╒ *My grandfather traded with a village that isn't there now. Not destroyed — isn't THERE. He drank with them last spring. He's stopped mentioning it. Mostly.* ╛
19. ╒ *Birds fly around the deep woods like there's glass in the sky above it. Feathers land at the edge, all pointing in.* ╛
20. ╒ *There's a night each season when every dog in town watches the same corner of the sky. No appointment. No explanation. The next morning, nothing.* ╛
21. ╒ *Cartographers argue about whether the far coast curves away or down. The ones who've sailed it don't argue. They just redraw it lower each year.* ╛
22. ╒ *The old powers broke, the priests say. The mountains disagree politely — certain peaks have kept a shape no weather explains.* ╛

## Pool — occasionally important

23. ╒ *The sky over the far wastes flickered last week. Not lightning. Flickered. Like a lamp deciding. The astronomers called it nothing. They kept watching, though.* ╛
24. ╒ *A star went out and came back dimmer, and every oracle in the city spoke at once. They all said 'not yet.' Comforting, if you like consistency.* ╛
25. ╒ *The wardens count the dungeons every solstice. The count came back one higher this year. Nobody built one. Draw your own conclusions, adventurer.* ╛
