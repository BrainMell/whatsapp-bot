# Lore Drops — Crafting (general smithing/leatherwork/carpentry voices)

> Pool for `.j craft` successes (both code paths), `.j forge`, and craft failures.
> Format contract: rendered as `╒ *line* ╛`, italics on the text only.

## Usage notes

- Speaker implied: the crafter behind the work — leatherworker, carpenter, artificer's
  apprentice, guild quartermaster. Deliberately broader than the dwarf-blacksmith pool so the
  two never feel like the same voice.
- Keep hands, materials, and workshops concrete. Lore arrives sideways (in what the material
  has seen), never as exposition.

## Pool — mundane / warm

1. ╒ *Careful with the straps the first week. Leather remembers your shoulders eventually. Not kindly.* ╛
2. ╒ *Made a hundred of these. Still hold my breath on the last stitch.* ╛
3. ╒ *Good oak, straight grain, no excuses. That's all craftsmanship ever was.* ╛
4. ╒ *Don't brag about it in town. Bragging gets it stolen, and I don't do reunions.* ╛
5. ╒ *The glue sets by moonrise. Until then, treat it like a rumor — don't repeat anything it does.* ╛
6. ╒ *You came to the right bench. Wrong week, but the right bench.* ╛
7. ╒ *I made the lock, the latch, and the box. I never made a key that couldn't be copied. Humility is a trade skill.* ╛
8. ╒ *Bring it back if the joint creaks in winter. Wood complains honestly. Metal lies.* ╛

## Pool — funny

9. ╒ *Measure twice, cut once, swear in between. That's the whole guild handbook, don't tell anyone.* ╛
10. ╒ *The customer wanted it 'menacing but approachable.' I gave up and added a ribbon.* ╛
11. ╒ *My master could make armor fit anyone. He charged extra for 'anyone' with shoulders like yours.* ╛
12. ╒ *It's not a flaw, it's a signature. Everything I make tries to kill me a little.* ╛
13. ╒ *You want it enchanted too? Talk to the witch. I make the thing. She makes the thing complicated.* ╛

## Pool — mysterious / worldbuilding

14. ╒ *This timber grew over an old battleground. Rings are full of iron flecks. Sings a little when it swings.* ╛
15. ╒ *The Infection got into the old forests before it got into anything else. Wood from those grooves — we don't cut it. We harvest what falls. respectfully.* ╛
16. ╒ *I buy my thread from a peddler who trades between the realms. Don't ask which realms. The thread doesn't like being named.* ╛
17. ╒ *Every workshop keeps one tool it doesn't talk about. Mine is the small hammer on the top shelf. It's not for sale. It's not for USING.* ╛
18. ╒ *Stone from the deep walls cuts easier at night. The quarrymen say it's dreaming. I say stone doesn't dream. I say it quietly, though.* ╛
19. ╒ *Guild marks from four kingdoms are scratched under this lid. I added mine fifth. The box is older than all of us put together.* ╛

## Pool — occasionally important

20. ╒ *Adventurer materials come in strange. Last month a hide walked in on its own — the hunter was very apologetic. Very. Apologetic.* ╛
21. ╒ *You find things in dungeon rubble that no kingdom minted and no language I know claims. I fit them into hilts anyway. They hold. They always hold.* ╛
22. ╒ *A crafter I knew made one perfect thing and quit the same day. Said his hands knew something the rest of him shouldn't. Take the compliment. Leave the lesson.* ╛
23. ╒ *There's a rumor the fragments of the old powers still sit in raw ore. Rubbish, mostly. But I've held ore that sat TOO still in the fire. Like it was watching the tongs.* ╛
