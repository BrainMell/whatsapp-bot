#!/usr/bin/env python3.13
"""wm2_concepts.py — three multiversal-cosmology concepts, Royal-Decree rendering.

A THE SUNDERED WHEEL  — quadrant survey wheel (Dragon Ball universe-chart energy)
B THE SEA OF WORLDS   — bubble multiverse on an ink sea (DC Multiverse Map energy)
C THE WOVEN PILLAR    — rooted cosmology column (Marvel world-tree energy)

Canon locks honored: player world unnamed ("YOUR WORLD"); siblings uncharted;
Abyss NOT a world (a wound / underside / roots); God-rank ring left UNNAMED;
afterlife never mapped (at most 'the far shore of the veil', late state only);
Kosmion stays a working name in the subtitle.
"""
from wm2_helpers import *  # noqa

TICKS = "".join(
    (lambda a: f'<line x1="{500+380*math.cos(a):.1f}" y1="{610+380*math.sin(a):.1f}" '
               f'x2="{500+366*math.cos(a):.1f}" y2="{610+366*math.sin(a):.1f}" '
               f'stroke="{GOLD}" stroke-width="1.1" opacity="0.7"/>')(i * math.pi / 24)
    for i in range(48))


def _cracked_center(cx, cy, r):
    s = circle(cx, cy, r, fill="#3E2C1C", stroke=GOLD, sw=2.2)
    s += circle(cx, cy, r - 8, stroke=GOLDH, sw=0.9, opacity=0.8)
    # the crack: order broke here
    s += path(f"M {cx-r+10} {cy-6} L {cx-24} {cy-2} L {cx-30} {cy-16} L {cx-2} {cy+2} "
              f"L {cx-12} {cy+14} L {cx+30} {cy+6} L {cx+r-10} {cy+2}", stroke=SEALTX, sw=2.0)
    s += path(f"M {cx-6} {cy-r+12} L {cx-2} {cy-10} L {cx+12} {cy-16}", stroke=SEALTX, sw=1.4, opacity=0.8)
    s += label(cx, cy + r + 30, "THE SUNDERING", 19, INK, family="Cinzel", weight="bold", spacing=3)
    s += label(cx, cy + r + 50, "where the order of all things broke", 13.5, "#6B4E26",
               family="IM Fell English", italic=True, spacing=0.5)
    return s


def build_A(state):
    late = state == "late"
    mid = state in ("mid", "late")
    s = [parchment(21)]
    s += [cartouche(W // 2, 92, 640, 96, "THE SUNDERED WHEEL",
                    "an official chart of the weaving of worlds — working name: kosmion")]
    # rim
    s += [circle(500, 610, 380, stroke=INK, sw=2.4), circle(500, 610, 362, stroke=GOLD, sw=1.1)]
    s += [TICKS]
    # spokes (vertical + horizontal) with gaps at center medallion
    for (x1, y1, x2, y2) in [(500, 230, 500, 536), (500, 745, 500, 990),
                             (120, 610, 430, 610), (570, 610, 880, 610)]:
        s += [line(x1, y1, x2, y2, stroke=GOLD, sw=1.6, opacity=0.8, dash="1 7")]
    s += [_cracked_center(500, 610, 74)]
    # quadrant captions on inner rim
    s += [label(250, 425, "FIRST QUARTER", 16, "#5A4326", family="Cinzel", spacing=3, rotate=-41),
          label(750, 425, "SECOND QUARTER", 16, "#5A4326", family="Cinzel", spacing=3, rotate=41),
          label(250, 815, "THIRD QUARTER", 16, "#5A4326", family="Cinzel", spacing=3, rotate=41),
          label(750, 815, "FOURTH QUARTER", 16, "#5A4326", family="Cinzel", spacing=3, rotate=-41)]
    # --- worlds
    s += [world_sigil(640, 470, 34, seed=3, known=True),
          label(640, 540, "YOUR WORLD", 21, INK, family="Cinzel", weight="bold", spacing=2),
          label(640, 560, "the world you know", 13.5, "#6B4E26", family="IM Fell English", italic=True),
          sigil_mark(628, 462, "gate"), sigil_mark(660, 480, "forge")]
    fogs = [(795, 385, 22), (300, 350, 24), (345, 800, 20), (700, 780, 22)]
    if mid:
        fogs += [(215, 590, 18), (835, 640, 18)]
        s += [world_sigil(320, 545, 22, seed=8, known=False),
              label(320, 500, "reached through the rift", 13, "#5A4326",
                    family="IM Fell English", italic=True)]
    if late:
        s += [world_sigil(760, 700, 20, seed=9)]
    for (fx, fy, fr) in fogs:
        s += [fog_world(fx, fy, fr)]
    # rift roads (mid+)
    if mid:
        s += [path("M 640 470 Q 700 400 795 385", stroke=GOLDH, sw=1.3, dash="2 6", opacity=0.9),
              path("M 640 470 Q 470 490 320 545", stroke=GOLDH, sw=1.3, dash="2 6", opacity=0.9)]
    if late:
        s += [path("M 640 470 Q 730 600 760 700", stroke=GOLDH, sw=1.2, dash="2 6", opacity=0.8)]
    # --- the underside breach (Abyss; NOT a world): an irregular tear bitten out of the chart
    s += [path("M 400 992 L 438 946 L 452 962 L 478 918 L 502 958 L 516 908 L 548 960 "
               "L 566 936 L 596 992 Z", fill=DARK, stroke="none"),
          path("M 400 992 L 438 946 L 452 962 L 478 918 L 502 958 L 516 908 L 548 960 "
               "L 566 936 L 596 992", stroke=PARCH, sw=2.5),
          label(500, 1030, "THE UNDERSIDE", 20, SEAL if not late else SEALTX,
                family="Cinzel", weight="bold", spacing=3),
          label(500, 1052, "a breach under the chart — not a world", 13.5,
                "#6B4E26", family="IM Fell English", italic=True)]
    if late:
        s += [circle(500, 990, 60, stroke=GOLD, sw=0.9, opacity=0.4),
              circle(500, 990, 40, stroke=GOLD, sw=0.8, opacity=0.35),
              circle(500, 990, 22, stroke=GOLD, sw=0.8, opacity=0.3),
              # ink specks falling into the tear
              circle(468, 1010, 2.4, fill=DARK, stroke="none", opacity=0.8),
              circle(512, 1004, 1.8, fill=DARK, stroke="none", opacity=0.7),
              circle(492, 1018, 1.4, fill=DARK, stroke="none", opacity=0.6),
              circle(536, 1014, 1.2, fill=DARK, stroke="none", opacity=0.6),
              stamp(760, 1035, "SURVEY FORBIDDEN BELOW THIS LINE", rot=-4, w=290),
              label(500, 1074, "hours do not hold beneath — the survey lost three lamps here",
                    13.5, "#6B4E26", family="IM Fell English", italic=True)]
    # --- late: the unnamed crown (God-rank) + rim cracks
    if late:
        s += [circle(500, 610, 432, stroke="#8a6a3a", sw=1.6, dash="10 8", opacity=0.65),
              label(500, 158, "AN UNNAMED CROWN OF WORLDS", 17, "#6B4E26",
                    family="Cinzel", weight="bold", spacing=4, opacity=0.85),
              label(500, 178, "beyond the rim the chart refuses", 13, "#6B4E26",
                    family="IM Fell English", italic=True),
              sigil_mark(180, 380, "crack", s=1.6), sigil_mark(830, 760, "crack", s=1.6),
              sigil_mark(500, 238, "crack", s=1.6),
              stamp(770, 215, "THE VEIL IS NOT CHARTED", rot=3, w=230)]
    # legend
    s += [legend_block(96, 258, [
        (world_sigil(0, -4, 11, seed=4, known=True), "a world — known to you"),
        (fog_world(0, -4, 11), "uncharted — the fog keeps it"),
        (line(-12, -2, 12, -2, stroke=GOLDH, sw=1.4, dash="2 4"), "a rift road — traversed"),
        (sigil_mark(0, -2, "gate", s=1.1), "a dungeon gate")])]
    s += [compass(132, 1190, 46),
          label(500, 1180, "one league — though distance lies", 13, "#6B4E26",
                family="IM Fell English", italic=True),
          line(440, 1198, 560, 1198, stroke=INK, sw=2.2),
          sheet_footer("A")]
    if late:
        s[-1] = s[-1] + stamp(800, 264, "4TH SURVEY", rot=-7, w=130)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">' + "".join(s) + "</svg>"


def build_B(state):
    late = state == "late"
    mid = state in ("mid", "late")
    s = [parchment(33)]
    s += [cartouche(W // 2, 92, 640, 96, "THE SEA OF WORLDS",
                    "every world a bubble upon the same dark water — working name: kosmion")]
    # the sea
    s += [f'<ellipse cx="500" cy="660" rx="420" ry="340" fill="#CFB27E" stroke="{INK}" stroke-width="2.2" opacity="0.95"/>']
    for i in range(14):
        yy = 330 + i * 48
        s += [path(f"M {150 + (i%3)*18} {yy} Q 300 {yy-12} 450 {yy} T 750 {yy} T 880 {yy-6}",
                   stroke=INK, sw=0.7, opacity=0.18)]
    # the first seam: order above, chaos below
    s += [ring(500, 430, 64, 58, GOLD, opacity=0.95),
          f'<path d="M 436 430 A 64 64 0 0 1 564 430 Z" fill="#EFDDB2" stroke="{GOLD}" stroke-width="1.4"/>',
          label(500, 424, "ORDER", 15, INK, family="Cinzel", weight="bold", spacing=3),
          f'<path d="M 436 470 A 64 64 0 0 0 564 470 Z" fill="#3E2C1C" stroke="{GOLD}" stroke-width="1.4"/>',
          sigil_mark(500, 492, "crack", s=1.2),
          label(500, 516, "THE SHATTERED MIRROR", 11.5, BANTX, family="Cinzel", spacing=2),
          line(500, 372, 500, 330, stroke=GOLD, sw=1.2, dash="2 5"),
          line(500, 540, 500, 596, stroke=GOLD, sw=1.2, dash="2 5"),
          label(500, 352, "THE FIRST SEAM", 16, "#5A4326", family="Cinzel", weight="bold", spacing=3)]
    # worlds on the sea
    s += [world_sigil(300, 560, 36, seed=5, known=True),
          label(300, 632, "YOUR WORLD", 21, INK, family="Cinzel", weight="bold"),
          label(300, 652, "the world you know", 13.5, "#6B4E26", family="IM Fell English", italic=True),
          sigil_mark(288, 552, "gate"), sigil_mark(316, 570, "forge")]
    semi = [(672, 470, 26, "heard of in taverns"), (745, 640, 24, "reached through the rift")]
    if mid:
        semi += [(215, 720, 22, "chart of the 2nd survey")]
    for (bx, by, br, note) in semi:
        s += [world_sigil(bx, by, br, seed=7),
              label(bx, by + br + 20, note, 13, "#5A4326", family="IM Fell English", italic=True)]
    fogs = [(180, 480, 18), (390, 760, 20), (620, 800, 18), (830, 540, 20), (640, 350, 18)]
    if late:
        fogs += [(130, 620, 14), (880, 700, 14), (500, 300, 16)]
    for (fx, fy, fr) in fogs:
        s += [fog_world(fx, fy, fr)]
    if mid:
        s += [path("M 300 560 Q 380 480 436 430", stroke=GOLDH, sw=1.3, dash="2 6", opacity=0.9),
              path("M 672 470 Q 560 430 500 430", stroke=GOLDH, sw=1.2, dash="2 6", opacity=0.85)]
    if late:
        s += [path("M 300 560 Q 480 700 620 800", stroke=GOLDH, sw=1.1, dash="2 6", opacity=0.75),
              path("M 745 640 Q 560 520 436 430", stroke=GOLDH, sw=1.1, dash="2 6", opacity=0.75),
              circle(500, 650, 330, stroke=GOLD, sw=0.8, dash="1 9", opacity=0.6)]
    # the abyss: a tear IN the page at the sea's bottom edge
    tear = "M 330 1000 L 380 1046 L 428 1018 L 470 1078 L 512 1030 L 560 1084 L 606 1036 L 650 1066 L 672 1000"
    s += [f'<path d="{tear} Z" fill="{DARK}"/>',
          f'<path d="{tear}" fill="none" stroke="{PARCH}" stroke-width="3.5"/>']
    if mid:
        s += [label(500, 1120, "THE ABYSS", 22, SEAL if not late else SEALTX,
                    family="Cinzel", weight="bold", spacing=4),
              label(500, 1142, "not a world — a wound beneath the water", 13.5, "#6B4E26",
                    family="IM Fell English", italic=True)]
    if late:
        s += [circle(500, 1050, 40, stroke=GOLD, sw=0.9, opacity=0.4),
              circle(500, 1050, 26, stroke=GOLD, sw=0.8, opacity=0.35),
              circle(500, 1050, 14, stroke=GOLD, sw=0.8, opacity=0.3),
              # reversed clocks: the hours misbehave near the tear
              circle(352, 1108, 15, stroke=SEAL, sw=1.4, opacity=0.8),
              line(352, 1108, 352, 1097, stroke=SEAL, sw=1.4),
              line(352, 1108, 343, 1113, stroke=SEAL, sw=1.4),
              circle(648, 1090, 15, stroke=SEAL, sw=1.4, opacity=0.8),
              line(648, 1090, 648, 1101, stroke=SEAL, sw=1.4),
              line(648, 1090, 657, 1084, stroke=SEAL, sw=1.4),
              label(500, 1168, "the hours swim backwards along the tear — clocks drawn by the 4th survey",
                    13, "#6B4E26", family="IM Fell English", italic=True),
              # god-rank: a halo outside the ellipse, unnamed
              path("M 120 520 A 430 430 0 0 1 880 520", stroke="#8a6a3a", sw=1.6, dash="10 8", opacity=0.8),
              label(500, 205, "AN UNNAMED CROWN ABOVE THE SEA", 16, "#6B4E26",
                    family="Cinzel", weight="bold", spacing=3, opacity=0.85)]
    # legend + furniture
    s += [legend_block(70, 300, [
        (world_sigil(0, -4, 11, seed=6, known=True), "a world afloat the sea"),
        (fog_world(0, -4, 11), "uncharted — a fog on the water"),
        (line(-12, -2, 12, -2, stroke=GOLDH, sw=1.4, dash="2 4"), "a rift road"),
        (circle(0, -2, 8, stroke=SEAL, sw=1.2), "a wound — never a world")])]
    s += [compass(118, 1230, 40),
          label(500, 1246, "no shore — though distance lies anyway", 13, "#6B4E26",
                family="IM Fell English", italic=True),
          line(430, 1262, 570, 1262, stroke=INK, sw=2.2),
          sheet_footer("B")]
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">' + "".join(s) + "</svg>"


def build_C(state):
    late = state == "late"
    mid = state in ("mid", "late")
    s = [parchment(45)]
    s += [cartouche(W // 2, 92, 640, 96, "THE WOVEN PILLAR",
                    "all worlds knotted to one thread — working name: kosmion")]
    # crown (god-rank) — above the frame of the column, unnamed
    s += [line(360, 300, 640, 300, stroke="#8a6a3a", sw=1.2, dash="8 8", opacity=0.7)]
    for i in range(3):
        s += [path(f"M {380 - i*0} {292 - i*14} Q 500 {252 - i*26} 620 {292 - i*14}",
                   stroke=GOLD, sw=1.1, dash="3 5", opacity=0.7 - i * 0.15)]
    s += [label(500, 232, "THE UNNAMED CROWN", 17, "#6B4E26", family="Cinzel",
                weight="bold", spacing=4, opacity=0.9),
          label(500, 252, "a fire above the weave — the chart will not name it", 13,
                "#6B4E26", family="IM Fell English", italic=True)]
    # pillar rules
    s += [line(380, 320, 380, 900, stroke=GOLD, sw=2.0, opacity=0.85),
          line(620, 320, 620, 900, stroke=GOLD, sw=2.0, opacity=0.85)]
    if mid:
        s += [sigil_mark(380, 560, "crack", s=1.5), sigil_mark(620, 700, "crack", s=1.5)]
    if late:
        s += [sigil_mark(380, 430, "crack", s=1.8), sigil_mark(620, 500, "crack", s=1.8),
              label(352, 566, "the pillar is not whole", 12.5, SEAL, family="IM Fell English",
                    italic=True, anchor="end", rotate=-90)]
    # the world ring (kosmion as a ring of worlds on the thread)
    s += [f'<ellipse cx="500" cy="620" rx="250" ry="86" fill="none" stroke="{GOLDH}" stroke-width="2.0" opacity="0.9"/>',
          f'<ellipse cx="500" cy="620" rx="250" ry="86" fill="#D9C08C" opacity="0.35"/>']
    ring_worlds = [(292, 620, 20, 11), (398, 556, 18, 12), (602, 556, 18, 13),
                   (708, 620, 20, 14), (602, 684, 18, 15), (398, 684, 18, 16)]
    for (wx, wy, wr, sd) in ring_worlds:
        s += [world_sigil(wx, wy, wr, seed=sd)]
    s += [world_sigil(500, 706, 34, seed=17, known=True),
          label(500, 762, "YOUR WORLD", 21, INK, family="Cinzel", weight="bold"),
          label(500, 782, "the knot you were tied at", 13.5, "#6B4E26",
                family="IM Fell English", italic=True),
          sigil_mark(488, 698, "gate"), sigil_mark(516, 714, "forge")]
    if mid:
        fogs = [(690, 468, 16)]
    else:
        fogs = []
    if late:
        fogs += [(160, 560, 14), (840, 640, 14)]
        s += [path("M 500 706 Q 660 740 826 646", stroke=GOLDH, sw=1.1, dash="2 6", opacity=0.8)]
    for (fx, fy, fr) in fogs:
        s += [fog_world(fx, fy, fr)]
    s += [label(500, 452, "THE WEAVE — A RING OF WORLDS", 17, "#5A4326",
                family="Cinzel", weight="bold", spacing=3)]
    if mid:
        s += [label(500, 472, "the thread runs through every knot", 13, "#6B4E26",
                    family="IM Fell English", italic=True)]
    # plinth + roots into the abyss
    s += [f'<rect x="360" y="900" width="280" height="26" fill="#3E2C1C" stroke="{GOLD}" stroke-width="1.4"/>',
          label(500, 948, "THE PILLAR'S FOOT — last sound stone", 13.5, "#5A4326",
                family="IM Fell English", italic=True)]
    strata = [
        (985,  "I",   "where lost hours gather"),
        (1050, "II",  "the tide that forgets"),
        (1115, "III", "the far ones — do not answer"),
        (1180, "—",   "no record survives"),
    ]
    depth_n = {"early": 2, "mid": 3, "late": 4}[state]
    for i, (yy, num, note) in enumerate(strata[:depth_n]):
        s += [path(f"M 240 {yy} Q 330 {yy-14} 430 {yy} T 640 {yy} T 800 {yy+6}",
                   stroke=INK, sw=1.6, opacity=0.75)]
        s += [label(210, yy + 5, num, 15, "#5A4326", family="Cinzel", weight="bold", anchor="end"),
              label(812, yy + 5, note, 13.5, "#5A4326", family="IM Fell English",
                    italic=True, anchor="start")]
    s += [label(500, 972, "THE ABYSS — BENEATH EVERY CHART, OUTSIDE THE WEAVE",
                15, INK, family="Cinzel", weight="bold", spacing=2)]
    # roots ending in broken tips (chaos fragments)
    if mid:
        s += [path("M 470 900 C 452 950 462 1000 448 1032", stroke=INK, sw=1.8, opacity=0.8),
              path("M 540 900 C 556 960 544 1010 556 1052", stroke=INK, sw=1.8, opacity=0.8)]
    if late:
        s += [path("M 500 926 C 500 980 492 1040 502 1104", stroke=INK, sw=2.0, opacity=0.85),
              f'<path d="M 444 1028 l 8 8 l -8 8 l -8 -8 Z" fill="{SEAL}"/>',
              f'<path d="M 552 1048 l 8 8 l -8 8 l -8 -8 Z" fill="{SEAL}"/>',
              f'<path d="M 498 1100 l 8 8 l -8 8 l -8 -8 Z" fill="{SEAL}"/>',
              label(500, 1218, "broken threads — fragments of the shattered mirror burn at the root-tips",
                    13, "#6B4E26", family="IM Fell English", italic=True),
              # the veil shoreline (late only, deliberately unlabelled as a place)
              line(300, 1258, 700, 1258, stroke=GOLD, sw=1.6),
              line(300, 1264, 700, 1264, stroke=GOLD, sw=0.8),
              label(500, 1252, "the far shore of the veil — not charted, by law", 12.5,
                    "#6B4E26", family="IM Fell English", italic=True),
              stamp(845, 1258, "NO FURTHER SURVEY", rot=3, w=200)]
    # legend + furniture (down-bearing rose instead of compass: depth is the only bearing)
    s += [legend_block(70, 300, [
        (world_sigil(0, -4, 11, seed=18, known=True), "a knot of the weave — a world"),
        (fog_world(0, -4, 11), "a knot the fog keeps"),
        (line(-12, -2, 12, -2, stroke=INK, sw=1.8), "a root of the pillar"),
        (f'<path d="M -6 -8 l 6 6 l 6 -6 l -6 10 Z" fill="{SEAL}"/>', "a burned fragment — Chaos")])]
    s += [f'<g transform="translate(118 1096)">'
          f'<circle cx="0" cy="0" r="26" fill="none" stroke="{GOLD}" stroke-width="1.2"/>'
          f'<line x1="0" y1="-16" x2="0" y2="12" stroke="{INK}" stroke-width="2.2"/>'
          f'<path d="M -6 8 L 0 20 L 6 8 Z" fill="{INK}"/></g>',
          label(118, 1148, "the only true bearing", 12.5, "#6B4E26",
                family="IM Fell English", italic=True),
          label(500, 1120 if state == "early" else 1306, "one league — depth is measured in other coin",
                13, "#6B4E26", family="IM Fell English", italic=True),
          sheet_footer("C")]
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">' + "".join(s) + "</svg>"
