# Architecture Notes — How a Proposed Feature Would Physically Integrate

> Engineering-facing synthesis of the investigation. No code was changed. File:line refs are
> from `31be194f` / `01ab7e0`.

---

## 1. End-to-end flow of a card-generating command (the template `.j world` would follow)

```
player: ".j world"
→ engine.js dispatch (primaryCmd match, e.g. after :9191 style of gating)
→ handler (new module, e.g. core/rpg/worldMap.js — new features go in separate modules,
   house rule: never grow engine.js inline)
   ├─ load player: economy.getUser(jid) (async, Mongo)
   ├─ read progression inputs: user.progression.level, user.adventurerRank,
   │   dungeon/abyss history (see §3 map-state sources)
   ├─ build payload { kind: "WORLDMAP", style: user.cardStyle || 0, discovered: [...], … }
   ├─ goImageService.generatePortraitCard(payload) → Buffer | null   (timeout 10 s)
   ├─ Buffer path:  sock.sendMessage(image FIRST, caption = help text + lore-drop line)
   └─ null path:    text-only map fallback (ASCII/emoji map sketch)  ← mandatory contract
```

Key contracts to respect: image-before-text; text fallback mandatory; `cardstyle.Sanitize`
strips emoji from card text (keep labels ASCII); payload `style` always passed; new Go kind
registers in `portrait.go` dispatch + `styledKinds()` + per-style switches (or stays baked).

## 2. Where lore drops would physically live

Proposed shape (implementation/lore_drop_system.md details it):

```
core/rpg/loreDrops.js          NEW MODULE (house pattern: separate module, required by callers)
  ├─ POOLS = { blacksmith: [...], brewing: [...], … afterlife: [...] }   // pure data
  ├─ maybeDrop(category, context) → string | null
  │    - probability gate (default 10%, per-command overrides — see investigation §2 rates)
  │    - per-chat + per-user cooldown map (in-memory LRU, ~30 min)
  │    - recent-lines ring per chat (no repeats within N lines)
  │    - try/catch-wrapped, synchronous-fast — can never slow the pipeline
  └─ format: `╒ *${line}* ╛` — italics on the TEXT, framing glyphs unitalicized
Call sites (1-line appends):
  craftingSystem.js:717 (craft family captions) · repairCommands.js:118/170 ·
  engine.js:25226 (balance caption) · economy.js:1069/1149/1238 (money messages) ·
  runeSystem.js:739/663 · shopCommands.js:446 · rpgCommands.js:527 ·
  guildAdventure.js:6330-6362 (abyss victory) · abyssSystem.js processTreasure/processEventChoice
```

Why a separate module: engine.js is ~27k lines and Python-fragile to edit (house rule 26);
`broadcastHelpers.js` and `interactionTracker.js` set the precedent for feature modules.
Zero schema changes needed for drops themselves.

## 3. World map player state — what would need persistence

Three viable sources, investigated:

| Option | Source | Pros | Cons |
|---|---|---|---|
| A. Derive-on-read | compute discoveries from existing fields: `user.progression.level`, `user.adventurerRank`, Abyss deepest floor (`AbyssLeaderboard` history / AbyssRun), dungeon completions, questsWon | zero schema change, zero migration | harder to add hand-authored discoveries later; recompute cost per render |
| B. New subdoc | `user.worldMap = { discoveries: [ids], firstViewedAt, … }` on User | per-player state, extendable | schema change (must be declared same commit — strict mode rule); one migration-free field add is house-safe |
| C. Dedicated collection | `WorldState` per user | bulk events, timeline | overkill for v1 |

Implementation doc recommends **B-lite**: one declared Map/Array field, lazily initialized on
first `.j world` call (same pattern as `stats.currentHP = -1` sentinel initialization).

## 4. Souls / Afterlife integration points

- **Counter:** add `user.stats.soulsSent` (+ optional `soulsByRank` Mixed map) declared in
  User.js; increment inside `recordEnemyKill` (guildAdventure.js:5675-5808) so PvE, Abyss,
  and pack adds all flow through one site; PvP deliberately excluded (a duel isn't a soul sent
  — or is it? flagged as open question).
- **Backfill decision (NEEDS REVIEW):** initialize `soulsSent` to 0 (clean narrative "the sight
  begins now") vs. seed from current `kills` (narratively "you never realized what you'd been
  doing"). Both are one line; owner should pick.
- **Sight gate:** house pattern = lore-flavored rejection copied from the Boundless Void gate
  (guildAdventure.js:6838). Suggested threshold documented as L40+ **or** rank B+ (open question
  — level gates in the codebase use 20; soul-sight should feel rarer).
- **Fortune teller interaction:** v1 = a command (e.g. `.j seer` / `.j souls`) that renders a
  new portrait-family card (SOULS kind) + afterlife lore pool lines. No NPC conversation system
  exists today — out of scope, flagged.

## 5. Abyss encounter-category lore (mechanics)

- `generateFloorEncounter` (abyssSystem.js:282-347) already labels each encounter
  (`combat|wild_summon|treasure|event` + boss/pack flags) and persists it on the run
  (`AbyssRun.currentEncounterType/EncounterData`, Mixed).
- A lore drop keyed to category requires **no new persistence**: at victory/collect/event text
  composition, call `loreDrops.maybeDrop('abyss_' + categoryVariant, ctx)`.
- `abyss_self_variant` / `abyss_player` pools would *eventually* pair with enemy naming
  ("Wanderer", "The Other You") — that IS a gameplay change, so it's listed PROPOSED-only in
  ideas.md; v1 pools are dialogue-only.

## 6. Render pipeline facts affecting the artwork in this package

- Card text on Go side goes through `cardstyle.Sanitize` + fit-to-width — mockups in this ZIP
  keep all in-card copy ASCII-safe and short.
- Wax seal, darkPill, captionAt, banner/plate geometry constants are exact — mockups reproduce
  them so the owner can compare designs against live cards 1:1.
- Character art in mockups is **AI-generated placeholder art** (CC0-equivalent output owned by
  the project per the generation tool's terms — see asset_sources/sources_and_licenses.md);
  final shipping art can be re-cut from these or replaced with licensed packs.

## 7. Risks / constraints the implementation must respect

1. Mongoose strict mode — every new persisted field declared in the same change (bit 4×).
2. Go service has an in-memory image cache — any new sprite/bg asset requires pm2 restart to
   clear stale renders.
3. Box 1 RAM (450MB pm2 line) — lore drops must be pure in-memory picks (they are).
4. Node edits to engine.js: use Node/sed, never Python read-modify-write; backup `.bak_<tag>`
   before guarded patches; `node --check` after every edit (house deploy pattern).
5. Never edit Go files only on Box 2; edit the mirror, push, build, restart (if/when approved).
6. All three render paths (PvE / PvP-1v1 / PvP-summon) exist for battle cards — lore drops that
   touch combat text must be checked on all three.
