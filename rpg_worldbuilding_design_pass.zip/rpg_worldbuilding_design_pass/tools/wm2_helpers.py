#!/usr/bin/env python3.13
"""wm2_helpers.py — decree-styled cosmology chart primitives (SVG -> cairosvg).

Palette = theme.go decreeTheme / palettes.go style 7 (byte-accurate):
  parchment #E9D7AB, ink #342010, gold #AA823C, seal #801C28, banner tx #F4D68C.
Fonts resolve via fontconfig: Cinzel, Cinzel Decorative, IM Fell English.
NOTE: no 8-digit hex (cairosvg bug) — opacity via attributes only.
"""
import math, random

# decree palette
INK   = "#342010"
GOLD  = "#AA823C"
GOLDH = "#D6AA52"
PARCH = "#E9D7AB"
PARCH2= "#E2CD9A"
SEAL  = "#801C28"
SEALTX= "#FAD278"
BANTX = "#F4D68C"
DARK  = "#18100A"
FOG   = "#7A6A4A"
W, H  = 1000, 1400

def esc(t):
    return (t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

def label(x, y, text, size=22, fill=INK, family="Cinzel", weight="normal",
          spacing=2.0, anchor="middle", italic=False, opacity=1.0, rotate=None):
    style = ' font-style="italic"' if italic else ""
    rot = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ""
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'fill="{fill}" font-weight="{weight}" letter-spacing="{spacing}" '
            f'text-anchor="{anchor}"{style} opacity="{opacity}"{rot}>{esc(text)}</text>')

def circle(cx, cy, r, fill="none", stroke=INK, sw=1.5, opacity=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" stroke="{stroke}" '
            f'stroke-width="{sw}" opacity="{opacity}"{d}/>')

def ring(cx, cy, r_out, r_in, fill, opacity=1.0):
    return (f'<path d="M {cx-r_out} {cy} A {r_out} {r_out} 0 1 0 {cx+r_out} {cy} '
            f'A {r_out} {r_out} 0 1 0 {cx-r_out} {cy} Z '
            f'M {cx-r_in} {cy} A {r_in} {r_in} 0 1 1 {cx+r_in} {cy} '
            f'A {r_in} {r_in} 0 1 1 {cx-r_in} {cy} Z" fill="{fill}" fill-rule="evenodd" '
            f'opacity="{opacity}"/>')

def line(x1, y1, x2, y2, stroke=GOLD, sw=1.4, opacity=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" '
            f'stroke-width="{sw}" opacity="{opacity}"{d}/>')

def path(d, fill="none", stroke=INK, sw=1.6, opacity=1.0, dash=None):
    ds = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" '
            f'opacity="{opacity}"{ds}/>')

def world_sigil(cx, cy, r, seed=1, known=False, gold=GOLDH, ink=INK, fog=FOG):
    """A world as a charted orb: parchment disc + wobbly shoreline + meridian."""
    rnd = random.Random(seed)
    s = f'<g opacity="1">'
    s += circle(cx, cy, r + 4, fill=PARCH2 if not known else "#EFDDB2", stroke="none", opacity=0.9)
    # wobbly coast
    pts, n = [], 14
    for i in range(n):
        a = 2 * math.pi * i / n
        w = 0.72 + 0.26 * rnd.random()
        pts.append((cx + r * w * math.cos(a), cy + r * w * math.sin(a)))
    d = f"M {pts[0][0]:.1f} {pts[0][1]:.1f} "
    for i in range(1, n + 1):
        p0, p1 = pts[i % n], pts[(i + 1) % n]
        d += f"Q {p0[0]:.1f} {p0[1]:.1f} {(p0[0]+p1[0])/2:.1f} {(p0[1]+p1[1])/2:.1f} "
    d += "Z"
    s += path(d, fill="#DFC98F" if known else PARCH2, stroke=ink if known else fog,
              sw=1.6 if known else 1.1)
    # meridian + parallel
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="{r*0.42:.1f}" ry="{r:.1f}" fill="none" stroke="{ink if known else fog}" stroke-width="0.7" opacity="0.55"/>'
    s += line(cx - r * 0.9, cy, cx + r * 0.9, cy, stroke=ink if known else fog, sw=0.7, opacity=0.5)
    if known:
        s += circle(cx, cy, r + 7, stroke=gold, sw=1.6, dash="3 4")
    s += "</g>"
    return s

def fog_world(cx, cy, r, seed=2):
    return (circle(cx, cy, r, stroke=FOG, sw=1.0, dash="2 5", opacity=0.9) +
            label(cx, cy + 7, "?", 26, FOG, family="Cinzel", weight="bold", opacity=0.85))

def sigil_mark(cx, cy, kind, ink=INK, gold=GOLD, s=1.0):
    """Small map marks: dungeon gate, forge, star, etc."""
    k = kind
    if k == "gate":
        return (path(f"M {cx-7*s} {cy+6*s} L {cx-7*s} {cy-4*s} Q {cx} {cy-12*s} {cx+7*s} {cy-4*s} "
                     f"L {cx+7*s} {cy+6*s} Z", fill="none", stroke=ink, sw=1.4) +
                circle(cx, cy, 1.6 * s, fill=ink, stroke="none"))
    if k == "forge":
        return (path(f"M {cx-7*s} {cy+5*s} L {cx-7*s} {cy-2*s} L {cx-2*s} {cy-2*s} "
                     f"L {cx-2*s} {cy-7*s} L {cx+2*s} {cy-7*s} L {cx+2*s} {cy-2*s} "
                     f"L {cx+7*s} {cy-2*s} L {cx+7*s} {cy+5*s} Z",
                     fill="none", stroke=ink, sw=1.3))
    if k == "star":
        return (f'<path d="M {cx} {cy-8*s} L {cx+2.1*s} {cy-2.5*s} L {cx+8*s} {cy-2.5*s} '
                f'L {cx+3.2*s} {cy+1.2*s} L {cx+5*s} {cy+7*s} L {cx} {cy+3.2*s} '
                f'L {cx-5*s} {cy+7*s} L {cx-3.2*s} {cy+1.2*s} L {cx-8*s} {cy-2.5*s} '
                f'L {cx-2.1*s} {cy-2.5*s} Z" fill="none" stroke="{gold}" stroke-width="1.2"/>')
    if k == "crack":
        return path(f"M {cx-6*s} {cy+5*s} L {cx-1*s} {cy} L {cx-3*s} {cy-2*s} L {cx+2*s} {cy-6*s} "
                    f"L {cx+4*s} {cy-3*s} L {cx+7*s} {cy-5*s}", stroke=ink, sw=1.5)
    return ""

def wax_seal(cx, cy, r=34, letter="K"):
    s = circle(cx, cy, r, fill=SEAL, stroke="#5e1119", sw=2)
    s += circle(cx, cy, r - 7, stroke=SEALTX, sw=1.0, opacity=0.75)
    s += label(cx, cy + 8, letter, 30, SEALTX, family="Cinzel Decorative",
               weight="bold", spacing=0)
    return s

def cartouche(cx, cy, w, h, title, sub="", title_size=44, dark=False):
    """Decree title cartouche (dark band + gold rules) like banner band y18-108."""
    f = "none"
    s = f'<rect x="{cx-w//2}" y="{cy-h//2}" width="{w}" height="{h}" fill="{DARK if dark else "#3E2C1C"}" opacity="0.92" rx="3"/>'
    s += f'<rect x="{cx-w//2+6}" y="{cy-h//2+6}" width="{w-12}" height="{h-12}" fill="none" stroke="{GOLD}" stroke-width="1.6" opacity="0.9"/>'
    s += label(cx, cy + (2 if not sub else -4), title, title_size, BANTX,
               family="Cinzel Decorative", weight="bold", spacing=7)
    if sub:
        s += label(cx, cy + 22, sub, 15, "#C9A961", family="IM Fell English",
                   italic=True, spacing=1)
    # fold notches
    s += f'<path d="M {cx-w//2-14} {cy-h//2} L {cx-w//2} {cy} L {cx-w//2-14} {cy+h//2}" fill="none" stroke="{GOLD}" stroke-width="1.6"/>'
    s += f'<path d="M {cx+w//2+14} {cy-h//2} L {cx+w//2} {cy} L {cx+w//2+14} {cy+h//2}" fill="none" stroke="{GOLD}" stroke-width="1.6"/>'
    return s

def compass(cx, cy, r):
    s = circle(cx, cy, r, stroke=GOLD, sw=1.2) + circle(cx, cy, r * 0.72, stroke=GOLD, sw=0.7)
    for dx, dy, ch in [(0, -r - 14, "N"), (0, r + 22, "S"), (-r - 16, 6, "W"), (r + 16, 6, "E")]:
        s += label(cx + dx, cy + dy, ch, 18, INK, family="Cinzel", weight="bold")
    s += f'<path d="M {cx} {cy-r} L {cx+6} {cy} L {cx} {cy+r} L {cx-6} {cy} Z" fill="{INK}" opacity="0.8"/>'
    return s

def stamp(x, y, text, rot=-6, w=150, h=26):
    """Surveyor's red stamp."""
    return (f'<g transform="rotate({rot} {x} {y})">'
            f'<rect x="{x-w//2}" y="{y-h//2}" width="{w}" height="{h}" fill="none" '
            f'stroke="{SEAL}" stroke-width="1.6" opacity="0.75" rx="2"/>'
            + label(x, y + 5, text, 11.5, SEAL, family="Cinzel", spacing=1.5, opacity=0.85)
            + "</g>")

def parchment(bg_alpha_noise_seed=11):
    """Full sheet: dark backing, full-bleed parchment w/ torn top+bottom edges,
    grain, blotches, gold hairline frame."""
    rnd = random.Random(bg_alpha_noise_seed)
    s = f'<rect width="{W}" height="{H}" fill="{DARK}"/>'
    # torn full-bleed sheet
    rnd2 = random.Random(bg_alpha_noise_seed + 4)
    top, bot = [], []
    x = -10.0
    while x <= W + 10:
        top.append((x, 44 + rnd2.uniform(0, 34)))
        bot.append((x, H - 44 - rnd2.uniform(0, 38)))
        x += rnd2.uniform(26, 56)
    d = f"M {top[0][0]:.1f} {top[0][1]:.1f} "
    for (px, py) in top[1:]:
        d += f"L {px:.1f} {py:.1f} "
    d += f"L {W+10:.1f} {H+10:.1f} L -10 {H+10:.1f} Z"
    d2 = f"M {bot[-1][0]:.1f} {bot[-1][1]:.1f} "
    for (px, py) in reversed(bot[:-1]):
        d2 += f"L {px:.1f} {py:.1f} "
    s += f'<path d="{d}" fill="{PARCH}"/>'
    s += f'<path d="{d}" fill="none" stroke="#5a4020" stroke-width="3" opacity="0.55"/>'
    s += f'<defs><filter id="grain" x="0" y="0" width="100%" height="100%">'
    s += f'<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="7" result="n"/>'
    s += f'<feColorMatrix in="n" type="matrix" values="0 0 0 0 0.55 0 0 0 0 0.47 0 0 0 0 0.33 0 0 0 0.10 0"/>'
    s += f'</filter>'
    s += f'<radialGradient id="agedge" cx="0.5" cy="0.5" r="0.72">'
    s += f'<stop offset="0.62" stop-color="{PARCH}" stop-opacity="0"/><stop offset="1" stop-color="#8a6a3a" stop-opacity="0.5"/></radialGradient>'
    s += f'<radialGradient id="corelight" cx="0.5" cy="0.42" r="0.85">'
    s += f'<stop offset="0" stop-color="#F2E3BC" stop-opacity="1"/><stop offset="1" stop-color="{PARCH}" stop-opacity="0"/></radialGradient>'
    s += f'</defs>'
    s += f'<path d="{d}" fill="url(#corelight)"/>'
    s += f'<rect y="44" width="{W}" height="{H-88}" filter="url(#grain)" opacity="0.32"/>'
    s += f'<rect width="{W}" height="{H}" fill="url(#agedge)" opacity="0.55"/>'
    # blotches
    for _ in range(26):
        bx, by = rnd.uniform(60, W - 60), rnd.uniform(60, H - 60)
        br = rnd.uniform(4, 26)
        s += circle(bx, by, br, fill="#6a4c22", stroke="none", opacity=rnd.uniform(0.05, 0.14))
    # fibers
    for _ in range(40):
        x1, y1 = rnd.uniform(40, W - 40), rnd.uniform(40, H - 40)
        s += line(x1, y1, x1 + rnd.uniform(-30, 30), y1 + rnd.uniform(-8, 8),
                  stroke="#7a5c2e", sw=0.5, opacity=0.12)
    # gold hairline frame (decree frame style: inset 10 lw1.5 r6)
    s += f'<rect x="14" y="14" width="{W-28}" height="{H-28}" fill="none" stroke="{GOLD}" stroke-width="1.8" rx="6" opacity="0.85"/>'
    s += f'<rect x="22" y="22" width="{W-44}" height="{H-44}" fill="none" stroke="{GOLD}" stroke-width="0.7" rx="4" opacity="0.6"/>'
    return s

def legend_block(x, y, entries, title="HOW TO READ THIS"):
    s = f'<rect x="{x-16}" y="{y-26}" width="292" height="{34 + 24*len(entries)}" fill="#E4CF9C" opacity="0.72" rx="3"/>'
    s += f'<rect x="{x-16}" y="{y-26}" width="292" height="{34 + 24*len(entries)}" fill="none" stroke="{GOLD}" stroke-width="1" opacity="0.7" rx="3"/>'
    s += label(x + 130, y - 2, title, 16, INK, family="Cinzel", weight="bold", spacing=2)
    for i, (mark, txt) in enumerate(entries):
        yy = y + 22 + i * 24
        s += f'<g transform="translate({x+14} {yy})">{mark}</g>'
        s += label(x + 42, yy + 5, txt, 14.5, "#5A4326", family="IM Fell English",
                   anchor="start", spacing=0.4)
    return s

def sheet_footer(seal_letter="K", note="surveyed by decree of the crown - corrections are treason"):
    s = wax_seal(W - 108, H - 96, 30, seal_letter)
    s += label(W // 2 - 60, H - 58, note, 14, "#6B4E26", family="IM Fell English", italic=True, spacing=1)
    return s
